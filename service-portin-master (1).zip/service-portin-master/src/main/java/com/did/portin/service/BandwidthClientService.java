package com.did.portin.service;

import com.did.portin.client.BandwidthClientFactory;
import com.did.portin.model.bandwidth.BulkPortin;
import com.did.portin.model.bandwidth.BulkPortinRequest;
import com.did.portin.model.bandwidth.BulkPortinResponse;
import com.did.portin.model.bandwidth.ErrorResponse;
import com.did.portin.model.bandwidth.FileMetaData;
import com.did.portin.model.bandwidth.FileUploadResponse;
import com.did.portin.model.bandwidth.IrisStatus;
import com.did.portin.model.bandwidth.IrisStatusForOrderHistoryWrapper;
import com.did.portin.model.bandwidth.LOAFileListResponse;
import com.did.portin.model.bandwidth.LnpOrderResponse;
import com.did.portin.model.bandwidth.LnpOrderSupp;
import com.did.portin.model.bandwidth.Notes;
import com.did.portin.model.bandwidth.NumberPortabilityRequest;
import com.did.portin.model.bandwidth.NumberPortabilityResponse;
import com.did.portin.model.bandwidth.OrderHistoryWrapper;
import com.did.portin.model.bandwidth.PortinList;
import com.did.portin.model.bandwidth.PortinListResponse;
import com.did.portin.model.bandwidth.Status;
import com.did.portin.model.bandwidth.TnList;
import com.did.portin.model.bandwidth.TnListResponse;
import com.google.common.base.Strings;
import io.micrometer.core.lang.NonNull;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import retrofit2.Converter;
import retrofit2.Response;

import javax.inject.Inject;
import javax.inject.Named;
import javax.naming.AuthenticationException;
import javax.validation.constraints.NotNull;
import javax.ws.rs.BadRequestException;
import java.io.IOException;
import java.lang.annotation.Annotation;
import java.util.Objects;


@Service
public class BandwidthClientService {

  @Inject BandwidthClientFactory bandwidthClientFactory;

  @Inject
  @Named("bandwidth.api.retry.max.count")
  private Integer bwApiMaxRetryCount;

  @Inject
  @Named("bandwidth.api.retry.interval")
  private Integer bwApiRetryInterval;
  private static final Logger logger = LoggerFactory.getLogger(BandwidthClientService.class);

  public Notes getNotes(@NotNull String bwOrderId) throws Exception {
    BandwidthClientFactory bandwidthClientFactory = new BandwidthClientFactory();
    Response<Notes> response =
        bandwidthClientFactory
            .getBandwidthClient()
            .notes(bandwidthClientFactory.generateBWToken(), bwOrderId)
            .execute();
    if (response.code() == 401) {
      throw new AuthenticationException(response.message());
    } else if (response.code() == 200) {
      return response.body();
    } else if (response.code() == 204) {
      return new Notes();
    } else {
      throw new BadRequestException(
          String.format(
              "Error occurred while getting Notes for Bandwidth Order id %s : %s",
              bwOrderId, response.message()));
    }
  }

  public LOAFileListResponse getLOAFileDetails(@NotNull String bwOrderId, String metaData)
      throws Exception {
    metaData = Strings.isNullOrEmpty(metaData) ? Boolean.TRUE.toString() : metaData;
    Response<LOAFileListResponse> response =
        bandwidthClientFactory
            .getBandwidthClient()
            .loaFilesDetails(bandwidthClientFactory.generateBWToken(), bwOrderId, metaData)
            .execute();
    if (response.code() == 401) {
      throw new AuthenticationException(response.message());
    } else if (response.code() == 200) {
      return response.body();
    } else if (response.code() == 204) {
      return new LOAFileListResponse();
    } else if (response.code() == 400 || response.code() == 404) {
      Converter<ResponseBody, ErrorResponse> errorConverter =
          bandwidthClientFactory
              .getRetrofit()
              .responseBodyConverter(ErrorResponse.class, new Annotation[0]);
      try {
        ErrorResponse errorResponse = errorConverter.convert(response.errorBody());
        LOAFileListResponse lOAFileListResponse = new LOAFileListResponse();
        lOAFileListResponse.setErrorResponse(errorResponse);
        return lOAFileListResponse;
      } catch (IOException e) {
        logger.error("Exception in BandwidthClientService.getLOAFileDetails",e.getMessage());
        throw new BadRequestException(
            String.format(
                "Error occurred while getting FileListLOA for Bandwidth Order id %s : %s",
                e.getMessage()));
      }
    } else {
      throw new BadRequestException(
          String.format(
              "Error occurred while getting FileListLOA for Bandwidth Order id %s : %s",
              bwOrderId, response.message()));
    }
  }

  public BulkPortinResponse createBulkPortin(@NotNull BulkPortinRequest bulkPortin)
      throws Exception {
    Response<BulkPortinResponse> response =
        bandwidthClientFactory
            .getBandwidthClient()
            .bulkPortins(bandwidthClientFactory.generateBWToken(), bulkPortin)
            .execute();
    if (response.code() == 401) {
      throw new AuthenticationException(response.message());
    } else if (response.code() == 201) {
      return response.body();
    } else if (response.code() == 204) {
      return new BulkPortinResponse();
    } else {
      throw new BadRequestException(
          String.format(
              "Error occurred while Create bulkportin Request %s : ", response.message()));
    }
  }

  public TnListResponse addTNsToBulkPortInOrder(@NonNull String orderId, @NotNull TnList tnList)
      throws Exception {
    Response<TnListResponse> response =
        bandwidthClientFactory
            .getBandwidthClient()
            .bulkPortinsTnListSubmit(bandwidthClientFactory.generateBWToken(), orderId, tnList)
            .execute();
    if (response.code() == 401) {
      throw new AuthenticationException(response.message());
    } else if (response.code() == 202) {
      return response.body();
    } else if (response.code() == 204) {
      return new TnListResponse();
    } else if (response.code() == 400) {
      Converter<ResponseBody, TnListResponse> errorConverter =
          bandwidthClientFactory
              .getRetrofit()
              .responseBodyConverter(TnListResponse.class, new Annotation[0]);
      try {
        return errorConverter.convert(response.errorBody());
      } catch (IOException e) {
        logger.error("Exception in BandwidthClientService.addTNsToBulkPortInOrder",e.getMessage());
        throw new BadRequestException(
            String.format(
                "Error occurred while submit the telephone numbers for bulkportin Request creation %s :",
                e.getMessage()));
      }
    } else {
      throw new BadRequestException(
          String.format(
              "Error occurred while submit the telephone numbers for bulkportin Request creation %s :",
              response.message()));
    }
  }

  public TnListResponse getTNsFromBulkPortInOrder(@NonNull String orderId) throws Exception {
    return getTNsFromBulkPortInOrder(orderId, 0);
  }

  public TnListResponse getTNsFromBulkPortInOrder(@NonNull String orderId, int retryCount)
      throws Exception {
    Response<TnListResponse> response =
        bandwidthClientFactory
            .getBandwidthClient()
            .bulkPortinsTnListFetch(bandwidthClientFactory.generateBWToken(), orderId)
            .execute();
    if (response.code() == 401) {
      throw new AuthenticationException(response.message());
    } else if (response.code() == 200) {
      TnListResponse tnListResponse = response.body();
      if (retryCount <= bwApiMaxRetryCount
          && CollectionUtils.isEmpty(tnListResponse.getValidTnList().getTns())
          && CollectionUtils.isEmpty(tnListResponse.getNonPortableTnList().getTns())) {
        Thread.sleep(bwApiRetryInterval);
        return getTNsFromBulkPortInOrder(orderId, retryCount + 1);
      }
      return response.body();
    } else if (response.code() == 204) {
      return new TnListResponse();
    } else if (response.code() == 400) {
      Converter<ResponseBody, TnListResponse> errorConverter =
          bandwidthClientFactory
              .getRetrofit()
              .responseBodyConverter(TnListResponse.class, new Annotation[0]);
      try {
        return errorConverter.convert(response.errorBody());
      } catch (IOException e) {
        logger.error("Exception in BandwidthClientService.getTNsFromBulkPortInOrder",e.getMessage());
        throw new BadRequestException(
            String.format(
                "Error occurred while submit the telephone numbers for bulkportin Request creation %s :",
                e.getMessage()));
      }
    } else {
      throw new BadRequestException(
          String.format(
              "Error occurred while getting the telephone numbers for bulkportin Request %s :",
              response.message()));
    }
  }

  public PortinListResponse getPortinListForBulkPortInOrder(@NonNull String orderId)
      throws Exception {
    return getPortinListForBulkPortInOrder(orderId, 0);
  }

  private PortinListResponse getPortinListForBulkPortInOrder(
      @NonNull String orderId, int retryCount) throws Exception {
    Response<PortinListResponse> response =
        bandwidthClientFactory
            .getBandwidthClient()
            .bulkPortinsPortinList(bandwidthClientFactory.generateBWToken(), orderId)
            .execute();
    if (response.code() == 401) {
      throw new AuthenticationException(response.message());
    } else if (response.code() == 200) {
      PortinListResponse portinListResponse = response.body();
      if (Objects.nonNull(portinListResponse)) {
        PortinList portinList = portinListResponse.getPortinList();
        if (Objects.nonNull(portinList.getPortinOrderId())) {
          return portinListResponse;
        }

        if (retryCount <= bwApiMaxRetryCount && Objects.isNull(portinList.getPortinOrderId())) {
          Thread.sleep(bwApiRetryInterval);
          return getPortinListForBulkPortInOrder(orderId, retryCount + 1);
        }
      }
      return null;
    } else if (response.code() == 204) {
      return new PortinListResponse();
    } else if (response.code() == 400 || response.code() == 404) {
      Converter<ResponseBody, PortinListResponse> errorConverter =
          bandwidthClientFactory
              .getRetrofit()
              .responseBodyConverter(PortinListResponse.class, new Annotation[0]);
      try {
        return errorConverter.convert(response.errorBody());
      } catch (IOException e) {
        logger.error("Exception in BandwidthClientService.getPortinListForBulkPortInOrder",e.getMessage());
        throw new BadRequestException(
            String.format(
                "Error occurred while getting the Portin List for bulkportin Request creation %s :",
                e.getMessage()));
      }
    } else {
      throw new BadRequestException(
          String.format(
              "Error occurred while getting the Portin List for bulkportin Request creation %s :",
              response.message()));
    }
  }

  public NumberPortabilityResponse lnpchecker(
      String fullCheck, @NonNull NumberPortabilityRequest numberPortabilityRequest)
      throws Exception {
    fullCheck = Strings.isNullOrEmpty(fullCheck) ? "true" : fullCheck;
    Response<NumberPortabilityResponse> response =
        bandwidthClientFactory
            .getBandwidthClient()
            .lnpchecker(
                bandwidthClientFactory.generateBWToken(), fullCheck, numberPortabilityRequest)
            .execute();
    if (response.code() == 401) {
      throw new AuthenticationException(response.message());
    } else if (response.code() == 200) {
      return response.body();
    } else if (response.code() == 204) {
      return new NumberPortabilityResponse();
    } else if (response.code() == 400 || response.code() == 404) {
      Converter<ResponseBody, NumberPortabilityResponse> errorConverter =
          bandwidthClientFactory
              .getRetrofit()
              .responseBodyConverter(NumberPortabilityResponse.class, new Annotation[0]);
      try {
        return errorConverter.convert(response.errorBody());
      } catch (IOException e) {
        logger.error("Exception in BandwidthClientService.lnpchecker",e.getMessage());
        throw new BadRequestException(
            String.format(
                "Error occurred while validating TNs using lnpchecker %s :", e.getMessage()));
      }
    } else {
      throw new BadRequestException(
          String.format(
              "Error occurred while validating TNs using lnpchecker %s :", response.message()));
    }
  }

  /**
   * @param portinOrderId
   * @return
   * @throws Exception
   */
  public LnpOrderResponse getPortinOrderDetails(@NonNull String portinOrderId) throws Exception {
    Response<LnpOrderResponse> response =
        bandwidthClientFactory
            .getBandwidthClient()
            .portinOrderDetails(bandwidthClientFactory.generateBWToken(), portinOrderId)
            .execute();
    if (response.code() == 401) {
      throw new AuthenticationException(response.message());
    } else if (response.code() == 200) {
      return response.body();
    } else if (response.code() == 204) {
      return new LnpOrderResponse();
    } else if (response.code() == 400 || response.code() == 404) {
      Converter<ResponseBody, ErrorResponse> errorConverter =
          bandwidthClientFactory
              .getRetrofit()
              .responseBodyConverter(ErrorResponse.class, new Annotation[0]);
      try {
        ErrorResponse errorResponse = errorConverter.convert(response.errorBody());
        LnpOrderResponse lnpOrderResponse = new LnpOrderResponse();
        lnpOrderResponse.setErrorResponse(errorResponse);
        return lnpOrderResponse;
      } catch (IOException e) {
        logger.error("Exception in BandwidthClientService.getPortinOrderDetails",e.getMessage());
        throw new BadRequestException(
            String.format(
                "Error occurred while getting the Portin id details for portin order %s :",
                e.getMessage()));
      }
    } else {
      throw new BadRequestException(
          String.format(
              "Error occurred while getting the Portin id details for portin order %s :",
              response.message()));
    }
  }

  /**
   * @param portinOrderId
   * @param lnpOrderSupp
   * @return
   * @throws Exception
   */
  public LnpOrderResponse suppPortinOrder(
      @NonNull String portinOrderId, @NonNull LnpOrderSupp lnpOrderSupp) throws Exception {
    Response<LnpOrderResponse> response =
        bandwidthClientFactory
            .getBandwidthClient()
            .suppPortinOrder(bandwidthClientFactory.generateBWToken(), portinOrderId, lnpOrderSupp)
            .execute();
    if (response.code() == 401) {
      throw new AuthenticationException(response.message());
    } else if (response.code() == 200) {
      return response.body();
    } else if (response.code() == 204) {
      return new LnpOrderResponse();
    } else if (response.code() == 400 || response.code() == 404) {
      Converter<ResponseBody, LnpOrderResponse> errorConverter =
          bandwidthClientFactory
              .getRetrofit()
              .responseBodyConverter(LnpOrderResponse.class, new Annotation[0]);
      try {
        return errorConverter.convert(response.errorBody());
      } catch (IOException e) {
        logger.error("Exception in BandwidthClientService.suppPortinOrder",e.getMessage());
        throw new BadRequestException(
            String.format(
                "Error occurred while getting the Portin id details for portin order %s :",
                e.getMessage()));
      }
    } else {
      throw new BadRequestException(
          String.format(
              "Error occurred while getting the Portin id details for portin order %s :",
              response.message()));
    }
  }

  /**
   * @param portinOrderId
   * @param originalFileName
   * @param fileBytes
   * @param documentType
   * @return
   * @throws Exception
   */
  public FileUploadResponse uploadFilesToPortinOrder(
      @NonNull String portinOrderId, String originalFileName, byte[] fileBytes, String documentType)
      throws Exception {
    MultipartBody.Part filePart =
        MultipartBody.Part.createFormData(
            "file",
            originalFileName,
            RequestBody.create(MediaType.parse("multipart/form-data"), fileBytes));
    Response<FileUploadResponse> response =
        bandwidthClientFactory
            .getBandwidthClient()
            .uploadFilesToPortinOrder(
                bandwidthClientFactory.generateBWToken(), portinOrderId, filePart)
            .execute();
    if (response.code() == 401) {
      throw new AuthenticationException(response.message());
    } else if (response.code() == 201) {
      FileUploadResponse fileUploadResponse = response.body();
      FileMetaData fileMetaData = new FileMetaData(documentType);
      Response<Void> metaDataResponse =
          bandwidthClientFactory
              .getBandwidthClient()
              .addMetaData(
                  bandwidthClientFactory.generateBWToken(),
                  portinOrderId,
                  fileUploadResponse.getFilename(),
                  fileMetaData)
              .execute();
      if (metaDataResponse.code() == 200) {
        fileUploadResponse.setFileMetaData(fileMetaData);
        return fileUploadResponse;
      } else {
        ErrorResponse errorResponse = new ErrorResponse();
        IrisStatus irisStatus = new IrisStatus();
        irisStatus.setCode("PE1000");
        irisStatus.setDescription(
            String.format("Unable to set metadata type for %s ", response.body().getFilename()));
        errorResponse.setIrisStatus(irisStatus);
        fileUploadResponse.setErrorResponse(errorResponse);
        return fileUploadResponse;
      }
    } else if (response.code() == 204) {
      return new FileUploadResponse();
    } else if (response.code() == 400 || response.code() == 404) {
      Converter<ResponseBody, FileUploadResponse> errorConverter =
          bandwidthClientFactory
              .getRetrofit()
              .responseBodyConverter(FileUploadResponse.class, new Annotation[0]);
      try {
        return errorConverter.convert(response.errorBody());
      } catch (IOException e) {
        logger.error("Exception in BandwidthClientService.uploadFilesToPortinOrder",e.getMessage());
        throw new BadRequestException(
            String.format("Error occurred while uploading the file %s :", e.getMessage()));
      }
    } else {
      throw new BadRequestException(
          String.format("Error occurred while uploading the file %s :", response.message()));
    }
  }

  /**
   * @param portinOrderId
   * @return
   * @throws Exception
   */
  public FileUploadResponse deleteFilefromPortinOrder(@NonNull String portinOrderId, String fileID)
      throws Exception {
    Response<FileUploadResponse> response =
        bandwidthClientFactory
            .getBandwidthClient()
            .deleteFilefromPortinOrder(
                bandwidthClientFactory.generateBWToken(), portinOrderId, fileID)
            .execute();
    if (response.code() == 401) {
      throw new AuthenticationException(response.message());
    } else if (response.code() == 200) {
      return response.body();
    } else if (response.code() == 204) {
      return new FileUploadResponse();
    } else if (response.code() == 400 || response.code() == 404) {
      Converter<ResponseBody, ErrorResponse> errorConverter =
          bandwidthClientFactory
              .getRetrofit()
              .responseBodyConverter(ErrorResponse.class, new Annotation[0]);
      try {
        ErrorResponse errorResponse = errorConverter.convert(response.errorBody());
        FileUploadResponse fileUploadResponse = new FileUploadResponse();
        fileUploadResponse.setErrorResponse(errorResponse);
        return fileUploadResponse;
      } catch (IOException e) {
        logger.error("Exception in BandwidthClientService.deleteFilefromPortinOrder",e.getMessage());
        throw new BadRequestException(
            String.format(
                "Error occurred while deleting file from Portin id  %s :", e.getMessage()));
      }
    } else {
      throw new BadRequestException(
          String.format(
              "Error occurred while deleting file from Portin id  %s :", response.message()));
    }
  }

  /**
   * @param portinOrderId
   * @throws Exception
   */
  public LnpOrderResponse deletePortinOrder(@NonNull String portinOrderId) throws Exception {
    Response<ResponseBody> response =
        bandwidthClientFactory
            .getBandwidthClient()
            .deletePortinOrder(bandwidthClientFactory.generateBWToken(), portinOrderId)
            .execute();
    if (response.code() == 401) {
      throw new AuthenticationException(response.message());
    } else if (response.code() == 200) {
      if (response.body().contentLength() == 0) {
        // Doing this because BW returns an empty response in case of 200
        // Setting the below custom response.
        LnpOrderResponse lnpOrderResponse = new LnpOrderResponse();
        lnpOrderResponse.setOrderId(portinOrderId);
        Status status = new Status();
        status.setCode(response.code());
        status.setDescription("Successfully deleted the Portin Order");
        lnpOrderResponse.setStatus(status);
        return lnpOrderResponse;
      }
      // Just in case in future if BW returns response
      Converter<ResponseBody, LnpOrderResponse> successResponseConverter =
          bandwidthClientFactory
              .getRetrofit()
              .responseBodyConverter(LnpOrderResponse.class, new Annotation[0]);
      try {
        return successResponseConverter.convert(response.body());
      } catch (IOException e) {
        logger.error("Exception in BandwidthClientService.deletePortinOrder",e.getMessage());
        throw new BadRequestException(
            String.format(
                "Error occurred while deleting portin order [%s], %s :",
                portinOrderId, e.getMessage()));
      }

    } else if (response.code() == 204) {
      return new LnpOrderResponse();
    } else if (response.code() == 400 || response.code() == 404) {
      Converter<ResponseBody, LnpOrderResponse> errorConverter =
          bandwidthClientFactory
              .getRetrofit()
              .responseBodyConverter(LnpOrderResponse.class, new Annotation[0]);
      try {
        return errorConverter.convert(response.errorBody());
      } catch (IOException e) {
        logger.error("Exception in BandwidthClientService.deletePortinOrder",e.getMessage());
        throw new BadRequestException(
            String.format(
                "Error occurred while deleting portin order [%s], %s :",
                portinOrderId, response.message()));
      }
    } else {
      throw new BadRequestException(
          String.format(
              "Error occurred while deleting portin order [%s], %s :",
              portinOrderId, response.message()));
    }
  }

  public BulkPortinResponse deleteBulkPortinOrder(@NonNull String bulkPortinOrderId)
      throws Exception {
    Response<ResponseBody> response =
        bandwidthClientFactory
            .getBandwidthClient()
            .deleteBulkPortinOrder(bandwidthClientFactory.generateBWToken(), bulkPortinOrderId)
            .execute();
    if (response.code() == 401) {
      throw new AuthenticationException(response.message());
    } else if (response.code() == 200) {
      if (response.body().contentLength() == 0) {
        // Doing this because BW returns an empty response in case of 200
        // Setting the below custom response.
        BulkPortinResponse bulkPortinResponse = new BulkPortinResponse();
        BulkPortin bulkPortin = new BulkPortin();
        bulkPortin.setOrderId(bulkPortinOrderId);
        Status status = new Status();
        status.setCode(response.code());
        status.setDescription("Successfully deleted the Bulk Portin Order");
        bulkPortin.setStatus(status);
        bulkPortinResponse.setBulkPortin(bulkPortin);
        return bulkPortinResponse;
      }
      // Just in case in future if BW returns response
      Converter<ResponseBody, BulkPortinResponse> successResponseConverter =
          bandwidthClientFactory
              .getRetrofit()
              .responseBodyConverter(BulkPortinResponse.class, new Annotation[0]);
      try {
        return successResponseConverter.convert(response.body());
      } catch (IOException e) {
        logger.error("Exception in BandwidthClientService.deleteBulkPortinOrder",e.getMessage());
        throw new BadRequestException(
            String.format(
                "Error occurred while deleting portin order [%s], %s :",
                bulkPortinOrderId, e.getMessage()));
      }

    } else if (response.code() == 204) {
      return new BulkPortinResponse();
    } else if (response.code() == 400 || response.code() == 404) {
      Converter<ResponseBody, BulkPortinResponse> errorConverter =
          bandwidthClientFactory
              .getRetrofit()
              .responseBodyConverter(BulkPortinResponse.class, new Annotation[0]);
      try {
        return errorConverter.convert(response.errorBody());
      } catch (IOException e) {
        logger.error("Exception in BandwidthClientService.deleteBulkPortinOrder",e.getMessage());
        throw new BadRequestException(
            String.format(
                "Error occurred while deleting portin order [%s], %s :",
                bulkPortinOrderId, response.message()));
      }
    } else {
      throw new BadRequestException(
          String.format(
              "Error occurred while deleting portin order [%s], %s :",
              bulkPortinOrderId, response.message()));
    }
  }

  /**
   * get Portin order history Details
   *
   * @param portinOrderId Portin order ID
   * @return OrderHistoryWrapper
   * @throws Exception
   */
  public OrderHistoryWrapper getPortinOrderHistoryDetails(@NonNull String portinOrderId)
      throws Exception {
    Response<OrderHistoryWrapper> response =
        bandwidthClientFactory
            .getBandwidthClient()
            .portinOrderHistory(bandwidthClientFactory.generateBWToken(), portinOrderId)
            .execute();

    if (response.code() == 401) {
      throw new AuthenticationException(response.message());
    } else if (response.code() == 200) {
      return response.body();
    } else if (response.code() == 204) {
      return new OrderHistoryWrapper();
    } else if (response.code() == 400 || response.code() == 404) {
      if (response.errorBody().contentLength() == 0) {

        // Doing this because BW returns an empty response in case of 404
        // Setting the below custom response.
        OrderHistoryWrapper orderHistoryWrapper = new OrderHistoryWrapper();
        IrisStatusForOrderHistoryWrapper irisStatus = new IrisStatusForOrderHistoryWrapper();
        irisStatus.setCode(response.code());
        irisStatus.setDescription("Invalid Portin Order id  " + portinOrderId);
        orderHistoryWrapper.setIrisStatus(irisStatus);
        return orderHistoryWrapper;
      }

      // Just in case in future if BW returns response
      Converter<ResponseBody, OrderHistoryWrapper> responseConverter =
          bandwidthClientFactory
              .getRetrofit()
              .responseBodyConverter(OrderHistoryWrapper.class, new Annotation[0]);
      try {
        return responseConverter.convert(response.errorBody());
      } catch (IOException e) {
        logger.error("Exception in BandwidthClientService.getPortinOrderHistoryDetails",e.getMessage());
        throw new BadRequestException(
            String.format(
                "Error occurred while deleting portin order [%s], %s :",
                portinOrderId, e.getMessage()));
      }

    } else {
      throw new BadRequestException(
          String.format(
              "Error occurred while deleting portin order [%s], %s :",
              portinOrderId, response.message()));
    }
  }
}
