package com.did.portin.model.bandwidth;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

@Root(strict = false)
@Element(name = "BulkPortinResponse")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BulkPortinResponse {

  @Element(name = "BulkPortin", required = false)
  BulkPortin bulkPortin;

  @Element(name = "ResponseStatus", required = false)
  private ResponseStatus responseStatus;

  public BulkPortin getBulkPortin() {
    return bulkPortin;
  }

  public void setBulkPortin(BulkPortin bulkPortin) {
    this.bulkPortin = bulkPortin;
  }

  public ResponseStatus getResponseStatus() {
    return responseStatus;
  }

  public void setResponseStatus(ResponseStatus responseStatus) {
    this.responseStatus = responseStatus;
  }
}
