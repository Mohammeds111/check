-- SQL TO CLEANUP DATABASE TABLES FOR DID PORTING --

-- Observed public schema is saving these database changelogs

UPDATE DATABASECHANGELOGLOCK SET LOCKED=FALSE, LOCKGRANTED=null, LOCKEDBY=null where ID=1;

DELETE FROM DATABASECHANGELOG WHERE id IN ('portin_questionnaire', 'insert_questionnaire_data', 'state', 'insert_state_data', 'access', 'did_process_lease', 'portin_event_type', 'portin_event', 'did_file_system', 'portin_request_status', 'insert_portin_request_status_data', 'portin_order_status', 'insert_portin_order_status_data', 'portin_file_type', 'insert_portin_file_type_data', 'portin_order_error_status_type', 'insert_portin_order_error_status_type_data', 'portin_request', 'portin_order', 'portin_precheck_answeres', 'portin_request_file', 'portin_order_error', 'email_notification_queue');

DROP TABLE IF EXISTS portin.portin_precheck_answeres;
DROP TABLE IF EXISTS portin.portin_request_file;
DROP TABLE IF EXISTS portin.portin_order_error;
DROP TABLE IF EXISTS portin.portin_order;
DROP TABLE IF EXISTS portin.email_notification_queue;

DROP TABLE IF EXISTS portin.portin_request;

DROP TABLE IF EXISTS portin.portin_questionnaire;
DROP TABLE IF EXISTS portin.portin_request_status;
DROP TABLE IF EXISTS portin.portin_file_type;

DROP TABLE IF EXISTS portin.access;
DROP TABLE IF EXISTS portin.did_process_lease;
DROP TABLE IF EXISTS portin.state;
DROP TABLE IF EXISTS portin.did_file_system;
DROP TABLE IF EXISTS portin.portin_event;
DROP TABLE IF EXISTS portin.portin_event_type;
DROP TABLE IF EXISTS portin.did_file_system;
DROP TABLE IF EXISTS portin.portin_order_status;
DROP TABLE IF EXISTS portin.portin_order_error_status_type;


-- Tables Clean up -- END ----------------------------------------
