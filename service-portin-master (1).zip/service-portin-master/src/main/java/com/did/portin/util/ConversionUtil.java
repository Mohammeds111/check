package com.did.portin.util;

import java.sql.Timestamp;
import java.text.ParseException;
import java.util.Date;
import java.util.Objects;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class ConversionUtil {
  public static final String BW_ORDER_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

  private static final Logger logger = LoggerFactory.getLogger(ConversionUtil.class);

  public static final String BW_EE_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss'Z'";

  public static Timestamp convertToTimestamp(String dateInString, String patternInString) {
    try {
      Date convertedDate = DateUtils.parseDate(dateInString, patternInString);
      return new Timestamp(convertedDate.getTime());
    } catch (ParseException e) {
      logger.error("Error in ConversionUtil",e);
    }
    return null;
  }

  public static Timestamp convertToTimestamp(String dateInString) {
    return convertToTimestamp(dateInString, BW_ORDER_DATE_FORMAT);
  }

  public static String convertToString(Timestamp dateInTS, String patternInString) {
    if( Objects.isNull(dateInTS)){
      return null;
    }
    return DateFormatUtils.format(dateInTS.getTime(), patternInString);
  }

  public static String convertToString(Timestamp dateInTS) {
    return convertToString(dateInTS, BW_ORDER_DATE_FORMAT);
  }

  public static String getCurrentDateInString() {
    return DateFormatUtils.format(new Date(), BW_ORDER_DATE_FORMAT);
  }
}
