package com.did.portin.model.bandwidth;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Root;

import java.util.List;

@Root(name = "LnpOrderResponse", strict = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LnpOrderResponse extends LnpOrderSuppAttributes {

  @Element(name = "PON", required = false)
  private String pon;

  @Element(name = "AccountId", required = false)
  private String accountId;

  @Element(name = "BulkPortinOrderId", required = false)
  private String bulkPortinOrderId;

  @Element(name = "EarliestEstimate", required = false)
  private String earliestEstimate;

  @Element(name = "LosingCarrierName", required = false)
  private String losingCarrierName;

  @Element(name = "LosingCarrierSPID", required = false)
  private String losingCarrierSPID;

  @Element(name = "LosingCarrierIsWireless", required = false)
  private String losingCarrierIsWireless;

  @Element(name = "VendorName", required = false)
  private String vendorName;

  @Element(name = "OrderCreateDate", required = false)
  private String orderCreateDate;

  @Element(name = "LastModifiedDate", required = false)
  private String lastModifiedDate;

  @Element(name = "userId", required = false)
  private String userId;

  @Element(name = "LastModifiedBy", required = false)
  private String lastModifiedBy;

  @Element(name = "PortType", required = false)
  private String portType;

  @Element(name = "ErrorResponse", required = false)
  private ErrorResponse errorResponse;

  @ElementList(name = "Errors", inline = true, required = false)
  private List<Errors> errors;

  @Element(name = "OrderId", required = false)
  private String OrderId;

  @Element(name = "Status", required = false)
  private Status Status;

  public String getOrderId() {
    return OrderId;
  }

  public void setOrderId(String orderId) {
    OrderId = orderId;
  }

  public Status getStatus() {
    return Status;
  }

  public void setStatus(Status status) {
    Status = status;
  }

  public String getPon() {
    return pon;
  }

  public void setPon(String pon) {
    this.pon = pon;
  }

  public String getAccountId() {
    return accountId;
  }

  public void setAccountId(String accountId) {
    this.accountId = accountId;
  }

  public String getBulkPortinOrderId() {
    return bulkPortinOrderId;
  }

  public void setBulkPortinOrderId(String bulkPortinOrderId) {
    this.bulkPortinOrderId = bulkPortinOrderId;
  }

  public String getEarliestEstimate() {
    return earliestEstimate;
  }

  public void setEarliestEstimate(String earliestEstimate) {
    this.earliestEstimate = earliestEstimate;
  }

  public String getLosingCarrierName() {
    return losingCarrierName;
  }

  public void setLosingCarrierName(String losingCarrierName) {
    this.losingCarrierName = losingCarrierName;
  }

  public String getLosingCarrierSPID() {
    return losingCarrierSPID;
  }

  public void setLosingCarrierSPID(String losingCarrierSPID) {
    this.losingCarrierSPID = losingCarrierSPID;
  }

  public String getLosingCarrierIsWireless() {
    return losingCarrierIsWireless;
  }

  public void setLosingCarrierIsWireless(String losingCarrierIsWireless) {
    this.losingCarrierIsWireless = losingCarrierIsWireless;
  }

  public String getVendorName() {
    return vendorName;
  }

  public void setVendorName(String vendorName) {
    this.vendorName = vendorName;
  }

  public String getOrderCreateDate() {
    return orderCreateDate;
  }

  public void setOrderCreateDate(String orderCreateDate) {
    this.orderCreateDate = orderCreateDate;
  }

  public String getLastModifiedDate() {
    return lastModifiedDate;
  }

  public void setLastModifiedDate(String lastModifiedDate) {
    this.lastModifiedDate = lastModifiedDate;
  }

  public String getUserId() {
    return userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }

  public String getLastModifiedBy() {
    return lastModifiedBy;
  }

  public void setLastModifiedBy(String lastModifiedBy) {
    this.lastModifiedBy = lastModifiedBy;
  }

  public String getPortType() {
    return portType;
  }

  public void setPortType(String portType) {
    this.portType = portType;
  }

  public ErrorResponse getErrorResponse() {
    return errorResponse;
  }

  public void setErrorResponse(ErrorResponse errorResponse) {
    this.errorResponse = errorResponse;
  }

  public List<Errors> getErrors() {
    return errors;
  }

  public void setErrors(List<Errors> errors) {
    this.errors = errors;
  }
}
