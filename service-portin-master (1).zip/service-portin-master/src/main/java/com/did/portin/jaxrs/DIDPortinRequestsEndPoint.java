package com.did.portin.jaxrs;

import com.did.portin.model.pagination.PaginatedRequest;
import com.did.portin.model.pagination.PaginatedResponse;
import com.did.portin.model.rest.PortinRequestDeletionResponse;
import com.did.portin.model.rest.PortinRequestFilter;
import com.did.portin.model.rest.PortinResponse;
import com.did.portin.model.rest.SearchPortinRequest;
import com.did.portin.model.sort.PortinRequestSortAttribute;
import com.did.portin.model.sort.Sorting;
import com.did.portin.service.PortinRequestService;
import com.did.portin.util.PaginationUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DIDPortinRequestsEndPoint {
  private static final Logger logger = LoggerFactory.getLogger(DIDPortinRequestsEndPoint.class);
  @Autowired PortinRequestService portinRequestService;

  // Method to Create portin request
  @PostMapping("/portin-request")
  public PortinResponse getCreatePortinRequest() {
    return PortinResponse.generateResponse("Ok", 0, portinRequestService.insertPortinRequest());
  }

  // Method to Search the portin request
  @PostMapping(
      value = "/portin-request/search",
      produces = "application/json",
      consumes = "application/json")
  public PortinResponse searchReturnPortin(@RequestBody SearchPortinRequest searchPortinRequest) {
    PaginatedRequest<PortinRequestFilter, PortinRequestSortAttribute> paginatedRequest =
        new PaginatedRequest<PortinRequestFilter, PortinRequestSortAttribute>()
            .withFilter(searchPortinRequest.getFilter())
            .withPagination(searchPortinRequest.getPagination())
            .withSorting(
                new Sorting<PortinRequestSortAttribute>()
                    .withDirection(searchPortinRequest.getFilter().getSortDirection())
                    .withAttribute(searchPortinRequest.getFilter().getSortBy()));

    PaginatedResponse paginatedResponse =
        PaginationUtil.createPaginatedResponse(
            portinRequestService.searchPortinRequests(paginatedRequest),
            searchPortinRequest.getPagination().getLimit(),
            searchPortinRequest.getPagination().getOffset());

    return PortinResponse.generateResponse(
        "Ok", 0, paginatedResponse.getData(), paginatedResponse.getPagination());
  }

  @DeleteMapping("/portin-request/{portinRequestId}")
  public PortinResponse deletePortinRequest(@PathVariable Long portinRequestId) throws Exception {
    PortinRequestDeletionResponse portinRequestDeletionResponse = null;
    portinRequestDeletionResponse = portinRequestService.deletePortinRequest(portinRequestId);
    return PortinResponse.generateResponse("Ok", 200, portinRequestDeletionResponse);
  }

  @ExceptionHandler(Exception.class)
  public ResponseEntity<String> handleException(Exception exception) throws JSONException {
    JSONObject response = new JSONObject();
    response.put("Error Message", exception.getMessage());
    logger.debug("Exception in DIDPortinRequestEndPoint:", exception.getMessage());
    return new ResponseEntity<String>(response.toString(), HttpStatus.BAD_REQUEST);
  }
}
