package com.did.portin.jaxrs;

import com.did.portin.model.bandwidth.BulkPortinRequest;
import com.did.portin.model.bandwidth.LnpOrderSupp;
import com.did.portin.model.bandwidth.NumberPortabilityRequest;
import com.did.portin.model.bandwidth.TnList;
import com.did.portin.model.rest.PortinResponse;
import com.did.portin.service.BandwidthClientService;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.inject.Inject;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

@RequestMapping("/bandwidth")
@RestController
public class BWEndpoint {
  // TODO: DELETE THIS FILE
  // This End point is just for testing the BW APIs developed.
  // We will get rid of this end point later.
  @Inject private BandwidthClientService bandwidthClientService;

  @GetMapping("/notes")
  @Produces(MediaType.APPLICATION_JSON_VALUE)
  public PortinResponse getNotes(@QueryParam("bwOrderId") String bwOrderId) throws Exception {
    System.out.println(bwOrderId);

    return PortinResponse.generateResponse("Ok", 0, bandwidthClientService.getNotes(bwOrderId));
  }

  @GetMapping("/loa-file-details")
  @Produces(MediaType.APPLICATION_JSON_VALUE)
  public PortinResponse getLOADetails(
      @QueryParam("bwOrderId") String bwOrderId, @QueryParam("metaData") String metaData)
      throws Exception {
    return PortinResponse.generateResponse(
        "Ok", 0, bandwidthClientService.getLOAFileDetails(bwOrderId, metaData));
  }

  @PostMapping("/bulkportins")
  @Produces(MediaType.APPLICATION_JSON_VALUE)
  public PortinResponse createBulkPortin(@RequestBody BulkPortinRequest bulkPortinRequest)
      throws Exception {
    return PortinResponse.generateResponse(
        "Ok", 0, bandwidthClientService.createBulkPortin(bulkPortinRequest));
  }

  /**
   * @param bwOrderId
   * @param tnList { "tnList" : ["1234567890"] }
   * @return PortinResponse
   * @throws Exception
   */
  @PutMapping("/submit-tn-list")
  @Produces(MediaType.APPLICATION_JSON_VALUE)
  public PortinResponse addTNsToBulkPortInOrder(
      @QueryParam("bwOrderId") String bwOrderId, @RequestBody TnList tnList) throws Exception {
    return PortinResponse.generateResponse(
        "Ok", 0, bandwidthClientService.addTNsToBulkPortInOrder(bwOrderId, tnList));
  }

  /**
   * @param bwOrderId
   * @return PortinResponse
   * @throws Exception
   */
  @GetMapping("/get-tn-list")
  @Produces(MediaType.APPLICATION_JSON_VALUE)
  public PortinResponse getTNsFromBulkPortInOrder(@QueryParam("bwOrderId") String bwOrderId)
      throws Exception {
    return PortinResponse.generateResponse(
        "Ok", 0, bandwidthClientService.getTNsFromBulkPortInOrder(bwOrderId));
  }

  /**
   * @param bwOrderId
   * @return PortinResponse
   * @throws Exception
   */
  @GetMapping("/get-portin-list")
  @Produces(MediaType.APPLICATION_JSON_VALUE)
  public PortinResponse getPortinListForBulkPortInOrder(@QueryParam("bwOrderId") String bwOrderId)
      throws Exception {
    return PortinResponse.generateResponse(
        "Ok", 0, bandwidthClientService.getPortinListForBulkPortInOrder(bwOrderId));
  }

  @PostMapping("/lnpchecker")
  @Produces(MediaType.APPLICATION_JSON_VALUE)
  public PortinResponse lnpchecker(
      @QueryParam("fullCheck ") String fullCheck,
      @RequestBody NumberPortabilityRequest numberPortabilityRequest)
      throws Exception {
    return PortinResponse.generateResponse(
        "Ok", 0, bandwidthClientService.lnpchecker(fullCheck, numberPortabilityRequest));
  }

  /**
   * @param portinOrderId
   * @return PortinResponse
   * @throws Exception
   */
  @GetMapping("/get-portin-order-details")
  @Produces(MediaType.APPLICATION_JSON_VALUE)
  public PortinResponse getPortinOrderDetails(@QueryParam("portinOrderId") String portinOrderId)
      throws Exception {
    return PortinResponse.generateResponse(
        "Ok", 0, bandwidthClientService.getPortinOrderDetails(portinOrderId));
  }

  @PutMapping("/supp-portin-order")
  @Produces(MediaType.APPLICATION_JSON_VALUE)
  public PortinResponse suppPortinOrder(
      @QueryParam("portinOrderId") String portinOrderId, @RequestBody LnpOrderSupp lnpOrderSupp)
      throws Exception {
    return PortinResponse.generateResponse(
        "Ok", 0, bandwidthClientService.suppPortinOrder(portinOrderId, lnpOrderSupp));
  }

  /**
   * @param portinOrderId
   * @param documentType
   * @param file
   * @return PortinResponse
   * @throws Exception
   */
  @PostMapping("/loa-file-upload")
  @Produces(MediaType.APPLICATION_JSON_VALUE)
  public PortinResponse uploadDocuments(
      @QueryParam("portinOrderId") String portinOrderId,
      @QueryParam("documentType") String documentType,
      @RequestParam("file") MultipartFile file)
      throws Exception {
    return PortinResponse.generateResponse(
        "Ok",
        0,
        bandwidthClientService.uploadFilesToPortinOrder(
            portinOrderId, file.getOriginalFilename(), file.getBytes(), documentType));
  }

  /**
   * @param portinOrderId
   * @param fileID
   * @return PortinResponse
   * @throws Exception
   */
  @DeleteMapping("/loa-file-delete")
  @Produces(MediaType.APPLICATION_JSON_VALUE)
  public PortinResponse deleteDocuments(
      @QueryParam("portinOrderId") String portinOrderId, @QueryParam("fileID") String fileID)
      throws Exception {
    return PortinResponse.generateResponse(
        "Ok", 0, bandwidthClientService.deleteFilefromPortinOrder(portinOrderId, fileID));
  }

  /**
   * @param portinOrderId
   * @throws Exception
   */
  @DeleteMapping("/delete-port-order")
  @Produces(MediaType.APPLICATION_JSON_VALUE)
  public PortinResponse deletePortOrder(@QueryParam("portinOrderId") String portinOrderId)
      throws Exception {
    return PortinResponse.generateResponse(
        "Ok", 0, bandwidthClientService.deletePortinOrder(portinOrderId));
  }

  /**
   * @param bulkPortinOrderId
   * @return
   * @throws Exception
   */
  @DeleteMapping("/delete-bulk-port-order")
  @Produces(MediaType.APPLICATION_JSON_VALUE)
  public PortinResponse deleteBulkPortOrder(
      @QueryParam("bulkPortinOrderId") String bulkPortinOrderId) throws Exception {
    return PortinResponse.generateResponse(
        "Ok", 0, bandwidthClientService.deleteBulkPortinOrder(bulkPortinOrderId));
  }

  /**
   * Get portin order history details
   * @param portinOrderId
   * @return PortinResponse
   * @throws Exception
   */
  @GetMapping("/get-portin-order-history")
  @Produces(MediaType.APPLICATION_JSON_VALUE)
  public PortinResponse getPortinOrderHistory(@QueryParam("portinOrderId") String portinOrderId)
      throws Exception {
    return PortinResponse.generateResponse(
        "Ok", 0, bandwidthClientService.getPortinOrderHistoryDetails(portinOrderId));
  }
}
