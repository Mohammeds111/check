package com.did.portin.model.sort;

public enum PortinRequestSortAttribute  implements SortAttribute {
    // sort candidates for Portin Request Table
    PORTIN_REQUEST_ID("portin_request_id"),
    PORTIN_EXTERNAL_REQUEST_ID("portin_external_request_id"),
    REQUESTED_DATE("requested_date"),
    ORGANIZATION("organization"),
    ORGANIZATION_NAME("organization_name");

    private String dbColumnName;

    PortinRequestSortAttribute(String dbColumnName) {
        this.dbColumnName = dbColumnName;
    }

    @Override
    public String getColumnName() {
        return this.dbColumnName;
    }
}
