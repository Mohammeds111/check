package com.did.portin.model.bandwidth;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Root;

import java.util.List;

@Root(name = "PortabilityErrors", strict = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PortabilityErrors {

  @ElementList(entry = "Error", inline = true, required = false)
  private List<Error> errors;

  public List<Error> getErrors() {
    return errors;
  }

  public void setErrors(List<Error> errors) {
    this.errors = errors;
  }
}
