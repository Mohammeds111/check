package com.did.portin.model.rest;

public class PortinFileRespose {
  private long portinRequestFileId;
  private long portinRequestId;
  private long portinOrderId;
  private int portinFileType;
  private long fileId;
  private String fileName;
  private String externalApiFileName;
  private String fileUri;
  private String createdDate;
  private String signedDate;

  public String getSignedDate() {
    return signedDate;
  }

  public void setSignedDate(String signedDate) {
    this.signedDate = signedDate;
  }

  public long getPortinRequestFileId() {
    return portinRequestFileId;
  }

  public void setPortinRequestFileId(long portinRequestFileId) {
    this.portinRequestFileId = portinRequestFileId;
  }

  public long getPortinRequestId() {
    return portinRequestId;
  }

  public void setPortinRequestId(long portinRequestId) {
    this.portinRequestId = portinRequestId;
  }

  public long getPortinOrderId() {
    return portinOrderId;
  }

  public void setPortinOrderId(long portinOrderId) {
    this.portinOrderId = portinOrderId;
  }

  public int getPortinFileType() {
    return portinFileType;
  }

  public void setPortinFileType(int portinFileType) {
    this.portinFileType = portinFileType;
  }

  public long getFileId() {
    return fileId;
  }

  public void setFileId(long fileId) {
    this.fileId = fileId;
  }

  public String getFileName() {
    return fileName;
  }

  public void setFileName(String fileName) {
    this.fileName = fileName;
  }

  public String getFileUri() {
    return fileUri;
  }

  public void setFileUri(String fileUri) {
    this.fileUri = fileUri;
  }

  public String getCreatedDate() {
    return createdDate;
  }

  public void setCreatedDate(String createdDate) {
    this.createdDate = createdDate;
  }

  public String getExternalApiFileName() {
    return externalApiFileName;
  }

  public void setExternalApiFileName(String externalApiFileName) {
    this.externalApiFileName = externalApiFileName;
  }
}
