# DID Porting API

## Overview

The DID Porting API is a REST based micro service used by end users of the Hub portal to order porting. This microservice will interact with Bandwidth API to submit the porting requests inturn. The data transport between the API and Bandwidth is done via Bandwidth web services.

The micro service is built off the following tech:

 - Java Discover SDK for Consul/Vault application configuration 
 - Undertow for HTTP container  (TBD)
 - RestEasy + JAX-RS for the REST container 
 - JWT SDK for JWT token generation (TBD)
 - Liquidbase for schema changes and MyBatis for SQL
 - Spring for IOC

The application is meant to be ran: 
- In a Docker container
- On AWS Elastic Beanstalk
- Against its own Postgres AWS RDS database

## External Dependencies

The porting app depends on the following:
- Bandwidth API for porting requests and orders
- Gmail for sending emails to customers
- Consul/Vault for configuration



## Project Components

The project is structure like our newest beanstalk applications. The following are noteworthy folders and classes:

- **com.did.portin.Main**: The Main class for the application. This is the class that's executed when running the executable jar.
- **src/main/resources/db**: The folder where you'll find the liquidbase changeset.
- **src/main/resources/spring**: The folder where you'll find the various Spring config files. Note that we mostly use autowiring using @Named and @Inject. However, the app requires some minimum configuration that isn't done via autowiring.
- **eb**: The folder that will contain the Elasticbeanstalk configuration
- **kv/data/file**: The folder containing the Discovery configuration when running in file based discover. (i.e. Mocked Consul). This is what developers would normally use for their discovery configuration.
- **kv/data/consul/kv**: The folder containing the KV that will be pushed to the various Consul clusters.

## Setup and Running the application

Before staring the application, you'll need a Postgres instance in docker. The project contains a simple Docker compose file that will create you one.

You can start the Postgres instance by running:
    
    c:/> cd <projectdir>/service-portin/src/main/resources/docker
    docker-compose -f docker-postrgres-env-setup.yml up -d

The compose will create an instance with name **portin-db**, with name volume **portin-postgres-data**. It'll be exposed through port **5492**. The username is **portin** and the passwords is **portin**.

To run the application, you'll need to run the Main class (from your IDE) with the following parameters:

- create a folder C:\projects\codebase\portin-service-ws
- Open Git Bash and run following commands

```bash
git clone https://git.virtusa.com/poc_projects/service-portin.git
git fetch
git branch <branch_name> (e.g: git branch feature/story-submit-bulkportin)
git checkout <branch_name>
git branch (to verify that you are pointing to correct branch)
```
## Import the code into IDE

Open the intelliJ... if this is the first time you are doing this
* Select 'Import Project'
* Pick the pom.xml under the checked out code
* The code will be imported as maven project.

## Build code

To build the code in command line, run the following command.

```bash
mvn clean install

```

- Configure java application to run in IDE's edit configuration
```bash
com.did.portin.DIDPortinMain
```
	
- Use the VM options -Xmx2048m


You can verify that the API is up and running by hitting it's health endpoint:

    curl -X GET http://localhost:8080/health -H 'content-type: application/json'

You should get the following response:

    {"msg":"ok","status":0}

For any user bound endpoint, you'd need to provide a Warden token as the following:

    curl -X GET \
      http://localhost:8080/portin-questions \
      -H 'content-type: application/json'

