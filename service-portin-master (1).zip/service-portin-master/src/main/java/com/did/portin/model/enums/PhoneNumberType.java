package com.did.portin.model.enums;

public enum PhoneNumberType {

    // Phone number type candidates
    WIRED("wired"),
    WIRELESS("wireless"),
    TOLLFREE("tollfree");

    private String phoneNumberType;

    PhoneNumberType(String phoneNumberType) {
        this.phoneNumberType = phoneNumberType;
    }

    public String getPhoneNumberType() {
        return this.phoneNumberType;
    }

    public static PhoneNumberType getPhoneNumberTypeFromName(String phoneNumberTypeName) {
        for (PhoneNumberType phNbrType : PhoneNumberType.values()) {
            if (phNbrType.name().equalsIgnoreCase(phoneNumberTypeName)) {
                return phNbrType;
            }
        }

        return null;
    }
}