package com.did.portin.util;

import com.did.portin.model.pagination.PagedResult;
import com.did.portin.model.pagination.PaginatedResponse;
import com.did.portin.model.pagination.Pagination;

public class PaginationUtil {
    public PaginationUtil() {
    }

    public static <T> PaginatedResponse<T> createPaginatedResponse(PagedResult<T> r, int limit, int offset) {
        return (new PaginatedResponse()).withData(r.getEntities()).withPagination((new Pagination()).withLimit(limit).withOffset(offset).withTotal(r.getRowCount()));
    }
}
