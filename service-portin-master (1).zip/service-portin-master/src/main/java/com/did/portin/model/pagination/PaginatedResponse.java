package com.did.portin.model.pagination;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class PaginatedResponse<R> {
    private List<R> data = new ArrayList();
    private Pagination pagination;

    public PaginatedResponse() {
    }

    public List<R> getData() {
        return this.data;
    }

    public void setData(List<R> data) {
        this.data = data;
    }

    public Pagination getPagination() {
        return this.pagination;
    }

    public void setPagination(Pagination pagination) {
        this.pagination = pagination;
    }

    public PaginatedResponse<R> withData(List<R> data) {
        this.data = data;
        return this;
    }

    public PaginatedResponse<R> withPagination(Pagination pagination) {
        this.pagination = pagination;
        return this;
    }

    public void paginate() {
        this.data = (List)this.data.stream().skip((long)this.pagination.getOffset()).limit((long)this.pagination.getLimit()).collect(Collectors.toList());
    }
}
