package com.did.portin.model.bandwidth;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

@Root(name = "fileUploadResponse", strict = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class FileUploadResponse {
  @Element(name = "filename", required = false)
  private String filename;

  @Element(name = "resultCode", required = false)
  private String resultCode;

  @Element(name = "resultMessage", required = false)
  private String resultMessage;

  @Element(name = "fileMetaData", required = false)
  private FileMetaData fileMetaData;

  @Element(name = "ErrorResponse", required = false)
  private ErrorResponse errorResponse;

  public FileMetaData getFileMetaData() {
    return fileMetaData;
  }

  public void setFileMetaData(FileMetaData fileMetaData) {
    this.fileMetaData = fileMetaData;
  }

  public ErrorResponse getErrorResponse() {
    return errorResponse;
  }

  public void setErrorResponse(ErrorResponse errorResponse) {
    this.errorResponse = errorResponse;
  }

  public String getFilename() {
    return filename;
  }

  public void setFilename(String filename) {
    this.filename = filename;
  }

  public String getResultCode() {
    return resultCode;
  }

  public void setResultCode(String resultCode) {
    this.resultCode = resultCode;
  }

  public String getResultMessage() {
    return resultMessage;
  }

  public void setResultMessage(String resultMessage) {
    this.resultMessage = resultMessage;
  }
}
