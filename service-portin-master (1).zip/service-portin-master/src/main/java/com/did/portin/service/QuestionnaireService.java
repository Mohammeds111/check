package com.did.portin.service;

import com.did.portin.model.db.Questionnaire;
import com.did.portin.mybatis.QuestionnaireMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class QuestionnaireService {

  @Autowired private QuestionnaireMapper questionnaireMapper;

  public List<Questionnaire> getQuestions() {
    return questionnaireMapper.getPrecheckQuestionnaire();
  }
}
