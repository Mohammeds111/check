package com.did.portin.model.bandwidth;

import org.simpleframework.xml.Root;

@Root(name = "NonPortableTnList", strict = false)
public class NonPortableTnList extends TNs {}
