package com.did.portin.jaxrs;

import com.did.portin.model.rest.PortinResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DIDHealthEndpoint {

  @RequestMapping("/health")
  public PortinResponse getHealth() {
    return PortinResponse.generateResponse("Ok", 0, "Portin Service is healthy");
  }
}
