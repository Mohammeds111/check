package com.did.portin.model.rest;

import com.did.portin.model.pagination.Pagination;

public class SearchPortinRequest {
    private PortinRequestFilter filter;
    private Pagination pagination;

    public PortinRequestFilter getFilter() {
        return filter;
    }

    public void setFilter(PortinRequestFilter filter) {
        this.filter = filter;
    }

    public Pagination getPagination() {
        return pagination;
    }

    public void setPagination(Pagination pagination) {
        this.pagination = pagination;
    }
}
