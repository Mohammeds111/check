package com.did.portin.mybatis;

import com.did.portin.model.db.PortinOrder;
import com.did.portin.model.db.PortinOrderError;
import com.did.portin.model.rest.PortinOrderFilter;
import com.did.portin.model.rest.PortinOrderResponse;
import java.util.List;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Many;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

@Mapper
public interface PortinOrderMapper {
    public static String PORTINORDER_SEARCH_WHERE_FILTER =
            "  order_status IN (<foreach collection='criteria.statuses' item='status' separator=','>#{status}</foreach>) "
                    + "<if test='criteria.q != null'>"
                    + "  AND "
                    + "  (portin_customer_order_id ILIKE #{criteria.q} "
                    + "  OR "
                    + "  loc_carrier_name ILIKE #{criteria.q} "
                    + "  OR "
                    + "  rate_center ILIKE #{criteria.q} "
                    + "  OR "
                    + "  billing_telephone_number ILIKE #{criteria.q} "
                    + "  OR "
                    + "  modified_user_fullname ILIKE #{criteria.q} "
                    + "  OR "
                    + "  to_char(order_status, '9999999999') ILIKE #{criteria.q} "
                    + "  OR "
                    + "  to_char(requested_quantity, '9999999999') ILIKE #{criteria.q} "
                    + "  OR "
                    + "  to_char(order_date, 'YYYY-MON-DD HH24:MI:SS.MS-TZ') ILIKE #{criteria.q} "
                    + "  OR "
                    + "  to_char(requested_activation_date, 'YYYY-MON-DD HH24:MI:SS.MS-TZ') ILIKE #{criteria.q} "
                    + "  ) "
                    + "</if>"
                    + "<if test='criteria.organization != null'>"
                    + " AND "
                    + "  (organization_code ILIKE #{criteria.organization} "
                    + "   OR organization_name ILIKE #{criteria.organization}) "
                    + "</if>"
                    + "<if test='criteria.portinRequestId != null'>"
                    + " AND "
                    + " portin_request_id = #{criteria.portinRequestId} "
                    + "</if>";


    public static final String PORTIN_CUSTOMER_ORDER_ID =
            " CONCAT( "
                    + "'PORTORDER',"
                    + "TO_CHAR(current_timestamp, 'YYYYMMDD'), "
                    + "'-', "
                    + "LPAD( currval(pg_get_serial_sequence('portin.portin_order', 'portin_order_id'))::text, 10, '0') "
                    + "), ";

    @Insert({
            "INSERT INTO portin.portin_order("
                    + "portin_customer_order_id, "
                    + "portin_request_id, "
                    + "portin_external_system_order_id, "
                    + "alternate_spid, "
                    + "billing_telephone_number, "
                    + "replacement_billing_telephone_number, "
                    + "user_account_type, "
                    + "user_companyname, "
                    + "authorized_username, "
                    + "user_firstname, "
                    + "user_middleinitial, "
                    + "user_lastname, "
                    + "address_streetnumber, "
                    + "address_streetname, "
                    + "address_Housenumber, "
                    + "address_addressline2, "
                    + "address_city, "
                    + "address_state, "
                    + "address_zip, "
                    + "address_zip4, "
                    + "address_country, "
                    + "loa_authorizing_person, "
                    + "lc_accountnumber, "
                    + "lc_pinnumber, "
                    + "phone_numbers, "
                    + "phone_number_type, "
                    + "portin_type, "
                    + "partial_portin, "
                    + "loa_uploaded, "
                    + "csr_uploaded, "
                    + "loa_required, "
                    + "suggested_activation_date, "
                    + "requested_activation_date, "
                    + "requested_quantity, "
                    + "order_status, "
                    + "triggered, "
                    + "order_date, "
                    + "vendor_name, "
                    + "rate_center,"
                    + "loc_carrier_spid, "
                    + "loc_carrier_name, "
                    + "loc_carrier_iswireless, "
                    + "loc_carrier_accountnumberrequired, "
                    + "loc_carrier_minimumportinginterval, "
                    + "organization_code, "
                    + "organization_name, "
                    + "requested_user_id, "
                    + "requested_user_email, "
                    + "requested_user_fullname, "
                    + "requested_user_code, "
                    + "modified_date, "
                    + "modified_user_id, "
                    + "modified_user_email, "
                    + "modified_user_fullname, "
                    + "modified_user_code, "
                    + "completed_date, "
                    + "completed_user_id, "
                    + "completed_user_email, "
                    + "completed_user_fullname, "
                    + "completed_user_code, "
                    + "notes "
                    + ") "
                    + "VALUES "
                    + "("
                    + PORTIN_CUSTOMER_ORDER_ID
                    + "#{portinOrder.portinRequestId},"
                    + "#{portinOrder.portinExternalSystemOrderId},"
                    + "#{portinOrder.alternateSpid},"
                    + "#{portinOrder.billingTelephoneNumber},"
                    + "#{portinOrder.replacementBillingTelephoneNumber},"
                    + "#{portinOrder.userAccountType},"
                    + "#{portinOrder.userCompanyname},"
                    + "#{portinOrder.authorizedUsername},"
                    + "#{portinOrder.userFirstname},"
                    + "#{portinOrder.userMiddleinitial},"
                    + "#{portinOrder.userLastname},"
                    + "#{portinOrder.addressStreetnumber},"
                    + "#{portinOrder.addressStreetname},"
                    + "#{portinOrder.addressHousenumber},"
                    + "#{portinOrder.addressAddressline2},"
                    + "#{portinOrder.addressCity},"
                    + "#{portinOrder.addressState},"
                    + "#{portinOrder.addressZip},"
                    + "#{portinOrder.addressZip4},"
                    + "#{portinOrder.addressCountry},"
                    + "#{portinOrder.loaAuthorizingPerson},"
                    + "#{portinOrder.lcAccountnumber},"
                    + "#{portinOrder.lcPinnumber},"
                    + "#{portinOrder.phoneNumbers},"
                    + "#{portinOrder.phoneNumberType},"
                    + "#{portinOrder.portinType},"
                    + "#{portinOrder.partialPortin},"
                    + "#{portinOrder.loaUploaded},"
                    + "#{portinOrder.csrUploaded},"
                    + "#{portinOrder.loaRequired},"
                    + "#{portinOrder.suggestedActivationDate},"
                    + "#{portinOrder.requestedActivationDate},"
                    + "#{portinOrder.requestedQuantity},"
                    + "#{portinOrder.orderStatus},"
                    + "#{portinOrder.triggered},"
                    + "#{portinOrder.orderDate},"
                    + "#{portinOrder.vendorName},"
                    + "#{portinOrder.rateCenter},"
                    + "#{portinOrder.locCarrierSpid},"
                    + "#{portinOrder.locCarrierName},"
                    + "#{portinOrder.locCarrierIswireless},"
                    + "#{portinOrder.locCarrierAccountnumberrequired},"
                    + "#{portinOrder.locCarrierMinimumportinginterval},"
                    + "#{portinOrder.organizationCode},"
                    + "#{portinOrder.organizationName},"
                    + "#{portinOrder.requestedUserId},"
                    + "#{portinOrder.requestedUserEmail},"
                    + "#{portinOrder.requestedUserFullName},"
                    + "#{portinOrder.requestedUserCode},"
                    + "#{portinOrder.modifiedDate},"
                    + "#{portinOrder.modifiedUserId},"
                    + "#{portinOrder.modifiedUserEmail},"
                    + "#{portinOrder.modifiedUserFullName},"
                    + "#{portinOrder.modifiedUserCode},"
                    + "#{portinOrder.completedDate},"
                    + "#{portinOrder.completedUserId},"
                    + "#{portinOrder.completedUserEmail},"
                    + "#{portinOrder.completedUserFullName},"
                    + "#{portinOrder.completedUserCode},"
                    + "#{portinOrder.notes} "
                    + ") RETURNING portin_order_id, portin_customer_order_id"
    })
    @Options(
            useGeneratedKeys = true,
            keyProperty =
                    "portinOrder.portinOrderId,portinOrder.portinCustomerOrderId",
            keyColumn = "portin_order_id,portin_customer_order_id")
    public Long insertPortinOrder(
            @Param("portinOrder") PortinOrder portinOrder);

    @Select("<script> "
            + "SELECT "
                    + "portin_order_id, "
                    + "portin_request_id, "
                    + "portin_customer_order_id, "
                    + "portin_external_system_order_id, "
                    + "alternate_spid, "
                    + "billing_telephone_number, "
                    + "replacement_billing_telephone_number, "
                    + "user_account_type, "
                    + "user_companyname, "
                    + "authorized_username, "
                    + "user_firstname, "
                    + "user_middleinitial, "
                    + "user_lastname, "
                    + "address_streetnumber, "
                    + "address_streetname, "
                    + "address_housenumber, "
                    + "address_addressline2, "
                    + "address_city, "
                    + "address_state, "
                    + "address_zip, "
                    + "address_zip4, "
                    + "address_country, "
                    + "loa_authorizing_person, "
                    + "lc_accountnumber, "
                    + "lc_pinnumber, "
                    + "phone_numbers, "
                    + "phone_number_type, "
                    + "portin_type, "
                    + "partial_portin, "
                    + "loa_uploaded, "
                    + "csr_uploaded, "
                    + "loa_required, "
                    + "suggested_activation_date, "
                    + "requested_activation_date, "
                    + "requested_quantity, "
                    + "order_status, "
                    + "external_api_update_status_code, "
                    + "external_api_update_status_description, "
                    + "triggered, "
                    + "order_date, "
                    + "vendor_name, "
                    + "rate_center,"
                    + "loc_carrier_spid, "
                    + "loc_carrier_name, "
                    + "loc_carrier_iswireless, "
                    + "loc_carrier_accountnumberrequired, "
                    + "loc_carrier_minimumportinginterval, "
                    + "organization_code, "
                    + "organization_name, "
                    + "requested_user_id, "
                    + "requested_user_email, "
                    + "requested_user_fullname, "
                    + "requested_user_code, "
                    + "modified_date, "
                    + "modified_user_id, "
                    + "modified_user_email, "
                    + "modified_user_fullname, "
                    + "modified_user_code, "
                    + "completed_date, "
                    + "completed_user_id, "
                    + "completed_user_email, "
                    + "completed_user_fullname, "
                    + "completed_user_code, "
                    + "notes "
                    + "FROM "
                    + "portin.portin_order "
                    + "WHERE "
                    + "portin_request_id = #{portinRequestId} "
                    + "<if test='portinOrderId != null'>"
                    + " AND "
                    + " portin_order_id = #{portinOrderId} "
                    + "</if>"
                    + "<if test='openOrdersOnly'>"
                    + " AND "
                    + " order_status IN (0, 1, 3) "
                    + "</if>"
                    + "</script>")
    @Results({
            @Result(property = "portinOrder.portinOrderId", column = "portin_order_id"),
            @Result(property = "portinOrder.portinRequestId", column = "portin_request_id"),
            @Result(property = "portinOrder.portinCustomerOrderId", column="portin_customer_order_id"),
            @Result(property = "portinOrder.portinExternalSystemOrderId", column = "portin_external_system_order_id"),
            @Result(property = "portinOrder.alternateSpid", column = "alternate_spid"),
            @Result(property = "portinOrder.billingTelephoneNumber", column = "billing_telephone_number"),
            @Result(property = "portinOrder.replacementBillingTelephoneNumber", column = "replacement_billing_telephone_number"),
            @Result(property = "portinOrder.userAccountType", column = "user_account_type"),
            @Result(property = "portinOrder.userCompanyname", column = "user_companyname"),
            @Result(property = "portinOrder.authorizedUsername", column = "authorized_username"),
            @Result(property = "portinOrder.userFirstname", column = "user_firstname"),
            @Result(property = "portinOrder.userMiddleinitial", column = "user_middleinitial"),
            @Result(property = "portinOrder.userLastname", column = "user_lastname"),
            @Result(property = "portinOrder.addressStreetnumber", column = "address_streetnumber"),
            @Result(property = "portinOrder.addressStreetname", column = "address_streetname"),
            @Result(property = "portinOrder.addressHousenumber", column = "address_housenumber"),
            @Result(property = "portinOrder.addressAddressline2", column = "address_addressline2"),
            @Result(property = "portinOrder.addressCity", column = "address_city"),
            @Result(property = "portinOrder.addressState", column = "address_state"),
            @Result(property = "portinOrder.addressZip", column = "address_zip"),
            @Result(property = "portinOrder.addressZip4", column = "address_zip4"),
            @Result(property = "portinOrder.addressCountry", column = "address_country"),
            @Result(property = "portinOrder.loaAuthorizingPerson", column = "loa_authorizing_person"),
            @Result(property = "portinOrder.lcAccountnumber", column = "lc_accountnumber"),
            @Result(property = "portinOrder.lcPinnumber", column = "lc_pinnumber"),
            @Result(property = "portinOrder.phoneNumbers", column = "phone_numbers"),
            @Result(property = "portinOrder.phoneNumberType", column = "phone_number_type"),
            @Result(property = "portinOrder.portinType", column = "portin_type"),
            @Result(property = "portinOrder.partialPortin", column = "partial_portin"),
            @Result(property = "portinOrder.loaUploaded", column = "loa_uploaded"),
            @Result(property = "portinOrder.csrUploaded", column = "csr_uploaded"),
            @Result(property = "portinOrder.loaRequired", column = "loa_required"),
            @Result(property = "portinOrder.suggestedActivationDate", column = "suggested_activation_date"),
            @Result(property = "portinOrder.requestedActivationDate", column = "requested_activation_date"),
            @Result(property = "portinOrder.requestedQuantity", column = "requested_quantity"),
            @Result(property = "portinOrder.orderStatus", column = "order_status"),
            @Result(property = "portinOrder.externalApiUpdateStatusCode", column = "external_api_update_status_code"),
            @Result(property = "portinOrder.externalApiUpdateStatusDescription", column = "external_api_update_status_description"),
            @Result(property = "portinOrder.triggered", column = "triggered"),
            @Result(property = "portinOrder.orderDate", column = "order_date"),
            @Result(property = "portinOrder.vendorName", column = "vendor_name"),
            @Result(property = "portinOrder.rateCenter", column = "rate_center"),
            @Result(property = "portinOrder.locCarrierSpid", column = "loc_carrier_spid"),
            @Result(property = "portinOrder.locCarrierName", column = "loc_carrier_name"),
            @Result(property = "portinOrder.locCarrierIswireless", column = "loc_carrier_iswireless"),
            @Result(property = "portinOrder.locCarrierAccountnumberrequired", column = "loc_carrier_accountnumberrequired"),
            @Result(property = "portinOrder.locCarrierMinimumportinginterval", column = "loc_carrier_minimumportinginterval"),
            @Result(property = "portinOrder.organizationCode", column = "organization_code"),
            @Result(property = "portinOrder.organizationName", column = "organization_name"),
            @Result(property = "portinOrder.requestedUserId", column = "requested_user_id"),
            @Result(property = "portinOrder.requestedUserEmail", column = "requested_user_email"),
            @Result(property = "portinOrder.requestedUserFullName", column = "requested_user_fullname"),
            @Result(property = "portinOrder.requestedUserCode", column = "requested_user_code"),
            @Result(property = "portinOrder.modifiedDate", column = "modified_date"),
            @Result(property = "portinOrder.modifiedUserId", column = "modified_user_id"),
            @Result(property = "portinOrder.modifiedUserEmail", column = "modified_user_email"),
            @Result(property = "portinOrder.modifiedUserFullName", column = "modified_user_fullname"),
            @Result(property = "portinOrder.modifiedUserCode", column = "modified_user_code"),
            @Result(property = "portinOrder.completedDate", column = "completed_date"),
            @Result(property = "portinOrder.completedUserId", column = "completed_user_id"),
            @Result(property = "portinOrder.completedUserEmail", column = "completed_user_email"),
            @Result(property = "portinOrder.completedUserFullName", column = "completed_user_fullname"),
            @Result(property = "portinOrder.completedUserCode", column = "completed_user_code"),
            @Result(property = "portinOrder.notes", column = "notes"),
            @Result(property = "portinOrderErrors", javaType=List.class, column = "portin_order_id", many=@Many(select="getOpenPortinOrderErrors"))
    })
    public List<PortinOrderResponse> getPortinOrdersByRequestId(@Param("portinRequestId") Long portinRequestId,
                                                                @Param("portinOrderId") Long portinOrderId,
                                                                @Param("openOrdersOnly") boolean openOrdersOnly);

    @Select(
            "SELECT "
                    + "portin_order_id, "
                    + "portin_request_id, "
                    + "portin_customer_order_id, "
                    + "portin_external_system_order_id, "
                    + "order_status "
                    + "FROM "
                    + "portin.portin_order "
                    + "WHERE "
                    + "portin_request_id = #{portinRequestId} "
                    + " AND "
                    + " order_status < 2 ")
    @Results({
            @Result(property = "portinOrderId", column = "portin_order_id"),
            @Result(property = "portinRequestId", column = "portin_request_id"),
            @Result(property = "portinCustomerOrderId", column = "portin_customer_order_id"),
            @Result(property = "portinExternalSystemOrderId", column = "portin_external_system_order_id"),
            @Result(property = "orderStatus", column = "order_status")
    })
    public List<PortinOrder> getNonSubmitPortinOrders(@Param("portinRequestId") Long portinRequestId);

    @Select(
            "SELECT "
                    + "portin_order_error_id, "
                    + "portin_request_id, "
                    + "portin_order_id, "
                    + "error_code, "
                    + "error_description, "
                    + "error_status, "
                    + "created_date "
                    + "FROM "
                    + "portin.portin_order_error "
                    + "WHERE "
                    + "portin_order_id = #{portinOrderId} "
                    + " AND "
                    + " error_status = 0 ")
    @Results({
            @Result(property = "portinOrderErrorId", column = "portin_order_error_id"),
            @Result(property = "portinRequestId", column = "portin_request_id"),
            @Result(property = "portinOrderId", column = "portin_order_id"),
            @Result(property = "errorCode", column = "error_code"),
            @Result(property = "errorDescription", column = "error_description"),
            @Result(property = "errorStatus", column = "error_status"),
            @Result(property = "createdDate", column = "created_date")
    })
    public List<PortinOrderError> getOpenPortinOrderErrors(
            @Param("portinOrderId") Long portinOrderId);

    @Select(
            "SELECT "
                    + "portin_order_id, "
                    + "portin_request_id, "
                    + "portin_customer_order_id, "
                    + "portin_external_system_order_id, "
                    + "alternate_spid, "
                    + "billing_telephone_number, "
                    + "replacement_billing_telephone_number, "
                    + "user_account_type, "
                    + "user_companyname, "
                    + "authorized_username, "
                    + "user_firstname, "
                    + "user_middleinitial, "
                    + "user_lastname, "
                    + "address_streetnumber, "
                    + "address_streetname, "
                    + "address_housenumber, "
                    + "address_addressline2, "
                    + "address_city, "
                    + "address_state, "
                    + "address_zip, "
                    + "address_zip4, "
                    + "address_country, "
                    + "loa_authorizing_person, "
                    + "lc_accountnumber, "
                    + "lc_pinnumber, "
                    + "phone_numbers, "
                    + "phone_number_type, "
                    + "portin_type, "
                    + "partial_portin, "
                    + "loa_uploaded, "
                    + "csr_uploaded, "
                    + "loa_required, "
                    + "suggested_activation_date, "
                    + "requested_activation_date, "
                    + "requested_quantity, "
                    + "order_status, "
                    + "external_api_update_status_code, "
                    + "external_api_update_status_description, "
                    + "triggered, "
                    + "order_date, "
                    + "vendor_name, "
                    + "rate_center,"
                    + "loc_carrier_spid, "
                    + "loc_carrier_name, "
                    + "loc_carrier_iswireless, "
                    + "loc_carrier_accountnumberrequired, "
                    + "loc_carrier_minimumportinginterval, "
                    + "organization_code, "
                    + "organization_name, "
                    + "requested_user_id, "
                    + "requested_user_email, "
                    + "requested_user_fullname, "
                    + "requested_user_code, "
                    + "modified_date, "
                    + "modified_user_id, "
                    + "modified_user_email, "
                    + "modified_user_fullname, "
                    + "modified_user_code, "
                    + "completed_date, "
                    + "completed_user_id, "
                    + "completed_user_email, "
                    + "completed_user_fullname, "
                    + "completed_user_code, "
                    + "notes "
                    + "FROM "
                    + "portin.portin_order "
                    + "WHERE "
                    + "portin_order_id = #{portinOrderId} ")
    @Results({
            @Result(property = "portinOrderId", column = "portin_order_id"),
            @Result(property = "portinRequestId", column = "portin_request_id"),
            @Result(property = "portinCustomerOrderId", column="portin_customer_order_id"),
            @Result(property = "portinExternalSystemOrderId", column = "portin_external_system_order_id"),
            @Result(property = "alternateSpid", column = "alternate_spid"),
            @Result(property = "billingTelephoneNumber", column = "billing_telephone_number"),
            @Result(property = "replacementBillingTelephoneNumber", column = "replacement_billing_telephone_number"),
            @Result(property = "userAccountType", column = "user_account_type"),
            @Result(property = "userCompanyname", column = "user_companyname"),
            @Result(property = "authorizedUsername", column = "authorized_username"),
            @Result(property = "userFirstname", column = "user_firstname"),
            @Result(property = "userMiddleinitial", column = "user_middleinitial"),
            @Result(property = "userLastname", column = "user_lastname"),
            @Result(property = "addressStreetnumber", column = "address_streetnumber"),
            @Result(property = "addressStreetname", column = "address_streetname"),
            @Result(property = "addressHousenumber", column = "address_housenumber"),
            @Result(property = "addressAddressline2", column = "address_addressline2"),
            @Result(property = "addressCity", column = "address_city"),
            @Result(property = "addressState", column = "address_state"),
            @Result(property = "addressZip", column = "address_zip"),
            @Result(property = "addressZip4", column = "address_zip4"),
            @Result(property = "addressCountry", column = "address_country"),
            @Result(property = "loaAuthorizingPerson", column = "loa_authorizing_person"),
            @Result(property = "lcAccountnumber", column = "lc_accountnumber"),
            @Result(property = "lcPinnumber", column = "lc_pinnumber"),
            @Result(property = "phoneNumbers", column = "phone_numbers"),
            @Result(property = "phoneNumberType", column = "phone_number_type"),
            @Result(property = "portinType", column = "portin_type"),
            @Result(property = "partialPortin", column = "partial_portin"),
            @Result(property = "loaUploaded", column = "loa_uploaded"),
            @Result(property = "csrUploaded", column = "csr_uploaded"),
            @Result(property = "loaRequired", column = "loa_required"),
            @Result(property = "suggestedActivationDate", column = "suggested_activation_date"),
            @Result(property = "requestedActivationDate", column = "requested_activation_date"),
            @Result(property = "requestedQuantity", column = "requested_quantity"),
            @Result(property = "orderStatus", column = "order_status"),
            @Result(property = "externalApiUpdateStatusCode", column = "external_api_update_status_code"),
            @Result(property = "externalApiUpdateStatusDescription", column = "external_api_update_status_description"),
            @Result(property = "triggered", column = "triggered"),
            @Result(property = "orderDate", column = "order_date"),
            @Result(property = "vendorName", column = "vendor_name"),
            @Result(property = "rateCenter", column = "rate_center"),
            @Result(property = "locCarrierSpid", column = "loc_carrier_spid"),
            @Result(property = "locCarrierName", column = "loc_carrier_name"),
            @Result(property = "locCarrierIswireless", column = "loc_carrier_iswireless"),
            @Result(property = "locCarrierAccountnumberrequired", column = "loc_carrier_accountnumberrequired"),
            @Result(property = "locCarrierMinimumportinginterval", column = "loc_carrier_minimumportinginterval"),
            @Result(property = "organizationCode", column = "organization_code"),
            @Result(property = "organizationName", column = "organization_name"),
            @Result(property = "requestedUserId", column = "requested_user_id"),
            @Result(property = "requestedUserEmail", column = "requested_user_email"),
            @Result(property = "requestedUserFullName", column = "requested_user_fullname"),
            @Result(property = "requestedUserCode", column = "requested_user_code"),
            @Result(property = "modifiedDate", column = "modified_date"),
            @Result(property = "modifiedUserId", column = "modified_user_id"),
            @Result(property = "modifiedUserEmail", column = "modified_user_email"),
            @Result(property = "modifiedUserFullName", column = "modified_user_fullname"),
            @Result(property = "modifiedUserCode", column = "modified_user_code"),
            @Result(property = "completedDate", column = "completed_date"),
            @Result(property = "completedUserId", column = "completed_user_id"),
            @Result(property = "completedUserEmail", column = "completed_user_email"),
            @Result(property = "completedUserFullName", column = "completed_user_fullname"),
            @Result(property = "completedUserCode", column = "completed_user_code"),
            @Result(property = "notes", column = "notes")
    })
    public PortinOrder getPortinOrderDetailsById(@Param("portinOrderId") Long portinOrderId);

  @Select(
      "SELECT "
          + "portin_order_id, "
          + "portin_request_id, "
          + "portin_customer_order_id, "
          + "portin_external_system_order_id "
          + "FROM "
          + "portin.portin_order "
          + "WHERE "
          + "portin_request_id = #{portinRequestId} "
          + " AND "
          + " order_status != 0 ")
  @Results({
    @Result(property = "portinOrderId", column = "portin_order_id"),
    @Result(property = "portinRequestId", column = "portin_request_id"),
    @Result(property = "portinCustomerOrderId", column = "portin_customer_order_id"),
    @Result(property = "portinExternalSystemOrderId", column = "portin_external_system_order_id")
  })
  public List<PortinOrder> getNonDraftPortinOrders(@Param("portinRequestId") Long portinRequestId);

  @Select(
      "<script> "
          + "SELECT count(*) "
          + "FROM portin.portin_order "
          + "<where> "
          + PORTINORDER_SEARCH_WHERE_FILTER
          + " </where>"
          + "</script>")
  public int count(@Param("criteria") PortinOrderFilter criteria);

    @Select(
            "<script> "
                    +"SELECT "
                    + "portin_order_id, "
                    + "portin_request_id, "
                    + "portin_external_system_order_id, "
                    + "alternate_spid, "
                    + "billing_telephone_number, "
                    + "replacement_billing_telephone_number, "
                    + "user_account_type, "
                    + "user_companyname, "
                    + "authorized_username, "
                    + "user_firstname, "
                    + "user_middleinitial, "
                    + "user_lastname, "
                    + "address_streetnumber, "
                    + "address_streetname, "
                    + "address_housenumber, "
                    + "address_addressline2, "
                    + "address_city, "
                    + "address_state, "
                    + "address_zip, "
                    + "address_zip4, "
                    + "address_country, "
                    + "loa_authorizing_person, "
                    + "lc_accountnumber, "
                    + "lc_pinnumber, "
                    + "phone_numbers, "
                    + "phone_number_type, "
                    + "portin_type, "
                    + "partial_portin, "
                    + "loa_uploaded, "
                    + "csr_uploaded, "
                    + "loa_required, "
                    + "suggested_activation_date, "
                    + "requested_activation_date, "
                    + "requested_quantity, "
                    + "order_status, "
                    + "external_api_update_status_code, "
                    + "external_api_update_status_description, "
                    + "triggered, "
                    + "order_date, "
                    + "vendor_name, "
                    + "rate_center,"
                    + "loc_carrier_spid, "
                    + "loc_carrier_name, "
                    + "loc_carrier_iswireless, "
                    + "loc_carrier_accountnumberrequired, "
                    + "loc_carrier_minimumportinginterval, "
                    + "organization_code, "
                    + "organization_name, "
                    + "requested_user_id, "
                    + "requested_user_email, "
                    + "requested_user_fullname, "
                    + "requested_user_code, "
                    + "modified_date, "
                    + "modified_user_id, "
                    + "modified_user_email, "
                    + "modified_user_fullname, "
                    + "modified_user_code, "
                    + "completed_date, "
                    + "completed_user_id, "
                    + "completed_user_email, "
                    + "completed_user_fullname, "
                    + "completed_user_code, "
                    + "notes "
                    + "FROM "
                    + "portin.portin_order "
                    + "<where> "
                    + PORTINORDER_SEARCH_WHERE_FILTER
                    + " </where>"
                    + " ORDER BY "
                    + "<choose>"
                    + "<when test=\"sortField == 'portin_request_id'\"> portin_request_id </when>"
                    + "<when test=\"sortField == 'billing_telephone_number'\"> billing_telephone_number </when>"
                    + "<when test=\"sortField == 'order_date'\"> order_date </when>"
                    + "<when test=\"sortField == 'rate_center'\"> rate_center </when>"
                    + "<when test=\"sortField == 'order_status'\"> order_status </when>"
                    + "<when test=\"sortField == 'portin_customer_order_id'\"> portin_customer_order_id </when>"
                    + "<when test=\"sortField == 'loc_carrier_name'\"> loc_carrier_name </when>"
                    + "<when test=\"sortField == 'requested_activation_date'\"> requested_activation_date </when>"
                    + "<when test=\"sortField == 'requested_quantity'\"> requested_quantity </when>"
                    + "<when test=\"sortField == 'organization_name'\"> organization_name </when>"
                    + "<when test=\"sortField == 'modified_user_fullname'\"> modified_user_fullname </when>"
                    + "<otherwise> order_date </otherwise>"
                    + "</choose>"
                    + "<choose>"
                    + "<when test=\"sortOrder\"> ASC </when>"
                    + "<otherwise> DESC </otherwise>"
                    + "</choose>"
                    + " LIMIT #{limit} OFFSET #{offset} "
                    + "</script>")
    @Results({
            @Result(property = "portinOrderId", column = "portin_order_id"),
            @Result(property = "portinRequestId", column = "portin_request_id"),
            @Result(property = "portinExternalSystemOrderId", column = "portin_external_system_order_id"),
            @Result(property = "alternateSpid", column = "alternate_spid"),
            @Result(property = "billingTelephoneNumber", column = "billing_telephone_number"),
            @Result(property = "replacementBillingTelephoneNumber", column = "replacement_billing_telephone_number"),
            @Result(property = "userAccountType", column = "user_account_type"),
            @Result(property = "userCompanyname", column = "user_companyname"),
            @Result(property = "authorizedUsername", column = "authorized_username"),
            @Result(property = "userFirstname", column = "user_firstname"),
            @Result(property = "userMiddleinitial", column = "user_middleinitial"),
            @Result(property = "userLastname", column = "user_lastname"),
            @Result(property = "addressStreetnumber", column = "address_streetnumber"),
            @Result(property = "addressStreetname", column = "address_streetname"),
            @Result(property = "addressHousenumber", column = "address_housenumber"),
            @Result(property = "addressAddressline2", column = "address_addressline2"),
            @Result(property = "addressCity", column = "address_city"),
            @Result(property = "addressState", column = "address_state"),
            @Result(property = "organizationName", column = "organization_name"),
            @Result(property = "addressZip", column = "address_zip"),
            @Result(property = "addressZip4", column = "address_zip4"),
            @Result(property = "addressCountry", column = "address_country"),
            @Result(property = "loaAuthorizingPerson", column = "loa_authorizing_person"),
            @Result(property = "lcAccountnumber", column = "lc_accountnumber"),
            @Result(property = "lcPinnumber", column = "lc_pinnumber"),
            @Result(property = "phoneNumbers", column = "phone_numbers"),
            @Result(property = "phoneNumberType", column = "phone_number_type"),
            @Result(property = "portinType", column = "portin_type"),
            @Result(property = "partialPortin", column = "partial_portin"),
            @Result(property = "loaUploaded", column = "loa_uploaded"),
            @Result(property = "csrUploaded", column = "csr_uploaded"),
            @Result(property = "loaRequired", column = "loa_required"),
            @Result(property = "suggestedActivationDate", column = "suggested_activation_date"),
            @Result(property = "requestedActivationDate", column = "requested_activation_date"),
            @Result(property = "requestedQuantity", column = "requested_quantity"),
            @Result(property = "orderStatus", column = "order_status"),
            @Result(property = "externalApiUpdateStatusCode", column = "external_api_update_status_code"),
            @Result(property = "externalApiUpdateStatusDescription", column = "external_api_update_status_description"),
            @Result(property = "triggered", column = "triggered"),
            @Result(property = "orderDate", column = "order_date"),
            @Result(property = "vendorName", column = "vendor_name"),
            @Result(property = "rateCenter", column = "rate_center"),
            @Result(property = "locCarrierSpid", column = "loc_carrier_spid"),
            @Result(property = "locCarrierName", column = "loc_carrier_name"),
            @Result(property = "locCarrierIswireless", column = "loc_carrier_iswireless"),
            @Result(property = "locCarrierAccountnumberrequired", column = "loc_carrier_accountnumberrequired"),
            @Result(property = "locCarrierMinimumportinginterval", column = "loc_carrier_minimumportinginterval"),
            @Result(property = "organizationCode", column = "organization_code"),
            @Result(property = "organizationName", column = "organization_name"),
            @Result(property = "requestedUserId", column = "requested_user_id"),
            @Result(property = "requestedUserEmail", column = "requested_user_email"),
            @Result(property = "requestedUserFullName", column = "requested_user_fullname"),
            @Result(property = "requestedUserCode", column = "requested_user_code"),
            @Result(property = "modifiedDate", column = "modified_date"),
            @Result(property = "modifiedUserId", column = "modified_user_id"),
            @Result(property = "modifiedUserEmail", column = "modified_user_email"),
            @Result(property = "modifiedUserFullName", column = "modified_user_fullname"),
            @Result(property = "modifiedUserCode", column = "modified_user_code"),
            @Result(property = "completedDate", column = "completed_date"),
            @Result(property = "completedUserId", column = "completed_user_id"),
            @Result(property = "completedUserEmail", column = "completed_user_email"),
            @Result(property = "completedUserFullName", column = "completed_user_fullname"),
            @Result(property = "completedUserCode", column = "completed_user_code"),
            @Result(property = "notes", column = "notes")
    })
    public List<PortinOrder> searchPortinOrders(
            @Param("criteria") PortinOrderFilter criteria,
            @Param("sortField") String sortField,
            @Param("sortOrder") boolean sortOrder,
            @Param("limit") int limit,
            @Param("offset") int offset);


  @Delete("DELETE FROM portin.portin_order WHERE portin_request_id = #{portinRequestId}")
  public void deletePortOrder(@Param("portinRequestId") Long portinRequestId);

  @Select(
      "SELECT "
          + "rate_center,"
          + "loc_carrier_name,"
          + "portin_order_id,"
          + "suggested_activation_date "
          + "FROM "
          + "portin.portin_order "
          + "WHERE "
          + "portin_order_id = #{portinOrderId} ")
  @Results({
    @Result(property = "portinOrderId", column = "portin_order_id"),
    @Result(property = "rateCenter", column = "rate_center"),
    @Result(property = "locCarrierName", column = "loc_carrier_name"),
    @Result(property = "suggestedActivationDate", column = "suggested_activation_date")
  })
  public PortinOrder getPortinOrderById(@Param("portinOrderId") Long getPortinOrderId);

    @Update(
            "<script>"
                    + "Update portin.portin_order "
                    + "<set>"
                    + "modified_date = current_timestamp, "
                    + "<if test='portinOrder.portinCustomerOrderId != null'>portin_customer_order_id = #{portinOrder.portinCustomerOrderId}, </if>"
                    + "<if test='portinOrder.portinExternalSystemOrderId != null'>portin_external_system_order_id = #{portinOrder.portinExternalSystemOrderId}, </if>"
                    + "<if test='portinOrder.alternateSpid != null'>alternate_spid = #{portinOrder.alternateSpid}, </if>"
                    + "<if test='portinOrder.billingTelephoneNumber != null'>billing_telephone_number = #{portinOrder.billingTelephoneNumber}, </if>"
                    + "<if test='portinOrder.replacementBillingTelephoneNumber != null'>replacement_billing_telephone_number = #{portinOrder.replacementBillingTelephoneNumber}, </if>"
                    + "<if test='portinOrder.userAccountType != null'>user_account_type = #{portinOrder.userAccountType}, </if>"
                    + "<if test='portinOrder.userCompanyname != null'>user_companyname = #{portinOrder.userCompanyname}, </if>"
                    + "<if test='portinOrder.authorizedUsername != null'>authorized_username = #{portinOrder.authorizedUsername}, </if>"
                    + "<if test='portinOrder.userFirstname != null'>user_firstname = #{portinOrder.userFirstname}, </if>"
                    + "<if test='portinOrder.userMiddleinitial != null'>user_middleinitial = #{portinOrder.userMiddleinitial}, </if>"
                    + "<if test='portinOrder.userLastname != null'>user_lastname = #{portinOrder.userLastname}, </if>"
                    + "<if test='portinOrder.addressStreetnumber != null'>address_streetnumber = #{portinOrder.addressStreetnumber}, </if>"
                    + "<if test='portinOrder.addressStreetname != null'>address_streetname = #{portinOrder.addressStreetname}, </if>"
                    + "<if test='portinOrder.addressHousenumber != null'>address_housenumber = #{portinOrder.addressHousenumber}, </if>"
                    + "<if test='portinOrder.addressAddressline2 != null'>address_addressline2 = #{portinOrder.addressAddressline2}, </if>"
                    + "<if test='portinOrder.addressCity != null'>address_city = #{portinOrder.addressCity}, </if>"
                    + "<if test='portinOrder.addressState != null'>address_state = #{portinOrder.addressState}, </if>"
                    + "<if test='portinOrder.addressZip != null'>address_zip = #{portinOrder.addressZip}, </if>"
                    + "<if test='portinOrder.addressZip4 != null'>address_zip4 = #{portinOrder.addressZip4}, </if>"
                    + "<if test='portinOrder.partialPortin != null'>partial_portin = #{portinOrder.partialPortin}, </if>"
                    + "<if test='portinOrder.addressCountry != null'>address_country = #{portinOrder.addressCountry}, </if>"
                    + "<if test='portinOrder.loaAuthorizingPerson != null'>loa_authorizing_person = #{portinOrder.loaAuthorizingPerson}, </if>"
                    + "<if test='portinOrder.lcAccountnumber != null'>lc_accountnumber = #{portinOrder.lcAccountnumber}, </if>"
                    + "<if test='portinOrder.lcPinnumber != null'>lc_pinnumber = #{portinOrder.lcPinnumber}, </if>"
                    + "<if test='portinOrder.phoneNumbers != null'>phone_numbers = #{portinOrder.phoneNumbers}, </if>"
                    + "<if test='portinOrder.phoneNumberType != null'>phone_number_type = #{portinOrder.phoneNumberType}, </if>"
                    + "<if test='portinOrder.portinType != null'>portin_type = #{portinOrder.portinType}, </if>"
                    + "<if test='portinOrder.loaUploaded != null'>loa_uploaded = #{portinOrder.loaUploaded}, </if>"
                    + "<if test='portinOrder.csrUploaded != null'>csr_uploaded = #{portinOrder.csrUploaded}, </if>"
                    + "<if test='portinOrder.loaRequired != null'>loa_required = #{portinOrder.loaRequired}, </if>"
                    + "<if test='portinOrder.suggestedActivationDate != null'>suggested_activation_date = #{portinOrder.suggestedActivationDate}, </if>"
                    + "<if test='portinOrder.requestedActivationDate != null'>requested_activation_date = #{portinOrder.requestedActivationDate}, </if>"
                    + "<if test='portinOrder.requestedQuantity != null'>requested_quantity = #{portinOrder.requestedQuantity}, </if>"
                    + "<if test='portinOrder.orderStatus != null'>order_status = #{portinOrder.orderStatus}, </if>"
                    + "<if test='portinOrder.externalApiUpdateStatusCode != null'>external_api_update_status_code = #{portinOrder.externalApiUpdateStatusCode}, </if>"
                    + "<if test='portinOrder.externalApiUpdateStatusDescription != null'>external_api_update_status_description = #{portinOrder.externalApiUpdateStatusDescription}, </if>"
                    + "<if test='portinOrder.triggered != null'>triggered = #{portinOrder.triggered}, </if>"
                    + "<if test='portinOrder.orderDate != null'>order_date = #{portinOrder.orderDate}, </if>"
                    + "<if test='portinOrder.vendorName != null'>vendor_name = #{portinOrder.vendorName}, </if>"
                    + "<if test='portinOrder.rateCenter != null'>rate_center = #{portinOrder.rateCenter}, </if>"
                    + "<if test='portinOrder.locCarrierSpid != null'>loc_carrier_spid = #{portinOrder.locCarrierSpid}, </if>"
                    + "<if test='portinOrder.locCarrierName != null'>loc_carrier_name = #{portinOrder.locCarrierName}, </if>"
                    + "<if test='portinOrder.locCarrierIswireless != null'>loc_carrier_iswireless = #{portinOrder.locCarrierIswireless}, </if>"
                    + "<if test='portinOrder.locCarrierAccountnumberrequired != null'>loc_carrier_accountnumberrequired = #{portinOrder.locCarrierAccountnumberrequired}, </if>"
                    + "<if test='portinOrder.locCarrierMinimumportinginterval != null'>loc_carrier_minimumportinginterval = #{portinOrder.locCarrierMinimumportinginterval}, </if>"
                    + "<if test='portinOrder.organizationCode != null'>organization_code = #{portinOrder.organizationCode}, </if>"
                    + "<if test='portinOrder.organizationName != null'>organization_name = #{portinOrder.organizationName}, </if>"
                    + "<if test='portinOrder.requestedUserId != null'>requested_user_id = #{portinOrder.requestedUserId}, </if>"
                    + "<if test='portinOrder.requestedUserEmail != null'>requested_user_email = #{portinOrder.requestedUserEmail}, </if>"
                    + "<if test='portinOrder.requestedUserFullName != null'>requested_user_fullname = #{portinOrder.requestedUserFullName}, </if>"
                    + "<if test='portinOrder.requestedUserCode != null'>requested_user_code = #{portinOrder.requestedUserCode}, </if>"
                    + "<if test='portinOrder.modifiedUserId != null'>modified_user_id = #{portinOrder.modifiedUserId}, </if>"
                    + "<if test='portinOrder.modifiedUserEmail != null'>modified_user_email = #{portinOrder.modifiedUserEmail}, </if>"
                    + "<if test='portinOrder.modifiedUserFullName != null'>modified_user_fullname = #{portinOrder.modifiedUserFullName}, </if>"
                    + "<if test='portinOrder.modifiedUserCode != null'>modified_user_code = #{portinOrder.modifiedUserCode}, </if>"
                    + "<if test='portinOrder.completedDate != null'>completed_date = #{portinOrder.completedDate}, </if>"
                    + "<if test='portinOrder.completedUserId != null'>completed_user_id = #{portinOrder.completedUserId}, </if>"
                    + "<if test='portinOrder.completedUserEmail != null'>completed_user_email = #{portinOrder.completedUserEmail}, </if>"
                    + "<if test='portinOrder.completedUserFullName != null'>completed_user_fullname = #{portinOrder.completedUserFullName}, </if>"
                    + "<if test='portinOrder.completedUserCode != null'>completed_user_code = #{portinOrder.completedUserCode}, </if>"
                    + "<if test='portinOrder.notes != null'>notes = #{portinOrder.notes}, </if>"
                    + "</set>"
                    + "WHERE "
                    + "portin_order_id = #{portinOrder.portinOrderId}"
                    + "</script>")
    public void updatePortinOrderId(@Param("portinOrder") PortinOrder portinOrder);

  @Delete(
      "DELETE "
          + "FROM portin.portin_order "
          + "WHERE portin_request_id = #{portinRequestId} "
          + " AND "
          + "order_status = #{portinOrderStatus} ")
  public void deleteDraftPortinOrdersByReqId(
      @Param("portinRequestId") Long portinRequestId,
      @Param("portinOrderStatus") Long portinOrderStatus);

    @Delete("DELETE FROM portin.portin_order WHERE order_status = 0 AND portin_order_id = #{portinOrderId}")
    void deletePortinOrder(@Param("portinOrderId") Long portinOrderId);

    @Select(
            "<script> "
                    + "SELECT count(portin_order_id) "
                    + "FROM portin_order "
                    + "where "
                    + "portin_request_id = #{portinRequestId}"
                    + "</script>")
    public int getPortinOrderCount(@Param("portinRequestId") Long portinRequestId);

    @Delete("DELETE FROM portin_order_error WHERE portin_order_id = #{portinOrderId}")
    void deletePortinOrderErrorByOrderId(@Param("portinOrderId") Long portinOrderId);

    @Delete("DELETE FROM portin_request_file WHERE portin_order_id = #{portinOrderId}")
    void deletePortinRequestFileByOrderId(@Param("portinOrderId") Long portinOrderId);
}
