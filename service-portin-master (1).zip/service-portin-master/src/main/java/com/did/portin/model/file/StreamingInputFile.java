package com.did.portin.model.file;

import java.io.InputStream;

public class StreamingInputFile {
  private InputStream streamingInput;
  private String fileName;

  public StreamingInputFile(InputStream streamingInput, String fileName) {
    this.streamingInput = streamingInput;
    this.fileName = fileName;
  }

  public InputStream getStreamingInput() {
    return streamingInput;
  }

  public void setStreamingInput(InputStream streamingInput) {
    this.streamingInput = streamingInput;
  }

  public String getFileName() {
    return fileName;
  }

  public void setFileName(String fileName) {
    this.fileName = fileName;
  }
}
