package com.did.portin.model.db;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.sql.Timestamp;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class PortinRequest {
  private Long portinRequestId;
  private String portinExternalRequestId;
  private String customerAccountId;
  private String phoneNumbers;
  private String nonPortableNumbers;
  private Timestamp requestedActivationDate;
  private Integer requestedQuantity;
  private Long requestStatus;
  private String bulkPortOrderNumber;
  private String organizationCode;
  private String organizationName;
  private Timestamp requestedDate;
  private Long requestedUserId;
  private String requestedUserEmail;
  private String requestedUserFullName;
  private String requestedUserCode;
  private Timestamp modifiedDate;
  private Long modifiedUserId;
  private String modifiedUserEmail;
  private String modifiedUserFullName;
  private String modifiedUserCode;
  private Timestamp completedDate;
  private String completedUserId;
  private String completedUserEmail;
  private String completedUserFullName;
  private String completedUserCode;
  private String notes;
  private boolean overdue;

  public Long getPortinRequestId() {
    return portinRequestId;
  }

  public void setPortinRequestId(Long portinRequestId) {
    this.portinRequestId = portinRequestId;
  }

  public String getPortinExternalRequestId() {
    return portinExternalRequestId;
  }

  public void setPortinExternalRequestId(String portinExternalRequestId) {
    this.portinExternalRequestId = portinExternalRequestId;
  }

  public String getCustomerAccountId() {
    return customerAccountId;
  }

  public void setCustomerAccountId(String customerAccountId) {
    this.customerAccountId = customerAccountId;
  }

  public String getPhoneNumbers() {
    return phoneNumbers;
  }

  public void setPhoneNumbers(String phoneNumbers) {
    this.phoneNumbers = phoneNumbers;
  }

  public String getNonPortableNumbers() {
    return nonPortableNumbers;
  }

  public void setNonPortableNumbers(String nonPortableNumbers) {
    this.nonPortableNumbers = nonPortableNumbers;
  }

  public Timestamp getRequestedActivationDate() {
    return requestedActivationDate;
  }

  public void setRequestedActivationDate(Timestamp requestedActivationDate) {
    this.requestedActivationDate = requestedActivationDate;
  }

  public Integer getRequestedQuantity() {
    return requestedQuantity;
  }

  public void setRequestedQuantity(Integer requestedQuantity) {
    this.requestedQuantity = requestedQuantity;
  }

  public Long getRequestStatus() {
    return requestStatus;
  }

  public void setRequestStatus(Long requestStatus) {
    this.requestStatus = requestStatus;
  }

  public String getBulkPortOrderNumber() {
    return bulkPortOrderNumber;
  }

  public void setBulkPortOrderNumber(String bulkPortOrderNumber) {
    this.bulkPortOrderNumber = bulkPortOrderNumber;
  }

  public String getOrganizationCode() {
    return organizationCode;
  }

  public void setOrganizationCode(String organizationCode) {
    this.organizationCode = organizationCode;
  }

  public String getOrganizationName() {
    return organizationName;
  }

  public void setOrganizationName(String organizationName) {
    this.organizationName = organizationName;
  }

  public Timestamp getRequestedDate() {
    return requestedDate;
  }

  public void setRequestedDate(Timestamp requestedDate) {
    this.requestedDate = requestedDate;
  }

  public Long getRequestedUserId() {
    return requestedUserId;
  }

  public void setRequestedUserId(Long requestedUserId) {
    this.requestedUserId = requestedUserId;
  }

  public String getRequestedUserEmail() {
    return requestedUserEmail;
  }

  public void setRequestedUserEmail(String requestedUserEmail) {
    this.requestedUserEmail = requestedUserEmail;
  }

  public String getRequestedUserFullName() {
    return requestedUserFullName;
  }

  public void setRequestedUserFullName(String requestedUserFullName) {
    this.requestedUserFullName = requestedUserFullName;
  }

  public String getRequestedUserCode() {
    return requestedUserCode;
  }

  public void setRequestedUserCode(String requestedUserCode) {
    this.requestedUserCode = requestedUserCode;
  }

  public Timestamp getModifiedDate() {
    return modifiedDate;
  }

  public void setModifiedDate(Timestamp modifiedDate) {
    this.modifiedDate = modifiedDate;
  }

  public Long getModifiedUserId() {
    return modifiedUserId;
  }

  public void setModifiedUserId(Long modifiedUserId) {
    this.modifiedUserId = modifiedUserId;
  }

  public String getModifiedUserEmail() {
    return modifiedUserEmail;
  }

  public void setModifiedUserEmail(String modifiedUserEmail) {
    this.modifiedUserEmail = modifiedUserEmail;
  }

  public String getModifiedUserFullName() {
    return modifiedUserFullName;
  }

  public void setModifiedUserFullName(String modifiedUserFullName) {
    this.modifiedUserFullName = modifiedUserFullName;
  }

  public String getModifiedUserCode() {
    return modifiedUserCode;
  }

  public void setModifiedUserCode(String modifiedUserCode) {
    this.modifiedUserCode = modifiedUserCode;
  }

  public Timestamp getCompletedDate() {
    return completedDate;
  }

  public void setCompletedDate(Timestamp completedDate) {
    this.completedDate = completedDate;
  }

  public String getCompletedUserId() {
    return completedUserId;
  }

  public void setCompletedUserId(String completedUserId) {
    this.completedUserId = completedUserId;
  }

  public String getCompletedUserEmail() {
    return completedUserEmail;
  }

  public void setCompletedUserEmail(String completedUserEmail) {
    this.completedUserEmail = completedUserEmail;
  }

  public String getCompletedUserFullName() {
    return completedUserFullName;
  }

  public void setCompletedUserFullName(String completedUserFullName) {
    this.completedUserFullName = completedUserFullName;
  }

  public String getCompletedUserCode() {
    return completedUserCode;
  }

  public void setCompletedUserCode(String completedUserCode) {
    this.completedUserCode = completedUserCode;
  }

  public String getNotes() {
    return notes;
  }

  public void setNotes(String notes) {
    this.notes = notes;
  }

  public boolean isOverdue() {
    return overdue;
  }

  public void setOverdue(boolean overdue) {
    this.overdue = overdue;
  }
}
