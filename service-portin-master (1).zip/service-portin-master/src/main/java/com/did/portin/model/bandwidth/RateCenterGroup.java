package com.did.portin.model.bandwidth;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

@Root(name = "RateCenterGroup", strict = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RateCenterGroup {

  @Element(name = "RateCenter", required = false)
  private String rateCenter;

  @Element(name = "City", required = false)
  private String city;

  @Element(name = "State", required = false)
  private String state;

  @Element(name = "LATA", required = false)
  private String lata;

  @Element(name = "Tiers", required = false)
  private Tiers tiers;

  @Element(name = "TnList", required = true)
  private TnListAlt tnList;

  public String getRateCenter() {
    return rateCenter;
  }

  public void setRateCenter(String rateCenter) {
    this.rateCenter = rateCenter;
  }

  public String getCity() {
    return city;
  }

  public void setCity(String city) {
    this.city = city;
  }

  public String getState() {
    return state;
  }

  public void setState(String state) {
    this.state = state;
  }

  public String getLata() {
    return lata;
  }

  public void setLata(String lata) {
    this.lata = lata;
  }

  public TnListAlt getTnList() {
    return tnList;
  }

  public void setTnList(TnListAlt tnList) {
    this.tnList = tnList;
  }

  public Tiers getTiers() {
    return tiers;
  }

  public void setTiers(Tiers tiers) {
    this.tiers = tiers;
  }
}
