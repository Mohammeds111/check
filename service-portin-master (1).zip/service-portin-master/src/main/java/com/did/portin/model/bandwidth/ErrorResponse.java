package com.did.portin.model.bandwidth;

import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

@Root(name = "ErrorResponse", strict = false)
public class ErrorResponse {
  @Element(name = "irisStatus", required = false)
  private IrisStatus irisStatus;

  public IrisStatus getIrisStatus() {
    return irisStatus;
  }

  public void setIrisStatus(IrisStatus irisStatus) {
    this.irisStatus = irisStatus;
  }
}
