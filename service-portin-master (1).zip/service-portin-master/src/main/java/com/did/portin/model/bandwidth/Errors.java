package com.did.portin.model.bandwidth;

import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

@Root(name = "Errors", strict = false)
public class Errors extends ErrorCommonAttributes {

  @Element(name = "TelephoneNumbers", required = false)
  private TelephoneNumbers telephoneNumbers;

  public TelephoneNumbers getTelephoneNumbers() {
    return telephoneNumbers;
  }

  public void setTelephoneNumbers(TelephoneNumbers telephoneNumbers) {
    this.telephoneNumbers = telephoneNumbers;
  }
}
