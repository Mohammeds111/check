package com.did.portin.jaxrs;

import com.did.portin.model.db.PortinOrder;
import com.did.portin.model.pagination.PaginatedResponse;
import com.did.portin.model.rest.PortinOrderDetailsResponse;
import com.did.portin.model.rest.PortinOrderSubmitResponse;
import com.did.portin.model.rest.PortinOrderUpdateResponse;
import com.did.portin.model.rest.PortinResponse;
import com.did.portin.model.rest.SearchPortinOrderRequest;
import com.did.portin.service.PortinOrderService;
import com.did.portin.util.PaginationUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.inject.Inject;
import javax.ws.rs.QueryParam;
import java.util.Objects;

@RestController
public class DIDPortinOrdersEndPoint {
  private static final Logger logger = LoggerFactory.getLogger(DIDPortinOrdersEndPoint.class);
  @Inject PortinOrderService portinOrderService;

  // Method to fetch the Order details
  @GetMapping("/portin-request/{portinRequestId}/portin-orders")
  public PortinResponse getPortinOrderDetails(
      @PathVariable("portinRequestId") Long portinRequestId,
      @QueryParam("portinOrderId") Long portinOrderId,
      @QueryParam("openOrdersOnly") boolean openOrdersOnly)
      throws Exception {
    PortinResponse portinResponse = new PortinResponse<>();
    PortinOrderDetailsResponse portinOrderDetailsResponse =
        portinOrderService.getPortinOrdersByRequestId(
            portinRequestId, portinOrderId, openOrdersOnly);
    if (Objects.nonNull(portinOrderDetailsResponse)) {
      portinResponse = PortinResponse.generateResponse("Ok", 0, portinOrderDetailsResponse);
    }
    return portinResponse;
  }
  // Method to Search Orders
  @PostMapping(
      value = "/portin-order/search",
      produces = "application/json",
      consumes = "application/json")
  public PortinResponse searchPortinOrders(
      @RequestBody SearchPortinOrderRequest searchPortinOrderRequest) {

    PaginatedResponse paginatedResponse =
        PaginationUtil.createPaginatedResponse(
            portinOrderService.searchPortinOrders(searchPortinOrderRequest),
            searchPortinOrderRequest.getPagination().getLimit(),
            searchPortinOrderRequest.getPagination().getOffset());

    return PortinResponse.generateResponse(
        "Ok", 0, paginatedResponse.getData(), paginatedResponse.getPagination());
  }
  // Method to update the Portin Orders
  @PutMapping(
      path = "/portin-order/{portinOrderId}",
      consumes = "application/json",
      produces = "application/json")
  public PortinResponse updatePortinOrder(
      @PathVariable("portinOrderId") Long portinOrderId, @RequestBody PortinOrder portinOrder)
      throws Exception {
    PortinOrderUpdateResponse portinOrderUpdateResponse =
        portinOrderService.updatePortinOrders(portinOrderId, portinOrder);
    return PortinResponse.generateResponse("Ok", 0, portinOrderUpdateResponse);
  }

  @ExceptionHandler(Exception.class)
  public ResponseEntity<String> handleException(Exception exception) throws JSONException {
    JSONObject response = new JSONObject();
    response.put("Error Message", exception.getMessage());
    logger.debug("Exception in DIDPortinOrdersEndPoint:", exception.getMessage());
    return new ResponseEntity<String>(response.toString(), HttpStatus.BAD_REQUEST);
  }

  @DeleteMapping("/portin-request/{portinRequestId}/portin-order/{portinOrderId}")
  public PortinResponse deletePortinOrder(
      @PathVariable("portinRequestId") Long portinRequestId,
      @PathVariable("portinOrderId") Long portinOrderId)
      throws Exception {
    PortinResponse portinResponse =
        PortinResponse.generateResponse(
            "Ok", 0, portinOrderService.deletePortinOrders(portinRequestId, portinOrderId));
    return portinResponse;
  }

  @PostMapping(path = "/portin-order/{portinOrderId}/submit", produces = "application/json")
  public PortinResponse submitPortinOrder(@PathVariable("portinOrderId") Long portinOrderId)
      throws Exception {
    PortinOrderSubmitResponse portinOrderSubmitResponse =
        portinOrderService.submitPortinOrders(portinOrderId);
    return PortinResponse.generateResponse("Ok", 0, portinOrderSubmitResponse);
  }
}
