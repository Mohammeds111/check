package com.did.portin.model.db;

import java.sql.Timestamp;

public class PortinRequestFile {
  private long portinRequestFileId;
  private long portinRequestId;
  private long portinOrderId;
  private long portinFileTypeId;
  private long fileId;
  private String externalApiFileName;
  private Timestamp signedDate;

  public Timestamp getSignedDate() {
    return signedDate;
  }

  public void setSignedDate(Timestamp signedDate) {
    this.signedDate = signedDate;
  }

  public long getPortinRequestFileId() {
    return portinRequestFileId;
  }

  public void setPortinRequestFileId(long portinRequestFileId) {
    this.portinRequestFileId = portinRequestFileId;
  }

  public long getPortinRequestId() {
    return portinRequestId;
  }

  public void setPortinRequestId(long portinRequestId) {
    this.portinRequestId = portinRequestId;
  }

  public long getPortinOrderId() {
    return portinOrderId;
  }

  public void setPortinOrderId(long portinOrderId) {
    this.portinOrderId = portinOrderId;
  }

  public long getPortinFileTypeId() {
    return portinFileTypeId;
  }

  public void setPortinFileTypeId(long portinFileTypeId) {
    this.portinFileTypeId = portinFileTypeId;
  }

  public long getFileId() {
    return fileId;
  }

  public void setFileId(long fileId) {
    this.fileId = fileId;
  }

  public String getExternalApiFileName() {
    return externalApiFileName;
  }

  public void setExternalApiFileName(String externalApiFileName) {
    this.externalApiFileName = externalApiFileName;
  }
}
