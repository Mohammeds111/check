package com.did.portin.model.rest;

import com.did.portin.model.rest.errors.PhoneNumberValidationError;

import java.util.List;

public class PhoneNumberValidationResponse {
    private List<PhoneNumberValidationError> validationErrors;
    private String validPhoneNumbers;

    public List<PhoneNumberValidationError> getValidationErrors() {
        return validationErrors;
    }

    public void setValidationErrors(List<PhoneNumberValidationError> validationErrors) {
        this.validationErrors = validationErrors;
    }

    public String getValidPhoneNumbers() {
        return validPhoneNumbers;
    }

    public void setValidPhoneNumbers(String validPhoneNumbers) {
        this.validPhoneNumbers = validPhoneNumbers;
    }
}
