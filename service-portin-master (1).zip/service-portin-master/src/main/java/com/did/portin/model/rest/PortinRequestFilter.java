package com.did.portin.model.rest;

import com.did.portin.model.sort.PortinRequestSortAttribute;
import com.did.portin.model.sort.SortDirection;

public class PortinRequestFilter extends BaseFilter {
    private String q;
    private PortinRequestSortAttribute sortBy;
    private SortDirection sortDirection;
    private Integer[] statuses;
    private String organization;
    private boolean overdue;

    public String getQ() {
        return q;
    }

    public void setQ(String q) {
        this.q = q;
    }

    public PortinRequestSortAttribute getSortBy() {
        return sortBy;
    }

    public void setSortBy(PortinRequestSortAttribute sortBy) {
        this.sortBy = sortBy;
    }

    public SortDirection getSortDirection() {
        return sortDirection;
    }

    public void setSortDirection(SortDirection sortDirection) {
        this.sortDirection = sortDirection;
    }

    public Integer[] getStatuses() {
        return statuses;
    }

    public void setStatuses(Integer[] statuses) {
        this.statuses = statuses;
    }


    public String getOrganization() {
        return organization;
    }

    public void setOrganization(String organization) {
        this.organization = organization;
    }

    public PortinRequestFilter withQ(String q) {
        this.q = q;
        return this;
    }

    public PortinRequestFilter withStatuses(Integer[] statuses) {
        this.statuses = statuses;
        return this;
    }


    public PortinRequestFilter withOrganization(String organization) {
        this.organization = organization;
        return this;
    }

    public PortinRequestFilter withOverdue(boolean overdue) {
        this.overdue = overdue;
        return this;
    }

    public boolean isOverdue() {
        return overdue;
    }

    public void setOverdue(boolean overdue) {
        this.overdue = overdue;
    }
}