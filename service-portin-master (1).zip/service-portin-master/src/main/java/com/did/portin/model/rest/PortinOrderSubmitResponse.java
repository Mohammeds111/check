package com.did.portin.model.rest;

import com.did.portin.model.db.PortinOrder;
import com.did.portin.model.db.PortinOrderError;
import java.util.List;

public class PortinOrderSubmitResponse {
    private boolean orderSubmitted;
    private List<PortinOrderError> orderErrors;
    private PortinOrder latestPortinOrder;

    public boolean isOrderSubmitted() {
        return orderSubmitted;
    }

    public void setOrderSubmitted(boolean orderSubmitted) {
        this.orderSubmitted = orderSubmitted;
    }

    public List<PortinOrderError> getOrderErrors() {
        return orderErrors;
    }

    public void setOrderErrors(List<PortinOrderError> orderErrors) {
        this.orderErrors = orderErrors;
    }

    public PortinOrder getLatestPortinOrder() {
        return latestPortinOrder;
    }

    public void setLatestPortinOrder(PortinOrder latestPortinOrder) {
        this.latestPortinOrder = latestPortinOrder;
    }
}
