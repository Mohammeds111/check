package com.did.portin.model.bandwidth;

import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

@Root(name = "LosingCarrierTnList", strict = false)
public class LosingCarrierTnList {

  @Element(name = "LosingCarrierSPID", required = false)
  private String losingCarrierSPID;

  @Element(name = "LosingCarrierName", required = false)
  private String losingCarrierName;

  @Element(name = "LosingCarrierIsWireless", required = false)
  private boolean losingCarrierIsWireless;

  @Element(name = "LosingCarrierAccountNumberRequired", required = false)
  private boolean LosingCarrierAccountNumberRequired;

  @Element(name = "LosingCarrierMinimumPortingInterval", required = false)
  private boolean losingCarrierMinimumPortingInterval;

  @Element(name = "TnList", required = true)
  private TnListAlt tnList;

  public TnListAlt getTnList() {
    return tnList;
  }

  public void setTnList(TnListAlt tnList) {
    this.tnList = tnList;
  }

  public String getLosingCarrierSPID() {
    return losingCarrierSPID;
  }

  public void setLosingCarrierSPID(String losingCarrierSPID) {
    this.losingCarrierSPID = losingCarrierSPID;
  }

  public String getLosingCarrierName() {
    return losingCarrierName;
  }

  public void setLosingCarrierName(String losingCarrierName) {
    this.losingCarrierName = losingCarrierName;
  }

  public boolean isLosingCarrierIsWireless() {
    return losingCarrierIsWireless;
  }

  public void setLosingCarrierIsWireless(boolean losingCarrierIsWireless) {
    this.losingCarrierIsWireless = losingCarrierIsWireless;
  }

  public boolean isLosingCarrierAccountNumberRequired() {
    return LosingCarrierAccountNumberRequired;
  }

  public void setLosingCarrierAccountNumberRequired(boolean losingCarrierAccountNumberRequired) {
    LosingCarrierAccountNumberRequired = losingCarrierAccountNumberRequired;
  }

  public boolean isLosingCarrierMinimumPortingInterval() {
    return losingCarrierMinimumPortingInterval;
  }

  public void setLosingCarrierMinimumPortingInterval(boolean losingCarrierMinimumPortingInterval) {
    this.losingCarrierMinimumPortingInterval = losingCarrierMinimumPortingInterval;
  }
}
