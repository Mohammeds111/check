package com.did.portin.service;

import com.did.portin.model.db.State;
import com.did.portin.mybatis.StateMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StateService {

    @Autowired private StateMapper stateMapper;

    public List<State> getStateLists() {
        return stateMapper.getListStates();
    }
}
