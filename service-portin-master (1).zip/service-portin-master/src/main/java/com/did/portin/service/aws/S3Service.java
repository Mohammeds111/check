package com.did.portin.service.aws;

import java.io.InputStream;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.core.sync.ResponseTransformer;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.DeleteObjectRequest;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.ListObjectsRequest;
import software.amazon.awssdk.services.s3.model.ListObjectsResponse;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;
import software.amazon.awssdk.services.s3.model.S3Object;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;

@Service
public class S3Service {

  @Inject
  @Named("did.processing.s3.bucketName")
  private String s3BucketName;

  @Inject
  @Named("did.processing.s3.region")
  private String s3Region;

  private S3Client s3;

  @PostConstruct
  private void init() {
    s3 = S3Client.builder().region(Region.of(s3Region)).build();
  }

  public void uploadFiles(byte[] byteArray, String filePath) {
    RequestBody requestBody = RequestBody.fromBytes(byteArray);
    s3.putObject(
        PutObjectRequest.builder().bucket(s3BucketName).key(filePath).build(), requestBody);
  }

  private List<S3Object> listObjects(String directory) {
    ListObjectsRequest listObjects =
        ListObjectsRequest.builder().bucket(s3BucketName).prefix(directory).build();
    ListObjectsResponse res = s3.listObjects(listObjects);
    return res.contents();
  }

  public void deleteDirectory(String directory) {
    for (S3Object file : listObjects(directory)) {
      DeleteObjectRequest deleteObjectRequest =
          DeleteObjectRequest.builder().bucket(s3BucketName).key(file.key()).build();
      s3.deleteObject(deleteObjectRequest);
    }
  }

  public void deleteFile(String fileUri) {
    DeleteObjectRequest deleteObjectRequest =
        DeleteObjectRequest.builder().bucket(s3BucketName).key(fileUri).build();
    s3.deleteObject(deleteObjectRequest);
  }

  public InputStream getFileAsByteArray(String sourceFilePath) {
    return s3.getObject(
            GetObjectRequest.builder().bucket(s3BucketName).key(sourceFilePath).build(), ResponseTransformer.toInputStream());
  }

}
