package com.did.portin.model.bandwidth;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

@Root(name = "FileMetaData  ", strict = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class FileMetaData {
  @Element(name = "DocumentName", required = false)
  private String documentName;

  @Element(name = "DocumentType", required = false)
  private String documentType;

  public String getDocumentName() {
    return documentName;
  }

  public void setDocumentName(String documentName) {
    this.documentName = documentName;
  }

  public String getDocumentType() {
    return documentType;
  }

  public void setDocumentType(String documentType) {
    this.documentType = documentType;
  }

  public FileMetaData() {}

  public FileMetaData(String documentType) {
    this.documentType = documentType;
  }
}
