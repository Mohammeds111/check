package com.did.portin.util;

public interface PortinConstants {
    public static final String TOLL_FREE_CARRIER_NAME = "Toll free carrier";
    public static final String COMMA = ",";
}
