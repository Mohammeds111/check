package com.did.portin.client;

import com.did.portin.model.bandwidth.BulkPortinRequest;
import com.did.portin.model.bandwidth.BulkPortinResponse;
import com.did.portin.model.bandwidth.FileMetaData;
import com.did.portin.model.bandwidth.FileUploadResponse;
import com.did.portin.model.bandwidth.LOAFileListResponse;
import com.did.portin.model.bandwidth.LnpOrderResponse;
import com.did.portin.model.bandwidth.LnpOrderSupp;
import com.did.portin.model.bandwidth.Notes;
import com.did.portin.model.bandwidth.NumberPortabilityRequest;
import com.did.portin.model.bandwidth.NumberPortabilityResponse;
import com.did.portin.model.bandwidth.OrderHistoryWrapper;
import com.did.portin.model.bandwidth.PortinListResponse;
import com.did.portin.model.bandwidth.TnList;
import com.did.portin.model.bandwidth.TnListResponse;
import okhttp3.MultipartBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Part;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface BandwidthClient {

  /**
   * Retrieves Notes associated with an Order
   *
   * @param authorization Auth Header
   * @param orderId Order ID
   * @return Notes
   */
  @GET("portins/{orderId}/notes")
  Call<Notes> notes(@Header("Authorization") String authorization, @Path("orderId") String orderId);

  /**
   * Get Files associated with an Order
   *
   * @param authorization Auth Header
   * @param orderId Order ID
   * @return LOAFileListResponse
   */
  @GET("portins/{orderId}/loas")
  Call<LOAFileListResponse> loaFilesDetails(
      @Header("Authorization") String authorization,
      @Path("orderId") String orderId,
      @Query("metadata") String metadata);

  /**
   * Create Bulk porting
   *
   * @param authorization Auth Header
   * @param bulkPortinRequest BulkPortinRequest
   * @return BulkPortinResponse
   */
  @POST("bulkPortins")
  Call<BulkPortinResponse> bulkPortins(
      @Header("Authorization") String authorization, @Body BulkPortinRequest bulkPortinRequest);

  /**
   * Delete Bulk Portin Order
   *
   * @param authorization
   * @param orderId
   * @return ResponseBody
   */
  @DELETE("bulkPortins/{orderId}")
  Call<ResponseBody> deleteBulkPortinOrder(
      @Header("Authorization") String authorization, @Path("orderId") String orderId);

  /**
   * Get OrderID of submitted telephone numbers
   *
   * @param authorization Auth Header
   * @param orderId Order ID
   * @param tnList List of TNs
   * @return TnListResponse
   */
  @PUT("bulkPortins/{orderId}/tnList")
  Call<TnListResponse> bulkPortinsTnListSubmit(
      @Header("Authorization") String authorization,
      @Path("orderId") String orderId,
      @Body TnList tnList);

  /**
   * Get telephone numbers associated with OrderID
   *
   * @param authorization Auth Header
   * @param orderId Order ID
   * @return TnListResponse
   */
  @GET("bulkPortins/{orderId}/tnList")
  Call<TnListResponse> bulkPortinsTnListFetch(
      @Header("Authorization") String authorization, @Path("orderId") String orderId);

  /*
   * Get PortinOrderList  associated with Bulk Order ID
   * @param authorization Auth Header
   * @param orderId Order ID
   * @return TnListResponse
   */
  @GET("bulkPortins/{orderId}/portinList")
  Call<PortinListResponse> bulkPortinsPortinList(
      @Header("Authorization") String authorization, @Path("orderId") String orderId);

  /**
   * @param authorization
   * @return
   */
  @POST("lnpchecker?")
  Call<NumberPortabilityResponse> lnpchecker(
      @Header("Authorization") String authorization,
      @Query("fullCheck") String fullCheck,
      @Body NumberPortabilityRequest numberPortabilityRequest);

  /*
   * Get PortinOrderID  Details
   * @param authorization Auth Header
   * @param orderId Order ID
   * @return LnpOrderResponse
   */
  @GET("portins/{orderid}")
  Call<LnpOrderResponse> portinOrderDetails(
      @Header("Authorization") String authorization, @Path("orderid") String portinId);

  /*
   * Delete PortinOrder
   * @param authorization Auth Header
   * @param orderId Order ID
   * @return ResponseBody
   */
  @DELETE("portins/{orderid}")
  Call<ResponseBody> deletePortinOrder(
      @Header("Authorization") String authorization, @Path("orderid") String portinOrderId);

  /*
   * @param authorization Auth Header
   * @param orderId Order ID
   * @return LnpOrderResponse
   */
  @PUT("portins/{orderid}")
  Call<LnpOrderResponse> suppPortinOrder(
      @Header("Authorization") String authorization,
      @Path("orderid") String portinId,
      @Body LnpOrderSupp lnpOrderSupp);

  /**
   * @param authorization
   * @param orderid
   * @param file
   * @return
   */
  @Multipart
  @POST("portins/{orderid}/loas")
  Call<FileUploadResponse> uploadFilesToPortinOrder(
      @Header("Authorization") String authorization,
      @Path("orderid") String orderid,
      @Part MultipartBody.Part file);

  /**
   * @param authorization
   * @param orderid
   * @param fileid
   * @param fileMetaData
   * @return
   */
  @PUT("portins/{orderid}/loas/{fileid}/metadata")
  Call<Void> addMetaData(
      @Header("Authorization") String authorization,
      @Path("orderid") String orderid,
      @Path("fileid") String fileid,
      @Body FileMetaData fileMetaData);

  /**
   * @param authorization
   * @param orderid
   * @param fileid
   * @return
   */
  @DELETE("portins/{orderid}/loas/{fileid}")
  Call<FileUploadResponse> deleteFilefromPortinOrder(
      @Header("Authorization") String authorization,
      @Path("orderid") String orderid,
      @Path("fileid") String fileid);

  /**
   * Get PortinOrderID History Details
   *
   * @param authorization Auth Header
   * @param portinId Order ID
   * @return OrderHistoryWrapper
   */
  @GET("portins/{orderid}/history")
  Call<OrderHistoryWrapper> portinOrderHistory(
      @Header("Authorization") String authorization, @Path("orderid") String portinId);
}
