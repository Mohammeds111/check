package com.did.portin.model.bandwidth;

import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

@Root(name = "BulkPortin", strict = false)
public class BulkPortinRequest {

  @Element(name = "ProcessingStatus", required = false)
  String processingStatus;

  @Element(name = "CustomerOrderId", required = false)
  String customerOrderId;

  @Element(name = "SiteId", required = false)
  int siteId;

  @Element(name = "PeerId", required = false)
  int peerId;

  public String getProcessingStatus() {
    return processingStatus;
  }

  public void setProcessingStatus(String processingStatus) {
    this.processingStatus = processingStatus;
  }

  public String getCustomerOrderId() {
    return customerOrderId;
  }

  public void setCustomerOrderId(String customerOrderId) {
    this.customerOrderId = customerOrderId;
  }

  public int getSiteId() {
    return siteId;
  }

  public void setSiteId(int siteId) {
    this.siteId = siteId;
  }

  public int getPeerId() {
    return peerId;
  }

  public void setPeerId(int peerId) {
    this.peerId = peerId;
  }
}
