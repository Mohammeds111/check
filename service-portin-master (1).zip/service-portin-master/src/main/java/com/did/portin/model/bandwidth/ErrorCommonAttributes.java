package com.did.portin.model.bandwidth;

import org.simpleframework.xml.Element;

public class ErrorCommonAttributes {

  @Element(name = "Code", required = false)
  private int code;

  @Element(name = "Description", required = false)
  private String description;

  public int getCode() {
    return code;
  }

  public void setCode(int code) {
    this.code = code;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }
}
