package com.did.portin.service;

import com.did.portin.model.db.PortinOrder;
import com.did.portin.model.rest.PhoneNumberValidationResponse;
import com.did.portin.model.rest.errors.PhoneNumberValidationError;
import com.did.portin.mybatis.PortinOrderMapper;
import com.did.portin.util.PhoneNumberUtility;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import javax.validation.ValidationException;
import java.util.List;
import java.util.Objects;

@Service
public class ValidatePhoneNumberService {

  @Inject private BandwidthClientService bandwidthClientService;

  @Autowired PortinOrderMapper portinOrderMapper;

  /*
   * This method validates List of Phone Numbers for US REGION
   * returns PhoneNumberValidationResponse
   */

  public PhoneNumberValidationResponse validatePhoneNumbers(
      List<String> phoneNumbers, Long portinOrderId) {
    // Empty check for Phone numbers
    if (CollectionUtils.isEmpty(phoneNumbers)) {
      throw new ValidationException("Phone Number must not be empty.");
    }
    PortinOrder portinOrder = null;
    if (Objects.nonNull(portinOrderId)) {
      if (portinOrderId.longValue() <= 0) {
        throw new ValidationException("Portin Order ID can not be zero or less than zero.");
      } else {
        // Check if portinorderId exists in database
        portinOrder = portinOrderMapper.getPortinOrderById(portinOrderId);
        if (Objects.isNull(portinOrder)) {
          throw new ValidationException("Portin Order Id not found.");
        }
      }
    }

    List<PhoneNumberValidationError> errors =
        PhoneNumberUtility.validatePhonenumbers(phoneNumbers, portinOrder, bandwidthClientService);

    PhoneNumberValidationResponse phoneNumberValidationResponse =
        new PhoneNumberValidationResponse();
    phoneNumberValidationResponse.setValidationErrors(errors);

    if (errors.size() > 0) {
      phoneNumberValidationResponse.setValidPhoneNumbers("No");
    } else {
      phoneNumberValidationResponse.setValidPhoneNumbers("Yes");
    }
    return phoneNumberValidationResponse;
  }
}
