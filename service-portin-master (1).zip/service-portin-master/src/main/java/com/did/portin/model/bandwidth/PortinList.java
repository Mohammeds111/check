package com.did.portin.model.bandwidth;

import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Root;

import java.util.List;

@Root(name = "PortinList", strict = false)
public class PortinList {
    @ElementList(entry = "PortinOrderId", inline = true ,required = false)
    private List<String> portinOrderId;

    public List<String> getPortinOrderId() {
        return portinOrderId;
    }

    public void setPortinOrderId(List<String> portinOrderId) {
        this.portinOrderId = portinOrderId;
    }
}
