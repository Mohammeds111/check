package com.did.portin.model.enums;

public enum PortinRequestStatus {

    // Portin order status candidates
    DRAFT(0, "Draft"),
    SUBMITTED(1, "Submitted"),
    REJECTED(2, "Rejected"),
    CUSTOMER_CANCELLED(3, "Customer Cancelled"),
    COMPLETE(4, "Complete"),
    SCHEDULED_FOR_DELETE(5, "Scheduled for Delete");

    private long statusId;
    private String statusName;

    PortinRequestStatus(int statusId, String statusName) {
        this.statusId = statusId;
        this.statusName = statusName;
    }

    public long getStatusId() {
        return this.statusId;
    }

    public String getStatusName() {
        return this.statusName;
    }

    public static PortinRequestStatus getStatusTypeFromId(long statusId) {
        for (PortinRequestStatus portinRequestStatus : PortinRequestStatus.values()) {
            if (portinRequestStatus.getStatusId() == statusId) {
                return portinRequestStatus;
            }
        }

        return null;
    }
}