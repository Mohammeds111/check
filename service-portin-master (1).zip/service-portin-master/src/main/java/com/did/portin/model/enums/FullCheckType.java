package com.did.portin.model.enums;

public enum FullCheckType {

    // Portin type candidates
    TRUE("true"),
    FALSE("false"),
    ONNETPORTABILITY("onnetportability"),
    OFFNETPORTABILITY("offnetportability");

    private String fullCheck;

    FullCheckType(String fullCheck) {
        this.fullCheck = fullCheck;
    }

    public String getFullCheck() {
        return this.fullCheck;
    }

    public static FullCheckType getFullCheckFromName(String fullCheck) {
        for (FullCheckType checkType : FullCheckType.values()) {
            if (checkType.name().equalsIgnoreCase(fullCheck)) {
                return checkType;
            }
        }

        return null;
    }
}