package com.did.portin.mybatis;

import com.did.portin.model.db.PortinRequestFile;
import com.did.portin.model.file.DidFileSystem;
import com.did.portin.model.rest.PortinFileRespose;
import java.util.List;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

public interface PortinFileSystemMapper {

  @Insert({
    "INSERT INTO portin.did_file_system("
        + "file_name, "
        + "file_uri, "
        + "created_date "
        + ")"
        + "VALUES"
        + "("
        + "#{didFileSystem.fileName},"
        + "#{didFileSystem.fileUri},"
        + "current_timestamp"
        + ") RETURNING file_id"
  })
  @Options(
      useGeneratedKeys = true,
      keyProperty = "didFileSystem.fileId",
      keyColumn = "file_id",
      flushCache = Options.FlushCachePolicy.TRUE)
  Long saveToFileSystem(@Param("didFileSystem") DidFileSystem didFileSystem);

  @Insert({
    "INSERT INTO portin.portin_request_file("
        + "portin_request_id, "
        + "portin_order_id, "
        + "portin_file_type, "
        + "file_id, "
        + "external_api_file_name,"
        + "signed_date"
        + ")"
        + " VALUES "
        + "("
        + "#{portinRequestFile.portinRequestId},"
        + "#{portinRequestFile.portinOrderId},"
        + "#{portinRequestFile.portinFileTypeId},"
        + "#{portinRequestFile.fileId},"
        + "#{portinRequestFile.externalApiFileName},"
        + "#{portinRequestFile.signedDate}"
        + ") RETURNING portin_request_file_id"
  })
  @Options(
      useGeneratedKeys = true,
      keyProperty = "portinRequestFile.portinRequestFileId",
      keyColumn = "portin_request_file_id",
      flushCache = Options.FlushCachePolicy.TRUE)
  Long saveToPortinRequestFile(@Param("portinRequestFile") PortinRequestFile portinRequestFile);

  @Select(
      "SELECT "
          + "prf.portin_request_file_id as portin_request_file_id, "
          + "prf.portin_request_id as portin_request_id, "
          + "prf.portin_order_id as portin_order_id, "
          + "prf.portin_file_type as portin_file_type, "
          + "prf.file_id as file_id, "
          + "prf.external_api_file_name as external_api_file_name, "
          + "prf.signed_date as signed_date, "
          + "dfs.file_name as file_name, "
          + "dfs.file_uri as file_uri, "
          + "dfs.created_date as created_date "
          + "FROM "
          + "portin.portin_request_file prf, "
          + "portin.did_file_system dfs "
          + "WHERE prf.file_id = dfs.file_id "
          + " AND "
          + "prf.portin_request_file_id=#{portinRequestFileId}")
  @Results({
    @Result(property = "portinRequestFileId", column = "portin_request_file_id"),
    @Result(property = "portinRequestId", column = "portin_request_id"),
    @Result(property = "portinOrderId", column = "portin_order_id"),
    @Result(property = "portinFileType", column = "portin_file_type"),
    @Result(property = "fileId", column = "file_id"),
    @Result(property = "fileName", column = "file_name"),
    @Result(property = "fileUri", column = "file_uri"),
    @Result(property = "createdDate", column = "created_date"),
    @Result(property = "externalApiFileName", column = "external_api_file_name"),
    @Result(property = "signedDate", column = "signed_date")
  })
  PortinFileRespose getPortinRequestFile(@Param("portinRequestFileId") Long portinRequestFileId);

  @Select(
      "SELECT "
          + "portin_request_file_id "
          + "FROM "
          + "portin.portin_request_file "
          + "WHERE "
          + "portin_request_file_id = #{portinRequestFileId} ")
  @Results({@Result(property = "portinRequestFileId", column = "portin_request_file_id")})
  public PortinFileRespose getPortinRequestFileId(
      @Param("portinRequestFileId") Long portinRequestFileId);

  @Select(
      "SELECT "
          + "portin_request_id "
          + "portin_order_id "
          + "FROM "
          + "portin.portin_request_file "
          + "WHERE "
          + "portin_request_id = #{portinRequestId} "
          + " AND "
          + "portin_order_id = #{portinOrderId} "
          + "LIMIT 1")
  @Results({
    @Result(property = "portinRequestId", column = "portin_request_id"),
    @Result(property = "portinOrderId", column = "portin_order_id")
  })
  public PortinFileRespose getPortinRequestIds(
      @Param("portinRequestId") Long portinRequestId, @Param("portinOrderId") Long portinOrderId);

  @Delete(
      "DELETE FROM portin.portin_request_file WHERE portin_request_file_id = #{portinRequestFileId}")
  void deletePortinRequestFileByFileId(@Param("portinRequestFileId") Long portinRequestFileId);

  @Delete("DELETE FROM portin.did_file_system WHERE file_uri ILIKE #{directory}")
  void deleteByFileUri(@Param("directory") String directory);

  @Delete("DELETE FROM portin.did_file_system WHERE file_id = #{fileId}")
  void deleteFileSystemByFileId(@Param("fileId") Long fileId);

  @Select(
      "<script> "
          + "SELECT "
          + "prf.portin_request_file_id as portin_request_file_id, "
          + "prf.portin_request_id as portin_request_id, "
          + "prf.portin_order_id as portin_order_id, "
          + "prf.portin_file_type as portin_file_type, "
          + "prf.file_id as file_id, "
          + "prf.external_api_file_name as external_api_file_name, "
          + "prf.signed_date as signed_date, "
          + "dfs.file_name as file_name, "
          + "dfs.file_uri as file_uri, "
          + "dfs.created_date as created_date "
          + "FROM "
          + "portin.portin_request_file prf, "
          + "portin.did_file_system dfs "
          + "WHERE prf.file_id = dfs.file_id "
          + "AND "
          + "prf.portin_request_id = #{portinRequestId} "
          + "AND "
          + "prf.portin_order_id = #{portinOrderId} "
          + "</script>")
  @Results({
    @Result(property = "portinRequestFileId", column = "portin_request_file_id"),
    @Result(property = "portinRequestId", column = "portin_request_id"),
    @Result(property = "portinOrderId", column = "portin_order_id"),
    @Result(property = "portinFileType", column = "portin_file_type"),
    @Result(property = "fileId", column = "file_id"),
    @Result(property = "fileName", column = "file_name"),
    @Result(property = "fileUri", column = "file_uri"),
    @Result(property = "createdDate", column = "created_date"),
    @Result(property = "externalApiFileName", column = "external_api_file_name"),
    @Result(property = "signedDate", column = "signed_date")
  })
  public List<PortinFileRespose> getFileDetails(
      @Param("portinRequestId") Long portinRequestId, @Param("portinOrderId") Long portinOrderId);

  @Update(
      "<script>"
          + "Update portin.portin_request_file "
          + "<set>"
          + "<if test='portinFileRespose.externalApiFileName != null'>external_api_file_name = #{portinFileRespose.externalApiFileName}, </if>"
          + "</set>"
          + "WHERE "
          + "portin_request_file_id = #{portinFileRespose.portinRequestFileId}"
          + "</script>")
  public void updatePortinRequestFileById(
      @Param("portinFileRespose") PortinFileRespose portinFileRespose);
}
