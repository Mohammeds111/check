package com.did.portin.model.file;

import java.util.Date;

public class DidFileSystem {
  private Long fileId;
  private String fileName;
  private String fileUri;
  private Date createdDate;

  public DidFileSystem() {}

  public DidFileSystem(Long fileId, String fileName) {
    this.fileId = fileId;
    this.fileName = fileName;
  }

  public Long getFileId() {
    return fileId;
  }

  public void setFileId(Long fileId) {
    this.fileId = fileId;
  }

  public String getFileName() {
    return fileName;
  }

  public void setFileName(String fileName) {
    this.fileName = fileName;
  }

  public String getFileUri() {
    return fileUri;
  }

  public void setFileUri(String fileUri) {
    this.fileUri = fileUri;
  }

  public Date getCreatedDate() {
    return createdDate;
  }

  public void setCreatedDate(Date createdDate) {
    this.createdDate = createdDate;
  }
}
