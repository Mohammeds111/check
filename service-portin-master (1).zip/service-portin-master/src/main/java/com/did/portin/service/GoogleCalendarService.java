package com.did.portin.service;

import com.did.portin.client.GoogleCalendarClient;
import com.did.portin.model.gcalendar.BlackoutSchedule;
import com.google.api.client.util.DateTime;
import com.google.api.services.calendar.model.Event;
import com.google.api.services.calendar.model.Events;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

@Service
public class GoogleCalendarService {

  public static final String BLACKOUT_SEARCH_STR = "Blackout";
  @Inject GoogleCalendarClient googleCalendarClient;

  public List<BlackoutSchedule> getBlackoutDates() throws Exception {
    // List the next 10 events from the primary calendar.
    DateTime now = new DateTime(System.currentTimeMillis());
    Events events =
        googleCalendarClient
            .getCalendarClient()
            .events()
            .list("primary")
            .setMaxResults(10)
            .setTimeMin(now)
            .setOrderBy("startTime")
            .setSingleEvents(true)
            .setShowDeleted(false)
            .setQ(BLACKOUT_SEARCH_STR)
            .execute();
    List<Event> items = events.getItems();
    List<BlackoutSchedule> blackoutSchedules = new ArrayList<>();
    if (items.isEmpty()) {
      return blackoutSchedules;
    } else {
      for (Event event : items) {
        DateTime start = event.getStart().getDateTime();
        if (start == null) {
          start = event.getStart().getDate();
        }
        DateTime end = event.getEnd().getDateTime();
        if (end == null) {
          end = event.getEnd().getDate();
        }
        blackoutSchedules.add(
            new BlackoutSchedule(
                event.getSummary(),
                new Timestamp(start.getValue()),
                new Timestamp(end.getValue())));
      }
      return blackoutSchedules;
    }
  }
}
