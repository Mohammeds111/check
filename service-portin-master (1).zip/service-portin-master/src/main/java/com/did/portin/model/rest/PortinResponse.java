package com.did.portin.model.rest;

import com.did.portin.model.pagination.Pagination;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class PortinResponse<T> {
    private String msg;
    private int status;
    private T data;
    private Pagination pagination;

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public Pagination getPagination() {
        return pagination;
    }

    public void setPagination(Pagination pagination) {
        this.pagination = pagination;
    }

    public static PortinResponse generateResponse(String msg, int status, Object data){
        PortinResponse response = new PortinResponse<Object>();
        response.setMsg(msg);
        response.setStatus(status);
        response.setData(data);
        return response;
    }

    public static PortinResponse generateResponse(String msg, int status, Object data, Pagination pagination){
        PortinResponse response = new PortinResponse<Object>();
        response.setMsg(msg);
        response.setStatus(status);
        response.setData(data);
        response.setPagination(pagination);
        return response;
    }
}
