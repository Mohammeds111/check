package com.did.portin.model.bandwidth;

import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Root;

import java.util.List;

@Root(name = "ListOfPhoneNumbers", strict = false)
public class ListOfPhoneNumbers {
    @ElementList(entry = "PhoneNumber", inline = true)
    private List<String> phoneNumber;

    public List<String> getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(List<String> phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
}
