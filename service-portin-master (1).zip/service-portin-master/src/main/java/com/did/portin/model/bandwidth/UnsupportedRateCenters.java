package com.did.portin.model.bandwidth;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Root;

import java.util.List;

@Root(name = "UnsupportedRateCenters", strict = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UnsupportedRateCenters {

  @ElementList(name = "RateCenterGroup", inline = true, required = false)
  private List<RateCenterGroup> rateCenterGroups;

  public List<RateCenterGroup> getRateCenterGroups() {
    return rateCenterGroups;
  }

  public void setRateCenterGroups(List<RateCenterGroup> rateCenterGroups) {
    this.rateCenterGroups = rateCenterGroups;
  }
}
