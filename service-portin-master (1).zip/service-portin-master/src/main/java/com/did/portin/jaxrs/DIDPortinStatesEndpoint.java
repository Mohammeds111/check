package com.did.portin.jaxrs;


import com.did.portin.model.rest.PortinResponse;
import com.did.portin.service.StateService;
import javax.inject.Inject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DIDPortinStatesEndpoint {

    @Inject
    private StateService stateService;

    @RequestMapping("/states")
    public PortinResponse getStates()
    {
        return PortinResponse.generateResponse("Ok", 0, stateService.getStateLists());
    }
}
