package com.did.portin.model.rest;

import com.did.portin.model.db.PortinOrder;
import com.did.portin.model.rest.errors.Error;
import com.did.portin.model.rest.errors.PhoneNumberValidationError;
import java.util.List;

public class PortinOrderUpdateResponse {
    private boolean orderUpdatedToDatabase;
    private List<Error> validationErrors;
    private List<PhoneNumberValidationError> invalidNumbers;
    private PortinOrder latestPortinOrder;

    public boolean isOrderUpdatedToDatabase() {
        return orderUpdatedToDatabase;
    }

    public void setOrderUpdatedToDatabase(boolean orderUpdatedToDatabase) {
        this.orderUpdatedToDatabase = orderUpdatedToDatabase;
    }

    public List<Error> getValidationErrors() {
        return validationErrors;
    }

    public void setValidationErrors(List<Error> validationErrors) {
        this.validationErrors = validationErrors;
    }

    public List<PhoneNumberValidationError> getInvalidNumbers() {
        return invalidNumbers;
    }

    public void setInvalidNumbers(List<PhoneNumberValidationError> invalidNumbers) {
        this.invalidNumbers = invalidNumbers;
    }

    public PortinOrder getLatestPortinOrder() {
        return latestPortinOrder;
    }

    public void setLatestPortinOrder(PortinOrder latestPortinOrder) {
        this.latestPortinOrder = latestPortinOrder;
    }
}
