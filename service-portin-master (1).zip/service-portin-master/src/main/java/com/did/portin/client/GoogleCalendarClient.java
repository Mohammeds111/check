package com.did.portin.client;

import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.services.calendar.Calendar;

import java.io.IOException;
import java.security.GeneralSecurityException;

/**
 * This Client will be replaced with existing service-pigeon Google client approach when we ship the
 * code.
 */
public class GoogleCalendarClient {

  private static final JsonFactory JSON_FACTORY = JacksonFactory.getDefaultInstance();

  // TODO move secrets to properties
  public Credential authorize() throws Exception {
    try {
      return new GoogleCredential.Builder()
          .setTransport(GoogleNetHttpTransport.newTrustedTransport())
          .setJsonFactory(JSON_FACTORY)
          .setClientSecrets(
              "1047497065976-pmclu07679mij4258b8l4fhfdj9d82e0.apps.googleusercontent.com",
              "gJuxhTdwlaxn2Ws-QmN3ifxS")
          .build()
          .setAccessToken(
              "ya29.a0Ae4lvC2G7TPIl2N-NobHD1AxKlCZy1h7xkrQzEofKqZocG64vNbVFt8Nr2KBgBCg1GmDxxagXuiYpJ0zz1ue9VT927SJQS-eKkfNB54oFVRQJwJktIpii5e3QFPk03c0a1a6YDR2ZBnn4Su-Fz9e8eSuh5SsHFFnA24")
          .setRefreshToken(
              "1//0gBRwILzUwzxsCgYIARAAGBASNwF-L9IryApkiH1mcED0_4-W_vxfcIhrwj5jfgROFNs50sgZo0HswoobuN9idLS3t2U2bCJ4dME");
    } catch (GeneralSecurityException | IOException ex) {
      throw new Exception(
          "Failed to authenticate with Google calendar API using the refresh/access tokens provided",
          ex);
    }
  }

  public Calendar getCalendarClient() throws Exception {
    // Build a new authorized API client service.
    final NetHttpTransport HTTP_TRANSPORT = GoogleNetHttpTransport.newTrustedTransport();
    return new Calendar.Builder(HTTP_TRANSPORT, JSON_FACTORY, authorize()).build();
  }
}
