package com.did.portin.service;

import com.did.portin.model.bandwidth.BulkPortin;
import com.did.portin.model.bandwidth.BulkPortinRequest;
import com.did.portin.model.bandwidth.BulkPortinResponse;
import com.did.portin.model.bandwidth.LnpOrderResponse;
import com.did.portin.model.bandwidth.NonPortableTnList;
import com.did.portin.model.bandwidth.NumberPortabilityRequest;
import com.did.portin.model.bandwidth.NumberPortabilityResponse;
import com.did.portin.model.bandwidth.PortinList;
import com.did.portin.model.bandwidth.PortinListResponse;
import com.did.portin.model.bandwidth.RateCenterGroup;
import com.did.portin.model.bandwidth.SupportedRateCenters;
import com.did.portin.model.bandwidth.TnList;
import com.did.portin.model.bandwidth.TnListAlt;
import com.did.portin.model.bandwidth.TnListResponse;
import com.did.portin.model.db.PortinOrder;
import com.did.portin.model.db.PortinRequest;
import com.did.portin.model.enums.FullCheckType;
import com.did.portin.model.enums.PhoneNumberType;
import com.did.portin.model.enums.PortinOrderStatus;
import com.did.portin.model.enums.PortinRequestStatus;
import com.did.portin.model.enums.PortinType;
import com.did.portin.model.rest.CheckPortabilityResponse;
import com.did.portin.model.rest.PortinOrderStatistics;
import com.did.portin.model.rest.errors.PhoneNumberValidationError;
import com.did.portin.mybatis.PortinOrderMapper;
import com.did.portin.mybatis.PortinRequestMapper;
import com.did.portin.util.ConversionUtil;
import com.did.portin.util.PhoneNumberUtility;
import com.did.portin.util.PortinConstants;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import javax.inject.Named;
import javax.validation.ValidationException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CheckPortabilityService {

  private static final Logger logger = LoggerFactory.getLogger(CheckPortabilityService.class);

  @Inject private BandwidthClientService bandwidthClientService;

  @Inject private PortinOrderService portinOrderService;

  @Autowired PortinOrderMapper portinOrderMapper;

  @Autowired
  PortinRequestMapper portinRequestMapper;

  @Inject
  @Named("bandwidth.api.siteid")
  private int bandwidthSiteId;

  @Inject
  @Named("bandwidth.api.peerid")
  private int bandwidthPeerId;

  @Transactional
  public CheckPortabilityResponse checkPortability(
      List<String> phoneNumbers, Long portinRequestId,boolean startOver) {
    // Empty check for Phone numbers
    if (CollectionUtils.isEmpty(phoneNumbers)) {
      throw new ValidationException("Phone Number must not be empty.");
    }

    if (Optional.ofNullable(portinRequestId).orElse(0L) <= 0) {
      throw new NullPointerException();
      //throw new ValidationException("Did portin request ID can not be zero or less than zero.");
    }
    PortinRequest portinRequest = portinRequestMapper.getPortinRequestDetail(portinRequestId);
    if(Objects.isNull(portinRequest)) {
      throw new ValidationException("Portin Request Id not found.");
    }

    CheckPortabilityResponse checkPortabilityResponse = new CheckPortabilityResponse();

    //To check the startOver
    if(startOver){
      portinOrderMapper.deletePortOrder(portinRequestId);
    }

    List<PhoneNumberValidationError> invalidPhoneNumbers =
        PhoneNumberUtility.validatePhonenumbers(phoneNumbers, null, null);

    // set invalid phone numbers to response
    if(CollectionUtils.isNotEmpty(invalidPhoneNumbers)){
      checkPortabilityResponse.setInvalidNumbers(invalidPhoneNumbers);

      portinRequest.setPhoneNumbers(String.join(StringUtils.SPACE, phoneNumbers));
      portinRequest.setRequestedQuantity(phoneNumbers.size());
      // Update portin-request with latest phone numbers info & stop processing further
      portinRequestMapper.updatePortinRequest(portinRequest);

      // Set empty stats to response
      PortinOrderStatistics portinOrderStatistics = new PortinOrderStatistics();
      checkPortabilityResponse.setStats(portinOrderStatistics);
    } else {
      // Proceed with Bandwidth API calls for creating orders.
      BulkPortinRequest bulkPortinRequest = new BulkPortinRequest();
      bulkPortinRequest.setProcessingStatus(PortinRequestStatus.DRAFT.getStatusName());
      bulkPortinRequest.setSiteId(bandwidthSiteId);
      bulkPortinRequest.setPeerId(bandwidthPeerId);

      BulkPortinResponse bulkPortinResponse = null;

      // Create bulk portin order
      try {
        bulkPortinResponse = bandwidthClientService.createBulkPortin(bulkPortinRequest);
      } catch (Exception e) {
        logger.error("Exception in CheckPortabilityService.checkPortability.createBulkPortin",e);
      }

      if (Objects.nonNull(bulkPortinResponse)) {
        BulkPortin bulkPortin = bulkPortinResponse.getBulkPortin();
        String bwOrderId = bulkPortin.getOrderId();

        // Set the BulkPortOrderNumber to portin request
        portinRequest.setBulkPortOrderNumber(bwOrderId);
        portinRequest.setPhoneNumbers(String.join(StringUtils.SPACE, phoneNumbers));
        portinRequest.setRequestedQuantity(phoneNumbers.size());

        TnList tnList = new TnList();
        tnList.setTns(phoneNumbers);
        TnListResponse tnListResponse = null;

        // Initialize counters for stats preparation
        List<String> carriers = new ArrayList<>();
        List<String> rateCenters = new ArrayList<>();
        List<String> wirelessNumbers = new ArrayList<>();
        List<String> wiredNumbers = new ArrayList<>();
        List<String> tollfreeNumbers = new ArrayList<>();

        // PUT / Update tnList to bulk portin order
        try {
          tnListResponse = bandwidthClientService.addTNsToBulkPortInOrder(bwOrderId, tnList);
        } catch (Exception e) {
          logger.error("Exception in CheckPortabilityService.checkPortability.addTNsToBulkPortInOrder",e);
        }

        // Get the bulk portin order details
        try {
          tnListResponse = bandwidthClientService.getTNsFromBulkPortInOrder(bwOrderId);
        } catch (Exception e) {
          logger.error("Exception in CheckPortabilityService.checkPortability.getTNsFromBulkPortInOrder",e);
        }

        if (Objects.nonNull(tnListResponse)) {
          NonPortableTnList nonPortableTnList = tnListResponse.getNonPortableTnList();
          List<String> unsupportedNumbers = null;
          // Set the non portable numbers to portin request
          if (CollectionUtils.isNotEmpty(nonPortableTnList.getTns())) {
            unsupportedNumbers = nonPortableTnList.getTns();
            String nonPortableNumbers = String.join(StringUtils.SPACE, unsupportedNumbers);
            portinRequest.setNonPortableNumbers(nonPortableNumbers);
            // set Unsupported phone numbers to response
            checkPortabilityResponse.setUnsupportedNumbers(unsupportedNumbers);
          }

          if(CollectionUtils.isEmpty(tnListResponse.getValidTnList().getTns())) {
            return checkPortabilityResponse;
          }

          // Update portin-request with latest info
          portinRequestMapper.updatePortinRequest(portinRequest);

          PortinListResponse portinListResponse = null;
          try {
            portinListResponse = bandwidthClientService.getPortinListForBulkPortInOrder(bwOrderId);
          } catch (Exception e) {
            logger.error("Exception in CheckPortabilityService.checkPortability.getPortinListForBulkPortInOrder",e);
          }

          List<PortinOrder> portinOrders = new ArrayList<>();

          if (Objects.nonNull(portinListResponse)) {
            PortinList portinList = portinListResponse.getPortinList();
            // Iterate and save available orderIds
            for (String portinOrderId : portinList.getPortinOrderId()) {
              PortinOrder portinOrder = new PortinOrder();
              portinOrder.setPortinExternalSystemOrderId(portinOrderId);
              portinOrder.setOrderStatus(PortinOrderStatus.PENDING_DOCUMENTS.getStatusId());
              portinOrder.setPortinRequestId(portinRequestId);

              LnpOrderResponse lnpOrderResponse = null;
              try {
                lnpOrderResponse = bandwidthClientService.getPortinOrderDetails(portinOrderId);
              } catch (Exception e) {
                logger.error("Exception in CheckPortabilityService.checkPortability.getPortinOrderDetails",e);
              }

              if (Objects.nonNull(lnpOrderResponse)) {
                if (StringUtils.isNotEmpty(lnpOrderResponse.getEarliestEstimate())) {
                  portinOrder.setSuggestedActivationDate(
                      ConversionUtil.convertToTimestamp(
                          lnpOrderResponse.getEarliestEstimate(),
                          ConversionUtil.BW_EE_DATE_FORMAT));
                }

                if (StringUtils.isNotEmpty(lnpOrderResponse.getRequestedFocDate())) {
                  portinOrder.setRequestedActivationDate(
                      ConversionUtil.convertToTimestamp(lnpOrderResponse.getRequestedFocDate()));
                }

                if (Objects.nonNull(lnpOrderResponse.getListOfPhoneNumbers())) {
                  List<String> phoneNumbersFromOrder = lnpOrderResponse.getListOfPhoneNumbers().getPhoneNumber();
                  portinOrder.setPhoneNumbers(
                      String.join(
                          StringUtils.SPACE,
                              phoneNumbersFromOrder));
                  portinOrder.setRequestedQuantity(
                          phoneNumbersFromOrder.size());

                  // Check whether phone numbers are unsupported or not
                  // if these phone numbers are unportable then this order is useless for us
                  // hence we need to skip this order & its further processing
                  if (CollectionUtils.isNotEmpty(unsupportedNumbers)) {
                    List<String> foundUnportableNumbers =
                        unsupportedNumbers.stream()
                            .filter(phoneNumbersFromOrder::contains)
                            .collect(Collectors.toList());

                    if (unsupportedNumbers.size() == foundUnportableNumbers.size()
                            && phoneNumbersFromOrder.size() == unsupportedNumbers.size()){
                      continue;
                    }
                  }

                }

                if (StringUtils.isNotEmpty(lnpOrderResponse.getLosingCarrierName())) {
                  portinOrder.setLocCarrierName(lnpOrderResponse.getLosingCarrierName());
                  if (!PortinConstants.TOLL_FREE_CARRIER_NAME.equalsIgnoreCase(
                      lnpOrderResponse.getLosingCarrierName())) {
                    carriers.add(lnpOrderResponse.getLosingCarrierName());
                  }
                }

                if (StringUtils.isNotEmpty(lnpOrderResponse.getLosingCarrierSPID())) {
                  portinOrder.setLocCarrierSpid(lnpOrderResponse.getLosingCarrierSPID());
                }

                if (StringUtils.isNotEmpty(lnpOrderResponse.getOrderCreateDate())) {
                  portinOrder.setOrderDate(
                      ConversionUtil.convertToTimestamp(lnpOrderResponse.getOrderCreateDate()));
                }

                if (StringUtils.isNotEmpty(lnpOrderResponse.getProcessingStatus())) {
                  portinOrder.setOrderStatus(
                      PortinOrderStatus.getStatusTypeFromName(
                              lnpOrderResponse.getProcessingStatus())
                          .getStatusId());
                }

                if (StringUtils.isNotEmpty(lnpOrderResponse.getPortType())) {
                  portinOrder.setPortinType(
                      PortinType.getPortinTypeFromName(lnpOrderResponse.getPortType())
                          .getStatusId());
                }

                if (StringUtils.isNotEmpty(lnpOrderResponse.getVendorName())) {
                  portinOrder.setVendorName(lnpOrderResponse.getVendorName());
                }

                // set bandwidth's properties
                if (StringUtils.isNotEmpty(lnpOrderResponse.getPortType())) {
                  portinOrder.setPortinType(PortinType.getPortinTypeFromName(lnpOrderResponse.getPortType()).getStatusId());
                }

                if (StringUtils.isNotEmpty(lnpOrderResponse.getPartialPort())) {
                  portinOrder.setPartialPortin(lnpOrderResponse.getPartialPort());
                }

                if (StringUtils.isNotEmpty(lnpOrderResponse.getTriggered())) {
                  portinOrder.setTriggered(lnpOrderResponse.getTriggered());
                }

                String isWireless = lnpOrderResponse.getLosingCarrierIsWireless();
                if (StringUtils.isNotEmpty(isWireless)) {
                  // Sometimes we are getting UNKNOWN as value here.
                  if (isWireless.equalsIgnoreCase(Boolean.TRUE.toString())) {
                    portinOrder.setLocCarrierIswireless(Boolean.TRUE.toString());
                    isWireless = Boolean.TRUE.toString();
                  } else {
                    portinOrder.setLocCarrierIswireless(Boolean.FALSE.toString());
                    isWireless = Boolean.FALSE.toString();
                  }
                }

                // Check whether carrier named as Toll free carrier
                if (PortinConstants.TOLL_FREE_CARRIER_NAME.equalsIgnoreCase(
                    lnpOrderResponse.getLosingCarrierName())) {
                  portinOrder.setPhoneNumberType(PhoneNumberType.TOLLFREE.getPhoneNumberType());
                  portinOrder.setLoaRequired(Boolean.TRUE.toString());
                  if (CollectionUtils.isNotEmpty(
                      lnpOrderResponse.getListOfPhoneNumbers().getPhoneNumber())) {
                    tollfreeNumbers.addAll(
                        lnpOrderResponse.getListOfPhoneNumbers().getPhoneNumber());
                  }
                } else {
                  portinOrder.setLoaRequired(Boolean.FALSE.toString());
                  // Check whether carrier is wireless or not (this will only available if it is not
                  // a tollfree carrier)
                  if (isWireless.equalsIgnoreCase(Boolean.FALSE.toString())) {
                    portinOrder.setPhoneNumberType(PhoneNumberType.WIRED.getPhoneNumberType());
                    portinOrder.setLocCarrierAccountnumberrequired(Boolean.FALSE.toString());
                    if (CollectionUtils.isNotEmpty(
                        lnpOrderResponse.getListOfPhoneNumbers().getPhoneNumber())) {
                      wiredNumbers.addAll(
                          lnpOrderResponse.getListOfPhoneNumbers().getPhoneNumber());
                    }
                  } else {
                    portinOrder.setPhoneNumberType(PhoneNumberType.WIRELESS.getPhoneNumberType());
                    portinOrder.setLocCarrierAccountnumberrequired(Boolean.TRUE.toString());
                    if (CollectionUtils.isNotEmpty(
                        lnpOrderResponse.getListOfPhoneNumbers().getPhoneNumber())) {
                      wirelessNumbers.addAll(
                          lnpOrderResponse.getListOfPhoneNumbers().getPhoneNumber());
                    }
                  }
                }
              }

              // TODO: Move this lnpchecker to out side of for loop to reduce the number of calls.
              NumberPortabilityResponse numberPortabilityResponse = null;
              try {
                NumberPortabilityRequest numberPortabilityRequest = new NumberPortabilityRequest();
                TnListAlt tnListAlt = new TnListAlt();
                tnListAlt.setTns(lnpOrderResponse.getListOfPhoneNumbers().getPhoneNumber());
                numberPortabilityRequest.setTnList(tnListAlt);

                numberPortabilityResponse =
                    bandwidthClientService.lnpchecker(
                        FullCheckType.OFFNETPORTABILITY.getFullCheck(), numberPortabilityRequest);
              } catch (Exception e) {
                logger.error("Exception in CheckPortabilityService.CheckPortability.lnpchecker",e);
              }

              if (Objects.nonNull(numberPortabilityResponse)) {
                if (Objects.nonNull(numberPortabilityResponse.getSupportedRateCenters())) {
                  List<SupportedRateCenters> supportedRateCenters =
                      numberPortabilityResponse.getSupportedRateCenters();
                  StringBuilder rateCenterData = new StringBuilder();
                  if (CollectionUtils.isNotEmpty(supportedRateCenters)) {
                    SupportedRateCenters supportedRateCenter = supportedRateCenters.get(0);
                    if (Objects.nonNull(supportedRateCenter)) {
                      List<RateCenterGroup> rateCenterGroups =
                          supportedRateCenter.getRateCenterGroups();
                      if (CollectionUtils.isNotEmpty(rateCenterGroups)) {
                        // RateCenters are one to many to an order
                        for (int count = 0; count < rateCenterGroups.size(); count++) {
                          RateCenterGroup rateCenterGroup = rateCenterGroups.get(count);
                          String rateCenter = rateCenterGroup.getRateCenter();
                          if (StringUtils.isNotEmpty(rateCenter)) {
                            rateCenterData.append(rateCenter);
                            if (count < (rateCenterGroups.size() - 1)) {
                              rateCenterData.append(PortinConstants.COMMA);
                            }

                            // Track rate centers for stats
                            rateCenters.add(rateCenter);
                          }
                        }
                      }
                    }
                  }

                  if (StringUtils.isNotEmpty(rateCenterData.toString().trim())) {
                    portinOrder.setRateCenter(rateCenterData.toString().trim());
                  }
                }
              }

              // Set the Organization & requested user details
              portinOrder.setOrganizationCode(portinRequest.getOrganizationCode());
              portinOrder.setOrganizationName(portinRequest.getOrganizationName());
              portinOrder.setRequestedUserId(portinRequest.getRequestedUserId());
              portinOrder.setRequestedUserCode(portinRequest.getRequestedUserCode());
              portinOrder.setRequestedUserEmail(portinRequest.getRequestedUserEmail());
              portinOrder.setRequestedUserFullName(portinRequest.getRequestedUserFullName());

              // Create portin-order record
              portinOrderMapper.insertPortinOrder(portinOrder);

              // Process the Errors for the order, if any
              portinOrder = portinOrderService.processErrorStatusForOrder(lnpOrderResponse, portinOrder);

              portinOrders.add(portinOrder);
            }
          }

          checkPortabilityResponse.setSupportedOrders(portinOrders);

          // Prepare the stats
          PortinOrderStatistics portinOrderStatistics =
              PortinOrderService.generateOrdersStatistics(
                  carriers, rateCenters, wirelessNumbers, wiredNumbers, tollfreeNumbers);
          checkPortabilityResponse.setStats(portinOrderStatistics);
        }
      }
    }

    return checkPortabilityResponse;
  }


}
