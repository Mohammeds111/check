package com.did.portin.model.bandwidth;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

@Root(name = "TnListResponse", strict = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TnListResponse {
  @Element(name = "OrderId", required = false)
  private String orderId;

  @Element(name = "ResponseStatus", required = false)
  private ResponseStatus responseStatus;

  @Element(name = "NonPortableTnList", required = false)
  private NonPortableTnList nonPortableTnList;

  @Element(name = "ValidTnList", required = false)
  private ValidTnList validTnList;

  @Element(name = "InvalidTnList", required = false)
  private InvalidTnList invalidTnList;

  public InvalidTnList getInvalidTnList() {
    return invalidTnList;
  }

  public void setInvalidTnList(InvalidTnList invalidTnList) {
    this.invalidTnList = invalidTnList;
  }

  public NonPortableTnList getNonPortableTnList() {
    return nonPortableTnList;
  }

  public void setNonPortableTnList(NonPortableTnList nonPortableTnList) {
    this.nonPortableTnList = nonPortableTnList;
  }

  public ValidTnList getValidTnList() {
    return validTnList;
  }

  public void setValidTnList(ValidTnList validTnList) {
    this.validTnList = validTnList;
  }

  public String getOrderId() {
    return orderId;
  }

  public void setOrderId(String orderId) {
    this.orderId = orderId;
  }

  public ResponseStatus getResponseStatus() {
    return responseStatus;
  }

  public void setResponseStatus(ResponseStatus responseStatus) {
    this.responseStatus = responseStatus;
  }
}
