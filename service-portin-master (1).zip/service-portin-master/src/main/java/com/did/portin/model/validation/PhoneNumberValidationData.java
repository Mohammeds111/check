package com.did.portin.model.validation;

import java.util.List;
import java.util.Map;

public class PhoneNumberValidationData {
    private List<String> phoneNumbers;
    private Map<String, String> bandwidthErrorCodeAndMessages;
    private String errorMessage;

    public List<String> getPhoneNumbers() {
        return phoneNumbers;
    }

    public void setPhoneNumbers(List<String> phoneNumbers) {
        this.phoneNumbers = phoneNumbers;
    }

    public Map<String, String> getBandwidthErrorCodeAndMessages() {
        return bandwidthErrorCodeAndMessages;
    }

    public void setBandwidthErrorCodeAndMessages(Map<String, String> bandwidthErrorCodeAndMessages) {
        this.bandwidthErrorCodeAndMessages = bandwidthErrorCodeAndMessages;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
}
