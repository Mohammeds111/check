package com.did.portin.model.gcalendar;

import java.sql.Timestamp;

public class BlackoutSchedule {

  private String eventName;
  private Timestamp startDatetimeInUTC;
  private Timestamp endDatetimeInUTC;

  public String getEventName() {
    return eventName;
  }

  public Timestamp getStartDatetimeInUTC() {
    return startDatetimeInUTC;
  }

  public Timestamp getEndDatetimeInUTC() {
    return endDatetimeInUTC;
  }

  public BlackoutSchedule(
      String eventName, Timestamp startDatetimeInUTC, Timestamp endDatetimeInUTC) {
    this.eventName = eventName;
    this.startDatetimeInUTC = startDatetimeInUTC;
    this.endDatetimeInUTC = endDatetimeInUTC;
  }
}
