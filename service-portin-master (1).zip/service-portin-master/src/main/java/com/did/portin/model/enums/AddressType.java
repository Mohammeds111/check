package com.did.portin.model.enums;

public enum AddressType {

    // Address type candidates
    SERVICE("Service");

    private String addressType;

    AddressType(String addressType) {
        this.addressType = addressType;
    }

    public String getAddressType() {
        return this.addressType;
    }

    public static AddressType getAddressTypeByName(String addressTypeName) {
        for (AddressType addressType : AddressType.values()) {
            if (addressType.name().equalsIgnoreCase(addressTypeName)) {
                return addressType;
            }
        }

        return null;
    }
}