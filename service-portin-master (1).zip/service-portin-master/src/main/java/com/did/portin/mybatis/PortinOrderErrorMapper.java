package com.did.portin.mybatis;

import com.did.portin.model.db.PortinOrderError;
import java.util.List;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.ResultType;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface PortinOrderErrorMapper {

  @Insert(
      "<script> "
          + "INSERT INTO portin.portin_order_error ( "
          + "portin_request_id, "
          + "portin_order_id, "
          + "error_code, "
          + "error_description, "
          + "error_status, "
          + "created_date "
          + ") "
          + "VALUES "
          + "<foreach collection='portinOrderErrors' item='portinOrderError' separator=','> "
          + " ( #{portinOrderError.portinRequestId}, #{portinOrderError.portinOrderId}, #{portinOrderError.errorCode}, "
          + "#{portinOrderError.errorDescription}, #{portinOrderError.errorStatus}, current_timestamp ) "
          + "</foreach> "
          + "</script> ")
  public Long insertPortinOrderErrors(
      @Param("portinOrderErrors") List<PortinOrderError> portinOrderErrors);

  @Insert(
      "<script> "
          + "UPDATE portin.portin_order_error "
          + "<set>"
          + "resolved_date = current_timestamp, "
          + "<if test='portinOrderError.errorStatus != null'>error_status = #{portinOrderError.errorStatus}, </if>"
          + "<if test='portinOrderError.resolvedUserId != null'>resolved_user_id = #{portinOrderError.resolvedUserId}, </if>"
          + "<if test='portinOrderError.resolvedUserEmail != null'>resolved_user_email = #{portinOrderError.resolvedUserEmail}, </if>"
          + "<if test='portinOrderError.resolvedUserFullName != null'>resolved_user_fullname = #{portinOrderError.resolvedUserFullName}, </if>"
          + "<if test='portinOrderError.resolvedUserCode != null'>resolved_user_code = #{portinOrderError.resolvedUserCode}, </if>"
          + "</set>"
          + "WHERE "
          + "portin_order_id = #{portinOrderError.portinOrderId} "
          + " AND "
          + " error_code IN (<foreach collection='errorCodesList' item='errorCodetoUpdate' separator=','>#{errorCodetoUpdate}</foreach>) "
          + "</script>")
  public Long updatePortinOrderErrors(
      @Param("portinOrderError") PortinOrderError portinOrderError,
      @Param("errorCodesList") List<String> errorCodesList);

  @Select(
      "SELECT "
          + "portin_order_error_id, "
          + "portin_request_id, "
          + "portin_order_id, "
          + "error_code, "
          + "error_description, "
          + "error_status, "
          + "created_date "
          + "FROM "
          + "portin.portin_order_error "
          + "WHERE "
          + "portin_order_id = #{portinOrderId} "
          + " AND "
          + " error_status = 0 ")
  @Results({
    @Result(property = "portinOrderErrorId", column = "portin_order_error_id"),
    @Result(property = "portinRequestId", column = "portin_request_id"),
    @Result(property = "portinOrderId", column = "portin_order_id"),
    @Result(property = "errorCode", column = "error_code"),
    @Result(property = "errorDescription", column = "error_description"),
    @Result(property = "errorStatus", column = "error_status"),
    @Result(property = "createdDate", column = "created_date")
  })
  public List<PortinOrderError> getOpenPortinOrderErrors(
      @Param("portinOrderId") Long portinOrderId);

  @Select(
          "SELECT "
                  + "error_code "
                  + "FROM "
                  + "portin.portin_order_error "
                  + "WHERE "
                  + "portin_order_id = #{portinOrderId} "
                  + " AND "
                  + " error_status = 0 ")
  @ResultType(String.class)
  public List<String> getOpenPortinOrderErrorCodes(
          @Param("portinOrderId") Long portinOrderId);
}
