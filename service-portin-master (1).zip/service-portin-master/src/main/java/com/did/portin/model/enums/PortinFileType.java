package com.did.portin.model.enums;

public enum PortinFileType {

    // Portin File Type candidates
    LETTER_OF_AUTHORIZATION(0, "Letter of Authorization"),
    COPY_OF_BILL(1, "Copy of Bill"),
    CUSTOMER_SERVICE_RECORD(2, "Customer Service Record");

    private int fileTypeId;
    private String fileTypeName;

    PortinFileType(int fileTypeId, String fileTypeName) {
        this.fileTypeId = fileTypeId;
        this.fileTypeName = fileTypeName;
    }

    public int getFileTypeId() {
        return this.fileTypeId;
    }

    public String getFileTypeName() {
        return this.fileTypeName;
    }

    public static PortinFileType getPortinFileTypeFromId(int fileId) {
        for (PortinFileType portinFileType : PortinFileType.values()) {
            if (portinFileType.getFileTypeId() == fileId) {
                return portinFileType;
            }
        }

        return null;
    }

    public static PortinFileType getPortinFileTypeFromName(String fileTypeName) {
        for (PortinFileType portinFileType : PortinFileType.values()) {
            if (portinFileType.getFileTypeName().equalsIgnoreCase(fileTypeName)) {
                return portinFileType;
            }
        }

        return null;
    }
}