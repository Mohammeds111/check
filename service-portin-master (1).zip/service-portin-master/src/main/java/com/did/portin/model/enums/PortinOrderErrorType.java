package com.did.portin.model.enums;

public enum PortinOrderErrorType {

    // Portin File Type candidates
    OPEN(0, "Open"),
    CLOSED(1, "Closed");

    private int errorTypeId;
    private String errorTypeName;

    PortinOrderErrorType(int errorTypeId, String errorTypeName) {
        this.errorTypeId = errorTypeId;
        this.errorTypeName = errorTypeName;
    }

    public int getErrorTypeId() {
        return this.errorTypeId;
    }

    public String getErrorTypeName() {
        return this.errorTypeName;
    }

    public static PortinOrderErrorType getErrorTypeFromId(int errorId) {
        for (PortinOrderErrorType errorType : PortinOrderErrorType.values()) {
            if (errorType.getErrorTypeId() == errorId) {
                return errorType;
            }
        }

        return null;
    }

    public static PortinOrderErrorType getErrorTypeFromName(String fileTypeName) {
        for (PortinOrderErrorType errorType : PortinOrderErrorType.values()) {
            if (errorType.getErrorTypeName().equalsIgnoreCase(fileTypeName)) {
                return errorType;
            }
        }

        return null;
    }
}