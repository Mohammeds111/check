package com.did.portin.model.bandwidth;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Root;

import java.util.List;

@Root(name = "OrderHistoryWrapper", strict = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OrderHistoryWrapper {
  @ElementList(entry = "OrderHistory", inline = true, required = false)
  private List<OrderHistory> orderHistory;

  @Element(name = "IrisStatus", required = false)
  private IrisStatusForOrderHistoryWrapper irisStatus;

  public IrisStatusForOrderHistoryWrapper getIrisStatus() {
    return irisStatus;
  }

  public void setIrisStatus(IrisStatusForOrderHistoryWrapper irisStatus) {
    this.irisStatus = irisStatus;
  }

  public List<OrderHistory> getOrderHistory() {
    return orderHistory;
  }

  public void setOrderHistory(List<OrderHistory> orderHistory) {
    this.orderHistory = orderHistory;
  }
}
