package com.did.portin.model.bandwidth;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Root(name = "BulkPortin", strict = false)
public class BulkPortin {

  @Element(name = "SiteId", required = false)
  private int siteId;

  @Element(name = "PeerId", required = false)
  private int peerId;

  @Element(name = "CustomerOrderId", required = false)
  private String customerOrderId;

  @Element(name = "ProcessingStatus", required = false)
  private String processingStatus;

  @Element(name = "CreatedByUser", required = false)
  private String createdByUser;

  @Element(name = "LastModifiedBy", required = false)
  private String lastModifiedBy;

  @Element(name = "LastModifiedDate", required = false)
  private String lastModifiedDate;

  @Element(name = "OrderCreateDate", required = false)
  private String orderCreateDate;

  @Element(name = "OrderId", required = false)
  private String orderId;

  @Element(name = "Status", required = false)
  private Status status;

  public String getProcessingStatus() {
    return processingStatus;
  }

  public void setProcessingStatus(String processingStatus) {
    this.processingStatus = processingStatus;
  }

  public String getOrderId() {
    return orderId;
  }

  public void setOrderId(String orderId) {
    this.orderId = orderId;
  }

  public String getOrderCreateDate() {
    return orderCreateDate;
  }

  public void setOrderCreateDate(String orderCreateDate) {
    this.orderCreateDate = orderCreateDate;
  }

  public String getLastModifiedDate() {
    return lastModifiedDate;
  }

  public void setLastModifiedDate(String lastModifiedDate) {
    this.lastModifiedDate = lastModifiedDate;
  }

  public String getCreatedByUser() {
    return createdByUser;
  }

  public void setCreatedByUser(String createdByUser) {
    this.createdByUser = createdByUser;
  }

  public String getLastModifiedBy() {
    return lastModifiedBy;
  }

  public void setLastModifiedBy(String lastModifiedBy) {
    this.lastModifiedBy = lastModifiedBy;
  }

  public String getCustomerOrderId() {
    return customerOrderId;
  }

  public void setCustomerOrderId(String customerOrderId) {
    this.customerOrderId = customerOrderId;
  }

  public int getSiteId() {
    return siteId;
  }

  public void setSiteId(int siteId) {
    this.siteId = siteId;
  }

  public int getPeerId() {
    return peerId;
  }

  public void setPeerId(int peerId) {
    this.peerId = peerId;
  }

  public Status getStatus() {
    return status;
  }

  public void setStatus(Status status) {
    this.status = status;
  }
}
