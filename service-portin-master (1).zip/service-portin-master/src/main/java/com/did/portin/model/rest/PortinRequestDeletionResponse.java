package com.did.portin.model.rest;

import com.did.portin.model.bandwidth.BulkPortinResponse;
import com.did.portin.model.rest.errors.Error;

import java.util.List;

public class PortinRequestDeletionResponse {

  private boolean requestDeletedFromDatabase;
  private List<Error> validationErrors;

  public boolean isRequestDeletedFromDatabase() {
    return requestDeletedFromDatabase;
  }

  public void setRequestDeletedFromDatabase(boolean requestDeletedFromDatabase) {
    this.requestDeletedFromDatabase = requestDeletedFromDatabase;
  }

  public List<Error> getValidationErrors() {
    return validationErrors;
  }

  public void setValidationErrors(List<Error> validationErrors) {
    this.validationErrors = validationErrors;
  }
}
