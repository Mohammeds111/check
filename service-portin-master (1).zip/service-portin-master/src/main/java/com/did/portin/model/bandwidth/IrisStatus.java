package com.did.portin.model.bandwidth;

import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

@Root(name = "irisStatus", strict = false)
public class IrisStatus {
    @Element(name = "Code", required = false)
    private String code;

    @Element(name = "Description", required = false)
    private String description;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
