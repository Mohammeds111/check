package com.did.portin.model.bandwidth;

import org.simpleframework.xml.Root;

@Root(name = "TnList", strict = false)
public class TnListAlt extends TnsAlt {}
