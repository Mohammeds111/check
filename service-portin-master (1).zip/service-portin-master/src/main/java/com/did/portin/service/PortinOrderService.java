package com.did.portin.service;

import com.did.portin.model.bandwidth.BulkPortinResponse;
import com.did.portin.model.bandwidth.Errors;
import com.did.portin.model.bandwidth.LnpOrderResponse;
import com.did.portin.model.bandwidth.LnpOrderSupp;
import com.did.portin.model.bandwidth.ServiceAddress;
import com.did.portin.model.bandwidth.Status;
import com.did.portin.model.bandwidth.Subscriber;
import com.did.portin.model.db.PortinOrder;
import com.did.portin.model.db.PortinOrderError;
import com.did.portin.model.db.PortinRequest;
import com.did.portin.model.db.State;
import com.did.portin.model.enums.AddressType;
import com.did.portin.model.enums.PhoneNumberType;
import com.did.portin.model.enums.PortinOrderErrorType;
import com.did.portin.model.enums.PortinOrderStatus;
import com.did.portin.model.enums.PortinRequestStatus;
import com.did.portin.model.enums.UserAccountType;
import com.did.portin.model.pagination.PagedResult;
import com.did.portin.model.rest.PortinOrderDeleteResponse;
import com.did.portin.model.rest.PortinOrderDetailsResponse;
import com.did.portin.model.rest.PortinOrderFilter;
import com.did.portin.model.rest.PortinOrderResponse;
import com.did.portin.model.rest.PortinOrderStatistics;
import com.did.portin.model.rest.PortinOrderSubmitResponse;
import com.did.portin.model.rest.PortinOrderUpdateResponse;
import com.did.portin.model.rest.SearchPortinOrderRequest;
import com.did.portin.model.rest.errors.Error;
import com.did.portin.model.rest.errors.PhoneNumberValidationError;
import com.did.portin.model.sort.PortinOrderSortAttribute;
import com.did.portin.model.sort.SortDirection;
import com.did.portin.model.sort.Sorting;
import com.did.portin.mybatis.PortinOrderErrorMapper;
import com.did.portin.mybatis.PortinOrderMapper;
import com.did.portin.mybatis.PortinRequestMapper;
import com.did.portin.mybatis.StateMapper;
import com.did.portin.util.ConversionUtil;
import com.did.portin.util.PhoneNumberUtility;
import com.did.portin.util.PortinConstants;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import javax.inject.Named;
import javax.validation.ValidationException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class PortinOrderService {

  public static final int BANDWIDTH_LIMIT_LAU_NAME = 15;
  public static final String ALPHA_NUMERIC_ONLY_REGEX = "^[a-zA-Z0-9\\s]+$";
  public static Pattern PATTERN_ALPHA_NUMERIC = Pattern.compile(ALPHA_NUMERIC_ONLY_REGEX);
  private static final Logger logger = LoggerFactory.getLogger(PortinOrderService.class);

  @Autowired PortinOrderMapper portinOrderMapper;
  @Autowired PortinRequestMapper portinRequestMapper;
  @Autowired StateMapper stateMapper;
  @Autowired
  PortinOrderErrorMapper portinOrderErrorMapper;

  @Inject
  private PortinFileSystemService portinFileSystemService;

  @Inject
  @Named("bandwidth.api.update.requestedActivationDateLimitInDays")
  private Long requestedActivationDateLimit;

  @Inject private BandwidthClientService bandwidthClientService;

  @Transactional
  public PortinOrder insertPortinOrder(PortinOrder portinOrder) {

    portinOrderMapper.insertPortinOrder(portinOrder);

    return portinOrder;
  }

  @Transactional
  public PortinOrderDetailsResponse getPortinOrdersByRequestId(Long portinRequestId, Long portinOrderId, boolean openOrdersOnly) {

    // To check if Portin Request Id is not negative or zero
    if (Objects.nonNull(portinRequestId)) {
      if (Optional.ofNullable(portinRequestId).orElse(0L) <= 0) {
        throw new ValidationException("Portin Request ID can not be zero or less than zero.");
      }

      if (Objects.nonNull(portinOrderId) && portinOrderId.longValue() <= 0) {
        throw new ValidationException("Portin Order ID can not be zero or less than zero.");
      }

      // To check if Portin Request Id is present in portin.portin_request table
      PortinRequest portinRequest = portinRequestMapper.getPortinRequestById(portinRequestId);

      if (portinRequest == null) {
        throw new ValidationException("Portin Request ID is not found");
      }
      // If Portin Request Id is present in portin.portin_request table,fetch its details from
      // portin.portin_order table
      if (Objects.nonNull(portinRequest)) {
        if (Objects.nonNull(portinRequest.getPortinRequestId())) {

          PortinOrderDetailsResponse portinOrderDetailsResponse = new PortinOrderDetailsResponse();
          List<PortinOrderResponse> portinOrderResponses = portinOrderMapper.getPortinOrdersByRequestId(portinRequest.getPortinRequestId(), portinOrderId, openOrdersOnly);
          portinOrderDetailsResponse.setSupportedOrders(portinOrderResponses);

          // Initialize counters for stats preparation
          List<String> carriers = new ArrayList<>();
          List<String> rateCenters = new ArrayList<>();
          List<String> wirelessNumbers = new ArrayList<>();
          List<String> wiredNumbers = new ArrayList<>();
          List<String> tollfreeNumbers = new ArrayList<>();

          // Iterate and prepare the states for available orders
          for (PortinOrderResponse portinOrderResponse : portinOrderResponses) {
            PortinOrder portinOrder = portinOrderResponse.getPortinOrder();

            String carrierName = portinOrder.getLocCarrierName();
            String phoneNumbers = portinOrder.getPhoneNumbers();
            String phoneNumberType = portinOrder.getPhoneNumberType();
            String[] phoneNumbersList = phoneNumbers.split(StringUtils.SPACE);
            if (StringUtils.isNotEmpty(carrierName)) {
              if (!PortinConstants.TOLL_FREE_CARRIER_NAME.equalsIgnoreCase(carrierName)) {
                carriers.add(carrierName);
              }
            }

            if(StringUtils.isNotEmpty(phoneNumberType)){
              if(PhoneNumberType.TOLLFREE.getPhoneNumberType().equalsIgnoreCase(phoneNumberType)) {
                tollfreeNumbers.addAll(Arrays.asList(phoneNumbersList));
              } else if(PhoneNumberType.WIRED.getPhoneNumberType().equalsIgnoreCase(phoneNumberType)) {
                wiredNumbers.addAll(Arrays.asList(phoneNumbersList));
              } else if(PhoneNumberType.WIRELESS.getPhoneNumberType().equalsIgnoreCase(phoneNumberType)) {
                wirelessNumbers.addAll(Arrays.asList(phoneNumbersList));
              }
            }

            String rateCenter = portinOrder.getRateCenter();
            if (StringUtils.isNotEmpty(rateCenter)) {
              String[] rateCenterNames = rateCenter.split(PortinConstants.COMMA);
              rateCenters.addAll(Arrays.asList(rateCenterNames));
            }
          } // End for

          // Prepare the stats
          PortinOrderStatistics portinOrderStatistics =
                  generateOrdersStatistics(
                          carriers, rateCenters, wirelessNumbers, wiredNumbers, tollfreeNumbers);
          portinOrderDetailsResponse.setStats(portinOrderStatistics);


          return portinOrderDetailsResponse;
        }
      }
    }
    return new PortinOrderDetailsResponse();
  }

  public static PortinOrderStatistics generateOrdersStatistics(
          List<String> carriers,
          List<String> rateCenters,
          List<String> wirelessNumbers,
          List<String> wiredNumbers,
          List<String> tollfreeNumbers) {

    // Initialize counters for stats preparation
    if (CollectionUtils.isEmpty(carriers)) {
      carriers = new ArrayList<>();
    }
    if (CollectionUtils.isEmpty(rateCenters)) {
      rateCenters = new ArrayList<>();
    }
    if (CollectionUtils.isEmpty(wirelessNumbers)) {
      wirelessNumbers = new ArrayList<>();
    }
    if (CollectionUtils.isEmpty(wiredNumbers)) {
      wiredNumbers = new ArrayList<>();
    }
    if (CollectionUtils.isEmpty(tollfreeNumbers)) {
      tollfreeNumbers = new ArrayList<>();
    }

    PortinOrderStatistics portinOrderStatistics = new PortinOrderStatistics();
    portinOrderStatistics.setCarriers(carriers.size());
    portinOrderStatistics.setRateCenter(rateCenters.size());
    portinOrderStatistics.setTollfree(tollfreeNumbers.size());
    portinOrderStatistics.setWired(wiredNumbers.size());
    portinOrderStatistics.setWireless(wirelessNumbers.size());
    portinOrderStatistics.setTotal(
            tollfreeNumbers.size() + wiredNumbers.size() + wirelessNumbers.size());

    return portinOrderStatistics;
  }

  @Transactional
  public PortinOrderUpdateResponse updatePortinOrders(Long portinOrderId, PortinOrder portinOrderFromReq) {

    if (Optional.ofNullable(portinOrderId).orElse(0L) <= 0) {
      throw new ValidationException("Portin Order ID can not be zero or less than zero.");
    }

    if (Objects.isNull(portinOrderFromReq)) {
      throw new ValidationException("Portin Order must not be null.");
    }
    // Check if portinorderId exists in database
    PortinOrder portinOrder = portinOrderMapper.getPortinOrderById(portinOrderId);
    if (Objects.isNull(portinOrder)) {
      throw new ValidationException("Portin Order Id not found.");
    }

    portinOrderFromReq.setPortinOrderId(portinOrderId);

    PortinOrder portinOrderDetailsFromDB = portinOrderMapper.getPortinOrderById(portinOrderId);
    if (portinOrderDetailsFromDB.getPortinOrderId() == 0) {
      throw new ValidationException("Portin Order Id not found.");
    }
    if (StringUtils.isEmpty(portinOrderDetailsFromDB.getLocCarrierName())) {
      throw new ValidationException(
          "Loosing Carrier Name is not available for the Portin Order Id.");
    }

    // Validate the update portin order
    PortinOrderUpdateResponse portinOrderUpdateResponse =
        validateUpdatePortinOrder(portinOrderFromReq, portinOrderDetailsFromDB);

    if (CollectionUtils.isEmpty(portinOrderUpdateResponse.getInvalidNumbers())
        && CollectionUtils.isEmpty(portinOrderUpdateResponse.getValidationErrors())) {
      portinOrderMapper.updatePortinOrderId(portinOrderFromReq);
      portinOrderUpdateResponse.setOrderUpdatedToDatabase(true);
      PortinOrder latestPortinOrder = portinOrderMapper.getPortinOrderDetailsById(portinOrderId);
      portinOrderUpdateResponse.setLatestPortinOrder(latestPortinOrder);
    }

    return portinOrderUpdateResponse;
  }

  public PortinOrderUpdateResponse validateUpdatePortinOrder(
      PortinOrder portinOrderFromReq, PortinOrder portinOrdeFromDB) {
    PortinOrderUpdateResponse portinOrderUpdateResponse = new PortinOrderUpdateResponse();
    List<Error> validationErrors = new ArrayList<>();

    // Validate BTN section related fields
    String billingTelephoneNumber = portinOrderFromReq.getBillingTelephoneNumber();
    if (Objects.nonNull(billingTelephoneNumber) && StringUtils.isEmpty(billingTelephoneNumber)) {
      Error error = Error.generateErrorMessage("portin-order.update.btn.billingTelephoneNumber.empty",
              "Billing Telephone Number must not be empty");
      validationErrors.add(error);
    }

    String replacementBillingTelephoneNumber = portinOrderFromReq.getReplacementBillingTelephoneNumber();
    if (Objects.nonNull(replacementBillingTelephoneNumber) && StringUtils.isEmpty(replacementBillingTelephoneNumber)) {
      Error error = Error.generateErrorMessage("portin-order.update.btn.replacementBillingTelephoneNumber.empty",
              "Replacement Billing Telephone Number must not be empty");
      validationErrors.add(error);
    }

    List<String> phoneNumbersToValidate = new ArrayList<String>();
    if (StringUtils.isNotEmpty(billingTelephoneNumber)) {
      phoneNumbersToValidate.add(billingTelephoneNumber);
    }
    if (StringUtils.isNotEmpty(replacementBillingTelephoneNumber)) {
      phoneNumbersToValidate.add(replacementBillingTelephoneNumber);
    }

    // Validate the update portin order
    List<PhoneNumberValidationError> invalidPhoneNumbers =
        PhoneNumberUtility.validatePhonenumbers(
            phoneNumbersToValidate, portinOrdeFromDB, bandwidthClientService);

    if (CollectionUtils.isNotEmpty(invalidPhoneNumbers)) {
      portinOrderUpdateResponse.setInvalidNumbers(invalidPhoneNumbers);
    }

    // Validate endUserInfo section related fields
    String userAccountType = portinOrderFromReq.getUserAccountType();
    String userCompanyname = portinOrderFromReq.getUserCompanyname();
    if (Objects.nonNull(userAccountType) && StringUtils.isEmpty(userAccountType)) {
      Error error = Error.generateErrorMessage("portin-order.update.endUserInfo.userAccountType.empty",
              "User Account Type must not be empty");
      validationErrors.add(error);
    }

    if (StringUtils.isNotEmpty(userAccountType)) {
      UserAccountType userAccountTypeFromName = UserAccountType.getUserAccountTypeFromName(userAccountType);
      if(Objects.isNull(userAccountTypeFromName)){
        Error error = Error.generateErrorMessage("portin-order.update.endUserInfo.userAccountType.invalid",
                "User Account Type must be either BUSINESS or RESIDENTIAL only");
        validationErrors.add(error);
      }

      // If user account type is BUSINESS then consider company name as first name
      if(userAccountTypeFromName == UserAccountType.BUSINESS){
        if(StringUtils.isNotEmpty(userCompanyname)) {
          portinOrderFromReq.setUserFirstname(userCompanyname);
        }
      }
    }

    if (Objects.nonNull(userCompanyname) && StringUtils.isEmpty(userCompanyname)) {
      Error error = Error.generateErrorMessage("portin-order.update.endUserInfo.userCompanyname.empty",
              "User Company Name must not be empty");
      validationErrors.add(error);
    }

    String loaAuthorizingPerson = portinOrderFromReq.getLoaAuthorizingPerson();
    if (Objects.nonNull(loaAuthorizingPerson) && StringUtils.isEmpty(loaAuthorizingPerson)) {
      Error error = Error.generateErrorMessage("portin-order.update.endUserInfo.loaAuthorizingPerson.empty",
              "loa Authorizing Person must not be empty");
      validationErrors.add(error);
    }

    if (StringUtils.isNotEmpty(loaAuthorizingPerson)){
      if (loaAuthorizingPerson.length() > BANDWIDTH_LIMIT_LAU_NAME) {
        Error error = Error.generateErrorMessage("portin-status.update.endUserInfo.loaAuthorizingPerson.invalidLength",
                "loa Authorizing Person value length must be less than or equal to 15 character only");
        validationErrors.add(error);
      }
    }

    String authorizedUsername = portinOrderFromReq.getAuthorizedUsername();
    if (Objects.nonNull(authorizedUsername) && StringUtils.isEmpty(authorizedUsername)) {
      Error error = Error.generateErrorMessage("portin-order.update.endUserInfo.authorizedUsername.empty",
              "Authorized Username must not be empty");
      validationErrors.add(error);
    }

    String lcAccountnumber = portinOrderFromReq.getLcAccountnumber();
    if (Objects.nonNull(lcAccountnumber) && StringUtils.isEmpty(lcAccountnumber)) {
      Error error = Error.generateErrorMessage("portin-order.update.endUserInfo.lcAccountnumber.empty",
              "Account number must not be empty");
      validationErrors.add(error);
    }

    String lcPinnumber = portinOrderFromReq.getLcPinnumber();
    if (Objects.nonNull(lcPinnumber) && StringUtils.isEmpty(lcPinnumber)) {
      Error error = Error.generateErrorMessage("portin-order.update.endUserInfo.lcPinnumber.empty",
              "Pin number must not be empty");
      validationErrors.add(error);
    }

    // Validate serviceAddress section related fields
    String userFirstname = portinOrderFromReq.getUserFirstname();
    if (Objects.nonNull(userFirstname) && StringUtils.isEmpty(userFirstname)) {
      Error error = Error.generateErrorMessage("portin-order.update.serviceAddress.userFirstname.empty",
              "User Firstname must not be empty");
      validationErrors.add(error);
    }

    String userLastname = portinOrderFromReq.getUserLastname();
    if (Objects.nonNull(userLastname) && StringUtils.isEmpty(userLastname)) {
      Error error = Error.generateErrorMessage("portin-order.update.serviceAddress.userLastname.empty",
              "User Firstname must not be empty");
      validationErrors.add(error);
    }

    String addressStreetnumber = portinOrderFromReq.getAddressStreetnumber();
    if (Objects.nonNull(addressStreetnumber) && StringUtils.isEmpty(addressStreetnumber)) {
      Error error = Error.generateErrorMessage("portin-order.update.serviceAddress.addressStreetnumber.empty",
              "Address Streetnumber must not be empty");
      validationErrors.add(error);
    }

    String addressHousenumber = portinOrderFromReq.getAddressHousenumber();
    if (Objects.nonNull(addressHousenumber) && StringUtils.isEmpty(addressHousenumber)) {
      Error error =
          Error.generateErrorMessage(
              "portin-order.update.serviceAddress.addressHousenumber.empty",
              "Address Housenumber must not be empty");
      validationErrors.add(error);
    }

    String addressStreetname = portinOrderFromReq.getAddressStreetname();
    if (Objects.nonNull(addressStreetname) && StringUtils.isEmpty(addressStreetname)) {
      Error error = Error.generateErrorMessage("portin-order.update.serviceAddress.addressStreetname.empty",
              "Address Streetname must not be empty");
      validationErrors.add(error);
    }

    String addressAddressline2 = portinOrderFromReq.getAddressAddressline2();
    if (Objects.nonNull(addressAddressline2) && StringUtils.isEmpty(addressAddressline2)) {
      Error error = Error.generateErrorMessage("portin-order.update.serviceAddress.addressAddressline2.empty",
              "Address line2 must not be empty");
      validationErrors.add(error);
    }

    // Validated addressCity to avoid special characters
    String addressCity = portinOrderFromReq.getAddressCity();
    if (Objects.nonNull(addressCity)) {
      Matcher matcher = PATTERN_ALPHA_NUMERIC.matcher(addressCity);
      if (StringUtils.isEmpty(addressCity)) {
        Error error =
            Error.generateErrorMessage(
                "portin-order.update.serviceAddress.addressCity.empty",
                "Address City must not be empty");
        validationErrors.add(error);
      } else if (!matcher.matches()) {
        Error error =
            Error.generateErrorMessage(
                "portin-order.update.serviceAddress.addressCity.specialcharacter",
                "Address City must not contain any special character.");
        validationErrors.add(error);
      }
    }

    String addressState = portinOrderFromReq.getAddressState();
    if (Objects.nonNull(addressState) && StringUtils.isEmpty(addressState)) {
      Error error = Error.generateErrorMessage("portin-order.update.serviceAddress.addressState.empty",
              "Address State must not be empty");
      validationErrors.add(error);
    }

    if (StringUtils.isNotEmpty(addressState)){
      if (addressState.length() == 2) {
        State tmpAddressState = stateMapper.getAddressState(addressState);
        if (Objects.isNull(tmpAddressState)) {
          Error error =
              Error.generateErrorMessage(
                  "portin-status.update.serviceAddress.addressState.invalid",
                  "Address State is invalid");
          validationErrors.add(error);
        }
      } else {
          Error error = Error.generateErrorMessage("portin-status.update.serviceAddress.addressState.invalidLength",
                  "Address State value length must be 2 character only");
          validationErrors.add(error);
      }
    }


    String addressCountry = portinOrderFromReq.getAddressCountry();
    if (Objects.nonNull(addressCountry) && StringUtils.isEmpty(addressCountry)) {
      Error error = Error.generateErrorMessage("portin-order.update.serviceAddress.addressCountry.empty",
              "Address Country must not be empty");
      validationErrors.add(error);
    }

    String addressZip = portinOrderFromReq.getAddressZip();
    if (Objects.nonNull(addressZip) && StringUtils.isEmpty(addressZip)) {
      Error error = Error.generateErrorMessage("portin-order.update.serviceAddress.addressZip.empty",
              "Address Zip must not be empty");
      validationErrors.add(error);
    }

    String notes = portinOrderFromReq.getNotes();
    if (Objects.nonNull(notes) && StringUtils.isEmpty(notes)) {
      Error error = Error.generateErrorMessage("portin-order.update.note.notes.empty",
              "Notes must not be empty");
      validationErrors.add(error);
    }

    //validate requestedActivation date
    Timestamp requestedActivationDate = portinOrderFromReq.getRequestedActivationDate();
    Timestamp suggestedActivationDate = portinOrdeFromDB.getSuggestedActivationDate();
    if (Objects.nonNull(requestedActivationDate) && Objects.nonNull(suggestedActivationDate)) {
      Date reqActivationDate = requestedActivationDate;
      Date sugActivationDate = suggestedActivationDate;
      LocalDate reqActivationLocalDate = reqActivationDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
      LocalDate sugActivationLocalDate = sugActivationDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
      long days = ChronoUnit.DAYS.between(sugActivationLocalDate, reqActivationLocalDate);
      if (days > requestedActivationDateLimit) {
        Error error = Error.generateErrorMessage("portin-order.update.requestedActivationDate.limit.exceeded",
                "requestedActivationDate cannot be more than "+ requestedActivationDateLimit +" days from suggestedActivationDate.");
        validationErrors.add(error);
      }
      if(reqActivationLocalDate.isBefore(sugActivationLocalDate)){
        Error error = Error.generateErrorMessage("portin-order.update.requestedActivationDate",
                "requestedActivationDate cannot be less than suggestedActivationDate.");
        validationErrors.add(error);
      }
    }

    portinOrderUpdateResponse.setValidationErrors(validationErrors);
    return portinOrderUpdateResponse;
  }

  @Transactional
  public PagedResult<PortinOrder> searchPortinOrders(
          SearchPortinOrderRequest paginatedSearchRequest) {
    PortinOrderFilter filter = paginatedSearchRequest.getFilter();

    String qText = filter.getQ();
    if (!StringUtils.isEmpty(qText)) {
      String wildCardSearchText = "%" + qText + "%";
      filter.setQ(wildCardSearchText);
    }

    Sorting<PortinOrderSortAttribute> sorting =
        new Sorting<PortinOrderSortAttribute>()
            .withDirection(filter.getSortDirection())
            .withAttribute(filter.getSortBy());
    boolean sortOrder = (sorting.getDirection() == SortDirection.asc);

    int total = portinOrderMapper.count(filter);

    List<PortinOrder> results;
    if (total > 0) {
      results =
          portinOrderMapper.searchPortinOrders(
              filter,
              sorting.getAttribute().getColumnName(),
              sortOrder,
              paginatedSearchRequest.getPagination().getLimit(),
              paginatedSearchRequest.getPagination().getOffset());
    } else {
      results = new ArrayList<>(0);
    }
    return new PagedResult<PortinOrder>().withEntities(results).withRowCount(total);
  }


  @Transactional
  public PortinOrderSubmitResponse submitPortinOrders(Long portinOrderId) {
    PortinOrderSubmitResponse portinOrderSubmitResponse = new PortinOrderSubmitResponse();
    boolean orderSubmitted = false;
    // Check if portinOrderId is not less than equal to 0
    if (Optional.ofNullable(portinOrderId).orElse(0L) <= 0) {
      throw new ValidationException("Portin Order ID can not be zero or less than zero.");
    }

    PortinOrder portinOrderToSubmit = portinOrderMapper.getPortinOrderDetailsById(portinOrderId);

    if (Objects.isNull(portinOrderToSubmit)) {
      throw new ValidationException("Portin Order Id is not found.");
    }

    // Upload latest documents to BW order
    portinFileSystemService.uploadFilesToBandwidth(portinOrderToSubmit);

    // Set latest portin-order details to BW order
    LnpOrderSupp lnpOrderSupp = new LnpOrderSupp();
    lnpOrderSupp.setBillingTelephoneNumber(portinOrderToSubmit.getBillingTelephoneNumber());
    lnpOrderSupp.setNewBillingTelephoneNumber(
        portinOrderToSubmit.getReplacementBillingTelephoneNumber());
    lnpOrderSupp.setLoaAuthorizingPerson(portinOrderToSubmit.getLoaAuthorizingPerson());
    String requestedFocDate =
        ConversionUtil.convertToString(portinOrderToSubmit.getRequestedActivationDate());
    if (StringUtils.isNotEmpty(requestedFocDate)) {
      lnpOrderSupp.setRequestedFocDate(requestedFocDate);
    }

    // Prepare the Subscriber
    Subscriber subscriber = new Subscriber();
    subscriber.setSubscriberType(portinOrderToSubmit.getUserAccountType());
    subscriber.setFirstName(portinOrderToSubmit.getUserFirstname());
    subscriber.setLastName(portinOrderToSubmit.getUserLastname());

    // Prepare service address of subscriber
    ServiceAddress serviceAddress = new ServiceAddress();
    serviceAddress.setAddressType(AddressType.SERVICE.getAddressType());
    serviceAddress.setStreetName(portinOrderToSubmit.getAddressStreetname());
    serviceAddress.setHouseNumber(portinOrderToSubmit.getAddressStreetnumber());
    serviceAddress.setAddressLine2(portinOrderToSubmit.getAddressAddressline2());
    serviceAddress.setCity(portinOrderToSubmit.getAddressCity());
    serviceAddress.setStateCode(portinOrderToSubmit.getAddressState());
    serviceAddress.setCountry(portinOrderToSubmit.getAddressCountry());
    serviceAddress.setZip(portinOrderToSubmit.getAddressZip());
    subscriber.setServiceAddress(serviceAddress);
    lnpOrderSupp.setSubscriber(subscriber);

    // Update Order to ProcessingStatus = SUBMITTED
    lnpOrderSupp.setProcessingStatus(PortinOrderStatus.SUBMITTED.getStatusName());

    LnpOrderResponse lnpOrderResponse = null;
    // Supp/update the portin order
    try {
      lnpOrderResponse =
          bandwidthClientService.suppPortinOrder(
              portinOrderToSubmit.getPortinExternalSystemOrderId(), lnpOrderSupp);

      orderSubmitted = true;
      // Process the Errors for the order, if any
      portinOrderToSubmit = processErrorStatusForOrder(lnpOrderResponse, portinOrderToSubmit);
    } catch (Exception e) {
      logger.error("Exception in PortinOrderService.submitPortinOrders",e);
    }
    // Prepare the response
    portinOrderSubmitResponse.setLatestPortinOrder(portinOrderToSubmit);
    portinOrderSubmitResponse.setOrderSubmitted(orderSubmitted);
    List<PortinOrderError> openErrors = portinOrderErrorMapper.getOpenPortinOrderErrors(portinOrderToSubmit.getPortinOrderId());
    portinOrderSubmitResponse.setOrderErrors(openErrors);
    return portinOrderSubmitResponse;
  }

  public PortinOrder processErrorStatusForOrder(LnpOrderResponse lnpOrderResponse, PortinOrder portinOrderDetails){
    if (Objects.nonNull(lnpOrderResponse)) {
      String portinOrderStatus = lnpOrderResponse.getProcessingStatus();
      Status updateStatus = lnpOrderResponse.getStatus();

      PortinOrder portinOrderToUpdate = new PortinOrder();
      if (Objects.nonNull(updateStatus)) {
        portinOrderToUpdate.setExternalApiUpdateStatusCode(String.valueOf(updateStatus.getCode()));
        portinOrderToUpdate.setExternalApiUpdateStatusDescription(
            String.valueOf(updateStatus.getDescription()));
        // set same details return order
        portinOrderDetails.setExternalApiUpdateStatusCode(String.valueOf(updateStatus.getCode()));
        portinOrderDetails.setExternalApiUpdateStatusDescription(
            String.valueOf(updateStatus.getDescription()));
      }

      List<Errors> updateErrors = lnpOrderResponse.getErrors();
      List<String> openErrorCodesForOrder =
              portinOrderErrorMapper.getOpenPortinOrderErrorCodes(
                      portinOrderDetails.getPortinOrderId());
      if (CollectionUtils.isEmpty(openErrorCodesForOrder)) {
        openErrorCodesForOrder = new ArrayList<>();
      }

      if (CollectionUtils.isNotEmpty(updateErrors)) {
        List<PortinOrderError> portinOrderErrorsToInsert =
                getLatestErrorsToInsert(portinOrderDetails, updateErrors, openErrorCodesForOrder);
        // Insert the new errors with Open status
        if (CollectionUtils.isNotEmpty(portinOrderErrorsToInsert)) {
          portinOrderErrorMapper.insertPortinOrderErrors(portinOrderErrorsToInsert);
        }
      }

      Map.Entry<PortinOrderError, List<String>> portinOrderErrorEntryToUpdate =
              getResolvedErrorsToUpdate(portinOrderDetails, updateErrors, openErrorCodesForOrder);
      PortinOrderError portinOrderErrorForStatus = portinOrderErrorEntryToUpdate.getKey();
      List<String> errorCodesToClose = portinOrderErrorEntryToUpdate.getValue();
      // Mark the resolved errors as Closed status
      if (CollectionUtils.isNotEmpty(errorCodesToClose)) {
        portinOrderErrorMapper.updatePortinOrderErrors(
                portinOrderErrorForStatus, errorCodesToClose);
      }

      if (Objects.nonNull(updateStatus)) {
        int updateResponseCode = updateStatus.getCode();
        long newOrderStatus = 0;
        if (updateResponseCode == HttpStatus.OK.value()) {
          newOrderStatus = PortinOrderStatus.SUBMITTED.getStatusId();
        } else if (updateResponseCode == HttpStatus.BAD_REQUEST.value()) {
          newOrderStatus = PortinOrderStatus.EXCEPTION.getStatusId();
        } else {
          newOrderStatus = PortinOrderStatus.getStatusTypeFromName(portinOrderStatus).getStatusId();
        }

        portinOrderToUpdate.setOrderStatus(newOrderStatus);
        portinOrderDetails.setOrderStatus(newOrderStatus);

        portinOrderToUpdate.setPortinOrderId(portinOrderDetails.getPortinOrderId());
        // set same details return order
        portinOrderDetails.setPortinOrderId(portinOrderDetails.getPortinOrderId());

        portinOrderMapper.updatePortinOrderId(portinOrderToUpdate);

        // If SUPP is Success then Verify all orders related to portinRequestId are submitted
        if (updateResponseCode == HttpStatus.OK.value()) {
          List<PortinOrder> nonSubmitPortinOrder =
              portinOrderMapper.getNonSubmitPortinOrders(portinOrderDetails.getPortinRequestId());
          // If no orders in DRAFT/PENDING_DOCUMENTS then update portin-request to SUBMITTED
          if (CollectionUtils.isEmpty(nonSubmitPortinOrder)) {
            PortinRequest portinRequest = new PortinRequest();
            portinRequest.setPortinRequestId(portinOrderDetails.getPortinRequestId());
            portinRequest.setRequestStatus(PortinRequestStatus.SUBMITTED.getStatusId());
            // TODO: Clean up this hard coded user info with user authentication based info
            portinRequest.setModifiedUserId(123456789L);
            portinRequest.setModifiedUserCode("virtusauser01");
            portinRequest.setModifiedUserEmail("virtusauser01@virtusa.com");
            portinRequest.setModifiedUserFullName("Virtusa User");

            portinRequestMapper.updatePortinRequest(portinRequest);
          }
        }
      }
    }

    return portinOrderDetails;
  }

  private List<PortinOrderError> getLatestErrorsToInsert(
      PortinOrder portinOrderToSubmit,
      List<Errors> updateErrors,
      List<String> openErrorCodesForOrder) {
    List<PortinOrderError> errorsToInsert = new ArrayList<>();

    if (CollectionUtils.isNotEmpty(updateErrors)) {
      for (Errors updateError : updateErrors) {
        String errorCode = String.valueOf(updateError.getCode());
        if (!openErrorCodesForOrder.contains(errorCode)) {
          PortinOrderError portinOrderError = new PortinOrderError();
          portinOrderError.setPortinRequestId(portinOrderToSubmit.getPortinRequestId());
          portinOrderError.setPortinOrderId(portinOrderToSubmit.getPortinOrderId());
          portinOrderError.setErrorCode(errorCode);
          portinOrderError.setErrorDescription(updateError.getDescription());
          portinOrderError.setErrorStatus(PortinOrderErrorType.OPEN.getErrorTypeId());
          errorsToInsert.add(portinOrderError);
        }
      }
    }

    return errorsToInsert;
  }

  private Map.Entry<PortinOrderError, List<String>> getResolvedErrorsToUpdate(
      PortinOrder portinOrderToSubmit,
      List<Errors> apiErrors,
      List<String> openErrorCodesForOrder) {

    List<String> errorCodesToResolve = new ArrayList<>();
    PortinOrderError portinOrderError = new PortinOrderError();
    portinOrderError.setPortinRequestId(portinOrderToSubmit.getPortinRequestId());
    portinOrderError.setPortinOrderId(portinOrderToSubmit.getPortinOrderId());
    portinOrderError.setErrorStatus(PortinOrderErrorType.CLOSED.getErrorTypeId());
    // TODO: replace with session user information
    portinOrderError.setResolvedUserCode("virtusauser01");
    portinOrderError.setResolvedUserEmail("virtusauser01@gmail.com");
    portinOrderError.setResolvedUserFullName("Virtusa User");
    portinOrderError.setResolvedUserId(12345678l);

    List<String> tmpApiErrorCodes = new ArrayList<>();
    if (CollectionUtils.isNotEmpty(apiErrors)) {
      for (Errors updateError : apiErrors) {
        String errorCode = String.valueOf(updateError.getCode());
        tmpApiErrorCodes.add(errorCode);
      }
    }

    if (CollectionUtils.isNotEmpty(tmpApiErrorCodes)) {
      for (String openErrorCode : openErrorCodesForOrder) {
        if (!tmpApiErrorCodes.contains(openErrorCode)) {
          errorCodesToResolve.add(openErrorCode);
        }
      }
    } else {
      errorCodesToResolve.addAll(openErrorCodesForOrder);
    }

    Map.Entry<PortinOrderError, List<String>> orderErrorStatusAndCodeList =
        new AbstractMap.SimpleEntry<>(portinOrderError, errorCodesToResolve);
    return orderErrorStatusAndCodeList;
  }

  @Transactional
  public PortinOrderDeleteResponse deletePortinOrders(Long portinRequestId, Long portinOrderId) {
    LnpOrderResponse lnpOrderResponse = null;
    BulkPortinResponse bulkPortinResponse = null;
    // Check if portinRequestId is not less than equal to 0
    if (Optional.ofNullable(portinRequestId).orElse(0L) <= 0) {
      throw new ValidationException("Portin Request ID can not be zero or less than zero.");
    }
    // Check if portinOrderId is not less than equal to 0
    if (Optional.ofNullable(portinOrderId).orElse(0L) <= 0) {
      throw new ValidationException("Portin Order ID can not be zero or less than zero.");
    }
    // Check if portinorderId exists in database
    PortinOrder portinOrderDetailsToDelete =
        portinOrderMapper.getPortinOrderDetailsById(portinOrderId);
    if (Objects.isNull(portinOrderDetailsToDelete)) {
      throw new ValidationException("Portin Order Id not found.");
    }
    // Check if portinRequestId exists in database
    PortinRequest portinRequestDetailsToDelete =
        portinRequestMapper.getPortinRequestDetail(portinRequestId);
    if (Objects.isNull(portinRequestDetailsToDelete)) {
      throw new ValidationException("Portin Request Id not found.");
    }
    // Validate the delete portin order, if order status is DRAFT
    PortinOrderDeleteResponse portinOrderDeleteResponse =
        validateDeletePortinOrder(portinOrderDetailsToDelete);
    // If there is no validation errors, invoking bandwidth service based on the count
    if (CollectionUtils.isEmpty(portinOrderDeleteResponse.getValidationErrors())) {
      // To get the count of portOrders for a particular portinRequestId
      int numberOfPortinOrders = portinOrderMapper.getPortinOrderCount(portinRequestId);
      if (numberOfPortinOrders > 1) {
        try {
          lnpOrderResponse =
              bandwidthClientService.deletePortinOrder(
                  portinOrderDetailsToDelete.getPortinExternalSystemOrderId());
        } catch (Exception e) {
          logger.error("Exception in PortinOrderService.deletePortinOrders",e);
        }
        // If Bandwidth service is success, deleting the port order from database
        if (lnpOrderResponse.getStatus().getCode() == 200) {
          portinOrderMapper.deletePortinRequestFileByOrderId(portinRequestId);
          portinOrderMapper.deletePortinOrderErrorByOrderId(portinOrderId);
          portinOrderMapper.deletePortinOrder(portinOrderId);
          portinOrderDeleteResponse.setOrderDeletedFromDatabase(Boolean.TRUE);
        } else {
          List<Error> errorFromBandwidth = new ArrayList<>();
          String errorKey = String.valueOf(lnpOrderResponse.getStatus().getCode());
          Error error =
              Error.generateErrorMessage(errorKey, lnpOrderResponse.getStatus().getDescription());
          errorFromBandwidth.add(error);
          portinOrderDeleteResponse.setValidationErrors(errorFromBandwidth);
        }
      } else if (numberOfPortinOrders == 1) {
        try {
          bulkPortinResponse =
              bandwidthClientService.deleteBulkPortinOrder(
                  portinRequestDetailsToDelete.getBulkPortOrderNumber());
        } catch (Exception e) {
          logger.error("Exception in PortinOrderService.deletePortinOrders.deleteBulkPortinOrder",e);
        }
        // If Bandwidth service is success, deleting the port order from database
        if (((BulkPortinResponse) bulkPortinResponse).getBulkPortin().getStatus().getCode()
            == 200) {
          portinOrderMapper.deletePortinRequestFileByOrderId(portinRequestId);
          portinOrderMapper.deletePortinOrderErrorByOrderId(portinOrderId);
          portinOrderMapper.deletePortinOrder(portinOrderId);
          portinOrderDeleteResponse.setOrderDeletedFromDatabase(Boolean.TRUE);
        } else {
          List<Error> errorFromBandwidth = new ArrayList<>();
          String errorKey =
              String.valueOf(bulkPortinResponse.getBulkPortin().getStatus().getCode());
          Error error =
              Error.generateErrorMessage(
                  errorKey, bulkPortinResponse.getBulkPortin().getStatus().getDescription());
          errorFromBandwidth.add(error);
          portinOrderDeleteResponse.setValidationErrors(errorFromBandwidth);
        }
      }
    }
    return portinOrderDeleteResponse;
  }

  public PortinOrderDeleteResponse validateDeletePortinOrder(PortinOrder portinOrder) {
    PortinOrderDeleteResponse portinOrderDeleteResponse = new PortinOrderDeleteResponse();
    List<Error> validationErrors = new ArrayList<>();
    Long orderStatus = portinOrder.getOrderStatus();
    if (PortinRequestStatus.DRAFT.getStatusId() != orderStatus) {
      Error error =
          Error.generateErrorMessage(
              "portin-order.delete.portinOrderId.status.notADarft",
              "Portin Order status must be in DRAFT status to delete.");
      validationErrors.add(error);
    }
    portinOrderDeleteResponse.setValidationErrors(validationErrors);
    return portinOrderDeleteResponse;
  }
}
