package com.did.portin.util;

import com.did.portin.model.bandwidth.LosingCarrierTnList;
import com.did.portin.model.bandwidth.NumberPortabilityRequest;
import com.did.portin.model.bandwidth.NumberPortabilityResponse;
import com.did.portin.model.bandwidth.RateCenterGroup;
import com.did.portin.model.bandwidth.SupportedLosingCarriers;
import com.did.portin.model.bandwidth.SupportedRateCenters;
import com.did.portin.model.bandwidth.TnListAlt;
import com.did.portin.model.db.PortinOrder;
import com.did.portin.model.enums.FullCheckType;
import com.did.portin.model.rest.errors.Error;
import com.did.portin.model.rest.errors.PhoneNumberValidationError;
import com.did.portin.model.validation.PhoneNumberValidationData;
import com.did.portin.service.BandwidthClientService;
import com.google.i18n.phonenumbers.NumberParseException;
import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.Phonenumber;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

public class PhoneNumberUtility {
  public static final String ERROR = "error";
  public static final String PHONE_NUMBER_INVALID_LENGTH = "phonenumber.invalid.length";
  public static final String PHONE_NUMBER_INVALID_NUMBER = "phonenumber.invalid.number";
  public static final String PHONE_NUMBER_INVALID_US_NUMBER = "phonenumber.invalid.us.number";
  public static final String PHONE_NUMBER_INVALID_NAN_NUMBER = "phonenumber.invalid.nan.number";
  public static final String PHONE_NUMBER_INVALID_GEO_NUMBER = "phonenumber.invalid.geo.number";
  public static final String PHONE_NUMBER_BANDWIDTH_ERROR = "phonenumber.invalid.bandwidth.errors";
  private static final int PHONE_NUMBER_LENGTH = 10;
  private static final String INVALID_NUMBER = "Not a Valid Phone Number";
  private static final String INVALID_US_NUMBER = "Not a Valid Phone Number for US region";
  private static final String INVALID_NAN_NUMBER = "Not a Possible Number";
  private static final String INVALID_GEO_NUMBER = "Not a Valid Geographical Number";
  private static final String REGION = "US";
  public static final String INVALID_LENGTH = "Invalid length";
  public static final String PHONE_NUMBER_DUPLICATE = "phonenumber.duplicate.number";
  public static final String MSG_DUPLICATE_NUMBERS = "Duplicate numbers";

  public static final String PHONE_NUMBER_INVALID_CARRIER_MISMATCH = "phonenumber.invalid.carrier.mismatch";
  public static final String PHONE_NUMBER_INVALID_RATECENTER_MISMATCH = "phonenumber.invalid.ratecenter.mismatch";

  public static final String MSG_CARRIER_MISMATCH =
          "Phone number's Carrier Name is not matching with associated Portin Order Carrier Name";
  public static final String MSG_RATECENTER_MISMATCH =
          "Phone number Rate Center is not matching with associated Portin Order Rate Center";

  public static final String UNSUPPORTED_RATE_CENTER_GROUP = "phonenumber.invalid.unsupported.ratecenterGroup";
  public static final String MSG_UNSUPPORTED_RATE_CENTER_GROUP = "Phone number Rate Center is not supported";
  public static final String UNKNOWN="unknown";

  private PhoneNumberUtility() {}

  // Validates US Phone numbers format
  public static List<PhoneNumberValidationError> validatePhonenumbers(
      List<String> phoneNumbers,
      PortinOrder portinOrderDetails,
      BandwidthClientService bandwidthClientService) {
    List<PhoneNumberValidationError> validatedNumbers = new ArrayList<>();
    Map<String, PhoneNumberValidationData> errorMap = new HashMap<>();

    // Find Duplicates
    errorMap = findDuplicates(phoneNumbers, errorMap);
    if (MapUtils.isEmpty(errorMap)) {
      for (String phoneNumber : phoneNumbers) {
        errorMap = validatePhoneNumber(phoneNumber, errorMap, portinOrderDetails, bandwidthClientService);
      }
    }

    if(MapUtils.isNotEmpty(errorMap)){
      for ( String errorKey: errorMap.keySet()) {
        PhoneNumberValidationError phoneNumberValidationError = new PhoneNumberValidationError();

        PhoneNumberValidationData phoneNumberValidationData = errorMap.get(errorKey);
        List<String> erroredPhoneNumbers = phoneNumberValidationData.getPhoneNumbers();
        if (CollectionUtils.isNotEmpty(erroredPhoneNumbers)) {
          phoneNumberValidationError.setNumbers(erroredPhoneNumbers);
          List<Error> errors = new ArrayList<>();
          if (errorKey.startsWith(PHONE_NUMBER_BANDWIDTH_ERROR)) {
            Map<String, String> bandwidthErrorCodeAndMessageMap = phoneNumberValidationData.getBandwidthErrorCodeAndMessages();
            if (MapUtils.isNotEmpty(bandwidthErrorCodeAndMessageMap)) {
              for (Map.Entry<String, String> bwErrorEntry : bandwidthErrorCodeAndMessageMap.entrySet()) {
                Error error = new Error();
                error.setErrorType(ERROR);
                error.setErrorKey(bwErrorEntry.getKey());
                error.setErrorMessage(bwErrorEntry.getValue());
                errors.add(error);
              }
            }
          } else {
            Error error = new Error();
            error.setErrorType(ERROR);
            error.setErrorKey(errorKey);
            error.setErrorMessage(phoneNumberValidationData.getErrorMessage());
            errors.add(error);
          }

          if (CollectionUtils.isNotEmpty(errors)) {
            phoneNumberValidationError.setErrors(errors);
            validatedNumbers.add(phoneNumberValidationError);
          }
        }
      }
    }

    return validatedNumbers;
  }

  // US Phone Numbers validation utility method
  public static Map<String, PhoneNumberValidationData> validatePhoneNumber(
      String number,
      Map<String, PhoneNumberValidationData> errorMap,
      PortinOrder portinOrderDetails,
      BandwidthClientService bandwidthClientService) {

    PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
    Phonenumber.PhoneNumber phone = null;

    try {
      phone = phoneUtil.parse(number, REGION);
    } catch (NumberParseException e) {

      PhoneNumberValidationData phoneNumberValidationData = errorMap.get(e.getMessage());
      if (Objects.isNull(phoneNumberValidationData)) {
        phoneNumberValidationData = new PhoneNumberValidationData();
      }
      List<String> phoneNumbers = phoneNumberValidationData.getPhoneNumbers();
      if (Objects.isNull(phoneNumbers)) {
        phoneNumbers = new ArrayList<>();
      }
      phoneNumbers.add(number);
      phoneNumberValidationData.setPhoneNumbers(phoneNumbers);
      phoneNumberValidationData.setErrorMessage(e.getMessage());
      errorMap.put(e.getMessage(), phoneNumberValidationData);
    }
    if (number.length() < PHONE_NUMBER_LENGTH) {

      PhoneNumberValidationData phoneNumberValidationData = errorMap.get(PHONE_NUMBER_INVALID_LENGTH);
      if (Objects.isNull(phoneNumberValidationData)) {
        phoneNumberValidationData = new PhoneNumberValidationData();
      }
      List<String> phoneNumbers = phoneNumberValidationData.getPhoneNumbers();

      if (Objects.isNull(phoneNumbers)) {
        phoneNumbers = new ArrayList<>();
      }
      phoneNumbers.add(number);

      phoneNumberValidationData.setPhoneNumbers(phoneNumbers);
      phoneNumberValidationData.setErrorMessage(INVALID_LENGTH);
      errorMap.put(PHONE_NUMBER_INVALID_LENGTH, phoneNumberValidationData);

    }
    if (Objects.nonNull(phone)) {
      if (!phoneUtil.isValidNumber(phone)) {

        PhoneNumberValidationData phoneNumberValidationData = errorMap.get(PHONE_NUMBER_INVALID_NUMBER);
        if (Objects.isNull(phoneNumberValidationData)) {
          phoneNumberValidationData = new PhoneNumberValidationData();
        }
        List<String> phoneNumbers = phoneNumberValidationData.getPhoneNumbers();

        if (Objects.isNull(phoneNumbers)) {
          phoneNumbers = new ArrayList<>();
        }
        phoneNumbers.add(number);

        phoneNumberValidationData.setPhoneNumbers(phoneNumbers);
        phoneNumberValidationData.setErrorMessage(INVALID_NUMBER);
        errorMap.put(PHONE_NUMBER_INVALID_NUMBER, phoneNumberValidationData);
      }
      if (!phoneUtil.isValidNumberForRegion(phone, REGION)) {

        PhoneNumberValidationData phoneNumberValidationData = errorMap.get(PHONE_NUMBER_INVALID_US_NUMBER);
        if (Objects.isNull(phoneNumberValidationData)) {
          phoneNumberValidationData = new PhoneNumberValidationData();
        }
        List<String> phoneNumbers = phoneNumberValidationData.getPhoneNumbers();

        if (Objects.isNull(phoneNumbers)) {
          phoneNumbers = new ArrayList<>();
        }
        phoneNumbers.add(number);

        phoneNumberValidationData.setPhoneNumbers(phoneNumbers);
        phoneNumberValidationData.setErrorMessage(INVALID_US_NUMBER);
        errorMap.put(PHONE_NUMBER_INVALID_US_NUMBER, phoneNumberValidationData);
      }
      if (!phoneUtil.isPossibleNumber(phone)) {

        PhoneNumberValidationData phoneNumberValidationData = errorMap.get(PHONE_NUMBER_INVALID_NAN_NUMBER);
        if (Objects.isNull(phoneNumberValidationData)) {
          phoneNumberValidationData = new PhoneNumberValidationData();
        }
        List<String> phoneNumbers = phoneNumberValidationData.getPhoneNumbers();

        if (Objects.isNull(phoneNumbers)) {
          phoneNumbers = new ArrayList<>();
        }
        phoneNumbers.add(number);

        phoneNumberValidationData.setPhoneNumbers(phoneNumbers);
        phoneNumberValidationData.setErrorMessage(INVALID_NAN_NUMBER);
        errorMap.put(PHONE_NUMBER_INVALID_NAN_NUMBER, phoneNumberValidationData);

      }
      if (!phoneUtil.isNumberGeographical(phone)) {

        PhoneNumberValidationData phoneNumberValidationData = errorMap.get(PHONE_NUMBER_INVALID_GEO_NUMBER);
        if (Objects.isNull(phoneNumberValidationData)) {
          phoneNumberValidationData = new PhoneNumberValidationData();
        }
        List<String> phoneNumbers = phoneNumberValidationData.getPhoneNumbers();

        if (Objects.isNull(phoneNumbers)) {
          phoneNumbers = new ArrayList<>();
        }
        phoneNumbers.add(number);

        phoneNumberValidationData.setPhoneNumbers(phoneNumbers);
        phoneNumberValidationData.setErrorMessage(INVALID_GEO_NUMBER);
        errorMap.put(PHONE_NUMBER_INVALID_GEO_NUMBER, phoneNumberValidationData);

      }

      if (Objects.nonNull(portinOrderDetails)) {
        // get BW validation error code and message
        Map<String, String> bandwidthErrorCodeAndMessageMap =
            generateBandiwdthErrorCodeAndMessages(number, bandwidthClientService, portinOrderDetails);

        String mapKey = PHONE_NUMBER_BANDWIDTH_ERROR + "." + number;

        PhoneNumberValidationData phoneNumberValidationData = new PhoneNumberValidationData();
        List<String> phoneNumbers = phoneNumberValidationData.getPhoneNumbers();

        if (Objects.isNull(phoneNumbers)) {
          phoneNumbers = new ArrayList<>();
        }
        phoneNumbers.add(number);

        phoneNumberValidationData.setPhoneNumbers(phoneNumbers);
        phoneNumberValidationData.setBandwidthErrorCodeAndMessages(bandwidthErrorCodeAndMessageMap);
        errorMap.put(mapKey, phoneNumberValidationData);
      }

    }

    return errorMap;
  }

  // Find Duplicates
  public static Map<String, PhoneNumberValidationData> findDuplicates(
          List<String> phoneNumbersList, Map<String, PhoneNumberValidationData> errorMap) {

    List<String> duplicatePhoneNumberList = new ArrayList<>();
    Map<String, Integer> frequencyMap = new HashMap<>();
    Set<String> setOfPhoneNumbers = new HashSet<String>(phoneNumbersList);
    for (String numbers : setOfPhoneNumbers) {
      int countOfDuplicates = Collections.frequency(phoneNumbersList, numbers);
      frequencyMap.put(numbers, countOfDuplicates);
    }
    for (Map.Entry<String, Integer> entry : frequencyMap.entrySet()) {
      String duplicatePhoneNumbers = entry.getKey();
      int occurrenceOfDuplicates = entry.getValue();
      if (occurrenceOfDuplicates > 1) {
        for (int i = 1; i <= occurrenceOfDuplicates; i++) {
          duplicatePhoneNumberList.add(duplicatePhoneNumbers);
        }
      }
    }
    if (duplicatePhoneNumberList.size()!=0) {

      PhoneNumberValidationData phoneNumberValidationData = new PhoneNumberValidationData();
      phoneNumberValidationData.setPhoneNumbers(duplicatePhoneNumberList);
      phoneNumberValidationData.setErrorMessage(MSG_DUPLICATE_NUMBERS);
      errorMap.put(PHONE_NUMBER_DUPLICATE, phoneNumberValidationData);
    }
    return errorMap;
  }

  public static Map<String, String> generateBandiwdthErrorCodeAndMessages(
      String number,
      BandwidthClientService bandwidthClientService,
      PortinOrder portinOrderDetails) {

    Map<String, String> bandiwdthErrorCodeAndMessageMap = new HashMap<String, String>();

    NumberPortabilityResponse numberPortabilityResponse = new NumberPortabilityResponse();
    List<String> tns = new ArrayList<>();
    tns.add(number);
    try {
      NumberPortabilityRequest numberPortabilityRequest = new NumberPortabilityRequest();
      TnListAlt tnListAlt = new TnListAlt();
      tnListAlt.setTns(tns);
      numberPortabilityRequest.setTnList(tnListAlt);

      numberPortabilityResponse =
          bandwidthClientService.lnpchecker(
              FullCheckType.OFFNETPORTABILITY.getFullCheck(), numberPortabilityRequest);
    } catch (Exception e) {
      e.printStackTrace();
    }

    if (Objects.nonNull(numberPortabilityResponse)) {
      // Process the portability Errors
      // TODO: Uncomment once the "Information on losing carrier is not available" issue is fixed
      /*
      if (Objects.nonNull(numberPortabilityResponse.getPortabilityErrors())) {
        if (Objects.nonNull(numberPortabilityResponse.getPortabilityErrors().getErrors())) {
          List<com.did.portin.model.bandwidth.Error> portabilityErrors =
              numberPortabilityResponse.getPortabilityErrors().getErrors();
          for (com.did.portin.model.bandwidth.Error portabilityError : portabilityErrors) {
            bandiwdthErrorCodeAndMessageMap.put(
                String.valueOf(portabilityError.getCode()), portabilityError.getDescription());
          }
        }
      }
      */

      // Process the Unsupported Rate Centers
      if (Objects.nonNull(numberPortabilityResponse.getUnsupportedRateCenters())) {
        if (Objects.nonNull(numberPortabilityResponse.getUnsupportedRateCenters().get(0)))
          if (Objects.nonNull(
              numberPortabilityResponse.getUnsupportedRateCenters().get(0).getRateCenterGroups()))
            bandiwdthErrorCodeAndMessageMap.put(
                UNSUPPORTED_RATE_CENTER_GROUP, MSG_UNSUPPORTED_RATE_CENTER_GROUP);
      }
      // Process the Supported Rate Centers
      if (Objects.nonNull(numberPortabilityResponse.getSupportedRateCenters())) {

        List<SupportedRateCenters> supportedRateCenters =
            numberPortabilityResponse.getSupportedRateCenters();
          if(CollectionUtils.isNotEmpty(supportedRateCenters)){
        SupportedRateCenters supportedRateCenter = supportedRateCenters.get(0);

        if (Objects.nonNull(supportedRateCenter)) {
          List<RateCenterGroup> rateCenterGroups = supportedRateCenter.getRateCenterGroups();
          if (CollectionUtils.isNotEmpty(rateCenterGroups)) {

              // Get the Rate Center
              RateCenterGroup rateCenterGroup = rateCenterGroups.get(0);
              if (Objects.nonNull(rateCenterGroup)) {
                // Rate Center comparision
                String rateCenterName = rateCenterGroup.getRateCenter();
                String portinOrderRateCenter = portinOrderDetails.getRateCenter();
                if (StringUtils.isNotEmpty(portinOrderRateCenter)) {
                  if (null != rateCenterName && !rateCenterName.equalsIgnoreCase(UNKNOWN)) {
                    String[] splitedPortinOrderRateCenters = portinOrderRateCenter.split(PortinConstants.COMMA);
                    List<String> rateCenters = Arrays.asList(splitedPortinOrderRateCenters);
                    if (!rateCenters.contains(rateCenterName))
                      bandiwdthErrorCodeAndMessageMap.put(
                          PHONE_NUMBER_INVALID_RATECENTER_MISMATCH, MSG_RATECENTER_MISMATCH);
                  }
                }
              }

              // Get the Carrier Name
              List<SupportedLosingCarriers> supportedLosingCarriers =
                  numberPortabilityResponse.getSupportedLosingCarriers();
              if (CollectionUtils.isNotEmpty(supportedLosingCarriers)) {
                SupportedLosingCarriers supportedLosingCarrier = supportedLosingCarriers.get(0);
                if (Objects.nonNull(supportedLosingCarrier)) {
                  List<LosingCarrierTnList> losingCarrierTnList =
                      supportedLosingCarrier.getLosingCarrierTnList();
                  if (CollectionUtils.isNotEmpty(losingCarrierTnList)) {
                    LosingCarrierTnList losingCarrierTnList0 = losingCarrierTnList.get(0);
                    if (Objects.nonNull(losingCarrierTnList0)) {
                      // Carrier Name comparision
                      String carrierName = losingCarrierTnList0.getLosingCarrierName();
                      if (null != carrierName && !carrierName.equalsIgnoreCase(UNKNOWN)
                          && !carrierName.equalsIgnoreCase(portinOrderDetails.getLocCarrierName())) {
                        bandiwdthErrorCodeAndMessageMap.put(
                            PHONE_NUMBER_INVALID_CARRIER_MISMATCH, MSG_CARRIER_MISMATCH);
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }

    return bandiwdthErrorCodeAndMessageMap;
  }

}
