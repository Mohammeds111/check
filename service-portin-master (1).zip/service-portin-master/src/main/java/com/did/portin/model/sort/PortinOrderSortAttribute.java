package com.did.portin.model.sort;

public enum PortinOrderSortAttribute implements SortAttribute  {

    // Sort candidates for Portin_order Table
    PORTIN_REQUEST_ID("portin_request_id"),
    BILLING_TELEPHONE_NUMBER("billing_telephone_number"),
    ORDER_DATE("order_date"),
    RATE_CENTER("rate_center"),
    ORGANIZATION_NAME("organization_name"),
    ORDER_STATUS("order_status"),
    PORTIN_CUSTOMER_ORDER_ID("portin_customer_order_id"),
    LOC_CARRIER_NAME("loc_carrier_name"),
    REQUESTED_ACTIVATION_DATE("requested_activation_date"),
    REQUESTED_QUANTITY("requested_quantity"),
    MODIFIED_USER_FULLNAME("modified_user_fullname");

    private String dbColumnName;

    PortinOrderSortAttribute(String dbColumnName) {
        this.dbColumnName = dbColumnName;
    }

    @Override
    public String getColumnName() {
        return this.dbColumnName;
    }

    }
