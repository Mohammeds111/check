package com.did.portin.model.rest;

import com.did.portin.model.db.PortinOrder;
import com.did.portin.model.db.PortinOrderError;
import java.util.List;

public class PortinOrderResponse {
    public PortinOrder portinOrder;
    public List<PortinOrderError> portinOrderErrors;

    public List<PortinOrderError> getPortinOrderErrors() {
        return portinOrderErrors;
    }

    public void setPortinOrderErrors(List<PortinOrderError> portinOrderErrors) {
        this.portinOrderErrors = portinOrderErrors;
    }

    public PortinOrder getPortinOrder() {
        return portinOrder;
    }

    public void setPortinOrder(PortinOrder portinOrder) {
        this.portinOrder = portinOrder;
    }
}
