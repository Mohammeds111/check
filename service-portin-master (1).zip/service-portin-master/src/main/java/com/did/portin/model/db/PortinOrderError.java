package com.did.portin.model.db;

import java.sql.Timestamp;

public class PortinOrderError {
  private long portinOrderErrorId;
  private long portinRequestId;
  private long portinOrderId;
  private String errorCode;
  private String errorDescription;
  private long errorStatus;
  private Timestamp createdDate;
  private Timestamp resolvedDate;
  private long resolvedUserId;
  private String resolvedUserEmail;
  private String resolvedUserFullName;
  private String resolvedUserCode;

  public long getPortinOrderErrorId() {
    return portinOrderErrorId;
  }

  public void setPortinOrderErrorId(long portinOrderErrorId) {
    this.portinOrderErrorId = portinOrderErrorId;
  }

  public long getPortinRequestId() {
    return portinRequestId;
  }

  public void setPortinRequestId(long portinRequestId) {
    this.portinRequestId = portinRequestId;
  }

  public long getPortinOrderId() {
    return portinOrderId;
  }

  public void setPortinOrderId(long portinOrderId) {
    this.portinOrderId = portinOrderId;
  }

  public String getErrorCode() {
    return errorCode;
  }

  public void setErrorCode(String errorCode) {
    this.errorCode = errorCode;
  }

  public String getErrorDescription() {
    return errorDescription;
  }

  public void setErrorDescription(String errorDescription) {
    this.errorDescription = errorDescription;
  }

  public long getErrorStatus() {
    return errorStatus;
  }

  public void setErrorStatus(long errorStatus) {
    this.errorStatus = errorStatus;
  }

  public Timestamp getCreatedDate() {
    return createdDate;
  }

  public void setCreatedDate(Timestamp createdDate) {
    this.createdDate = createdDate;
  }

  public Timestamp getResolvedDate() {
    return resolvedDate;
  }

  public void setResolvedDate(Timestamp resolvedDate) {
    this.resolvedDate = resolvedDate;
  }

  public long getResolvedUserId() {
    return resolvedUserId;
  }

  public void setResolvedUserId(long resolvedUserId) {
    this.resolvedUserId = resolvedUserId;
  }

  public String getResolvedUserEmail() {
    return resolvedUserEmail;
  }

  public void setResolvedUserEmail(String resolvedUserEmail) {
    this.resolvedUserEmail = resolvedUserEmail;
  }

  public String getResolvedUserFullName() {
    return resolvedUserFullName;
  }

  public void setResolvedUserFullName(String resolvedUserFullName) {
    this.resolvedUserFullName = resolvedUserFullName;
  }

  public String getResolvedUserCode() {
    return resolvedUserCode;
  }

  public void setResolvedUserCode(String resolvedUserCode) {
    this.resolvedUserCode = resolvedUserCode;
  }
}
