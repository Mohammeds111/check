package com.did.portin.service;

import com.did.portin.model.bandwidth.FileUploadResponse;
import com.did.portin.model.db.PortinOrder;
import com.did.portin.model.db.PortinRequest;
import com.did.portin.model.db.PortinRequestFile;
import com.did.portin.model.enums.PortinFileExtensionType;
import com.did.portin.model.enums.PortinFileType;
import com.did.portin.model.file.DidFileSystem;
import com.did.portin.model.file.StreamingInputFile;
import com.did.portin.model.rest.PortinFileRespose;
import com.did.portin.mybatis.PortinFileSystemMapper;
import com.did.portin.mybatis.PortinOrderMapper;
import com.did.portin.mybatis.PortinRequestMapper;
import com.did.portin.service.aws.S3Service;
import com.did.portin.util.ConversionUtil;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import javax.inject.Named;
import javax.validation.ValidationException;
import java.io.InputStream;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
public class PortinFileSystemService {
  public static final String UNSAFE_FILENAME_CHAR_REGEX = "[^a-zA-Z0-9.]";
  public static final String REPLACEMENT_CHAR = "_";
  public static final String PORTIN_ORDER_DOCUMENTS = "portin-order-documents/";
  public static final String URI_SEPERATOR = "/";
  public static final String FILE_PATH_REGEX = "%s/%s";
  private static final Logger logger = LoggerFactory.getLogger(PortinFileSystemService.class);


  @Inject private S3Service s3Service;

  @Inject private PortinFileSystemMapper portinFileSystemMapper;

  @Inject private PortinOrderMapper portinOrderMapper;

  @Inject private BandwidthClientService bandwidthClientService;
  @Autowired
  PortinRequestMapper portinRequestMapper;

  @Inject
  @Named("bandwidth.api.file.upload.signeddatepastlimitindays")
  private Long signedDateLimit;

  @Inject
  @Named("bandwidth.api.file.upload.maxfilesizeinmb")
  private String maxFileSize;

  @Transactional
  public PortinFileRespose saveDocumentToPortinOrder(
      byte[] byteArray,
      String uploadFileName,
      long portinRequestId,
      long portinOrderId,
      String documentType,
      String signedDate) {

    if (Optional.ofNullable(portinRequestId).orElse(0L) <= 0) {
      throw new ValidationException("Did portin request ID can not be zero or less than zero.");
    } else if (Optional.ofNullable(portinOrderId).orElse(0L) <= 0) {
      throw new ValidationException("Did portin order ID can not be zero or less than zero.");
    }
    // Check if portinorderId exists in database
    PortinOrder portinOrder = portinOrderMapper.getPortinOrderById(portinOrderId);
    if (Objects.isNull(portinOrder)) {
      throw new ValidationException("Portin Order Id not found.");
    }
    // Check if portinRequestId exists in database
    PortinRequest portinRequest = portinRequestMapper.getPortinRequestById(portinRequestId);
    if (Objects.isNull(portinRequest)) {
      throw new ValidationException("Portin Request Id not found.");
    }
    // Validates File Extension
    String fileExtension = FilenameUtils.getExtension(uploadFileName);
    if (StringUtils.isNotEmpty(fileExtension)) {
      PortinFileExtensionType portinFileExtensionType =
          PortinFileExtensionType.getPortinFileExtensionTypeFromName(fileExtension);
      if (Objects.isNull(portinFileExtensionType)) {
        throw new ValidationException("Unsupported file extension.");
      }
    } else {
      throw new ValidationException("Unsupported file extension.");
    }
    // Validates file size
    long fileSize = byteArray.length;
    long sizeInMb = fileSize / (1024 * 1024);
    if (sizeInMb > Long.parseLong(maxFileSize)) {
      throw new ValidationException("File size must be less than or equals to 10 MB.");
    }
    // Validates file length
    if (StringUtils.isNotEmpty(uploadFileName)) {
      if (uploadFileName.length() > 50) {
        throw new ValidationException("File name must be less than or equals to 50 characters.");
      }
    }
    // Validates Signed Date
    if (StringUtils.isNotEmpty(signedDate)) {
      Date convertedDate = ConversionUtil.convertToTimestamp(signedDate);
      LocalDate localDate = convertedDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
      LocalDate currentDate = LocalDate.now();
      // count number of days between the given date and today
      long days = ChronoUnit.DAYS.between(localDate, currentDate);
      if (days > signedDateLimit) {
        throw new ValidationException(
            "Signed Date cannot be more than " + signedDateLimit + "days in past");
      }
      if(convertedDate.after(new Date())){
        throw new ValidationException("Signed Date cannot be future date");
      }
    }
    String safeFileName = getSafeFileName(uploadFileName);

    String baseDir = PORTIN_ORDER_DOCUMENTS + portinRequestId + URI_SEPERATOR + portinOrderId;

    String uploadFilePath = String.format(FILE_PATH_REGEX, baseDir, safeFileName);

    // create an entry to did-file-system
    DidFileSystem didFileSystem = new DidFileSystem();
    didFileSystem.setFileName(safeFileName);
    didFileSystem.setFileUri(uploadFilePath);
    this.portinFileSystemMapper.saveToFileSystem(didFileSystem);

    Long fileId = didFileSystem.getFileId();
    int portinFileTypeId = PortinFileType.getPortinFileTypeFromName(documentType).getFileTypeId();

    // Save file to S3
    s3Service.uploadFiles(byteArray, uploadFilePath);

    PortinRequestFile portinRequestFile = new PortinRequestFile();
    portinRequestFile.setFileId(fileId);
    portinRequestFile.setPortinFileTypeId(portinFileTypeId);
    portinRequestFile.setPortinOrderId(portinOrderId);
    portinRequestFile.setPortinRequestId(portinRequestId);
    if (StringUtils.isNotEmpty(signedDate)) {
      portinRequestFile.setSignedDate(ConversionUtil.convertToTimestamp(signedDate));
    }
    this.portinFileSystemMapper.saveToPortinRequestFile(portinRequestFile);

    PortinFileRespose portinFileRespose = new PortinFileRespose();

    portinFileRespose.setCreatedDate(ConversionUtil.getCurrentDateInString());
    portinFileRespose.setFileId(fileId);
    portinFileRespose.setFileName(safeFileName);
    portinFileRespose.setFileUri(uploadFilePath);
    portinFileRespose.setPortinFileType(portinFileTypeId);
    portinFileRespose.setPortinOrderId(portinOrderId);
    portinFileRespose.setPortinRequestId(portinRequestId);
    portinFileRespose.setPortinRequestFileId(portinRequestFile.getPortinRequestFileId());
    if (StringUtils.isNotEmpty(signedDate)) {
      portinFileRespose.setSignedDate(signedDate);
    }
    return portinFileRespose;
  }

  // Delete file from AWS and db tables and BW
  @Transactional
  public String deleteDocumentFromOrder(
      Long portinRequestId, Long portinOrderId, Long portinRequestFileId) {

    if (Optional.ofNullable(portinRequestId).orElse(0L) <= 0) {
      throw new ValidationException("Did portin request ID can not be zero or less than zero.");
    } else if (Optional.ofNullable(portinOrderId).orElse(0L) <= 0) {
      throw new ValidationException("Did portin order ID can not be zero or less than zero.");
    } else if (Optional.ofNullable(portinRequestFileId).orElse(0L) <= 0) {
      throw new ValidationException("Portin request file ID can not be zero or less than zero.");
    }
    // Check if portinorderId exists in database
    PortinOrder portinOrderDetails = portinOrderMapper.getPortinOrderById(portinOrderId);
    if (Objects.isNull(portinOrderDetails)) {
      throw new ValidationException("Portin Order Id not found.");
    }
    // Check if portinRequestId exists in database
    PortinRequest portinRequest = portinRequestMapper.getPortinRequestById(portinRequestId);
    if (Objects.isNull(portinRequest)) {
      throw new ValidationException("Portin Request Id not found.");
    }
    // Check if portinRequestFileId exists in database
    PortinFileRespose portinFileResposeDetails =
        portinFileSystemMapper.getPortinRequestFileId(portinRequestFileId);
    if (Objects.isNull(portinFileResposeDetails)) {
      throw new ValidationException("Portin request file ID does not exists.");
    }
    PortinFileRespose portinFileRespose =
        portinFileSystemMapper.getPortinRequestFile(portinRequestFileId);
    String returnMessage = "File deleted successfully.";
    if (portinFileRespose != null) {
      String fileURI = portinFileRespose.getFileUri();

      // Delete the physical file in AWS S3
      s3Service.deleteFile(fileURI);

      // Delete the entry in portin-request-file
      portinFileSystemMapper.deletePortinRequestFileByFileId(portinRequestFileId);

      // Delete the entry in did-file-system
      portinFileSystemMapper.deleteFileSystemByFileId(portinFileRespose.getFileId());

      PortinOrder portinOrder = portinOrderMapper.getPortinOrderDetailsById(portinOrderId);
      String externalOrderId = portinOrder.getPortinExternalSystemOrderId();
      String externalAPIFileName = portinFileRespose.getExternalApiFileName();

      // Delete file from bandwidth API
      if (StringUtils.isNotEmpty(externalAPIFileName)) {
        FileUploadResponse response = new FileUploadResponse();
        // BW call to delete file
        try {
          response =
              bandwidthClientService.deleteFilefromPortinOrder(
                  externalOrderId, externalAPIFileName);
          returnMessage = response.getResultMessage();
        } catch (Exception e) {
          logger.error("Exception in PortinFileSystemService.deleteDocumentFromOrder",e);
          returnMessage = response.getResultMessage();
        }
      }

    } else {
      returnMessage = "Unable find file information.";
    }

    return returnMessage;
  }

  private String getSafeFileName(String fileNameOriginal) {
    return fileNameOriginal.trim().replaceAll(UNSAFE_FILENAME_CHAR_REGEX, REPLACEMENT_CHAR);
  }

  public List<PortinFileRespose> getFileDetails(Long portinRequestId, Long portinOrderId) {
    // To check if Portin Request Id and order Id is not negative or zero
    if (Optional.ofNullable(portinRequestId).orElse(0L) <= 0) {
      throw new ValidationException("Portin Request ID can not be zero or less than zero.");
    } else if (Optional.ofNullable(portinOrderId).orElse(0L) <= 0) {
      throw new ValidationException("Portin order ID can not be zero or less than zero.");
    }
    // Check if portinorderId exists in database
    PortinOrder portinOrderDetails = portinOrderMapper.getPortinOrderById(portinOrderId);
    if (Objects.isNull(portinOrderDetails)) {
      throw new ValidationException("Portin Order Id not found.");
    }
    // Check if portinRequestId exists in database
    PortinRequest portinRequest = portinRequestMapper.getPortinRequestById(portinRequestId);
    if (Objects.isNull(portinRequest)) {
      throw new ValidationException("Portin Request Id not found.");
    }
    return portinFileSystemMapper.getFileDetails(portinRequestId, portinOrderId);
  }

  // file download
  public StreamingInputFile getFileToDownload(Long portinRequestId, Long portinOrderId ,Long portinRequestFileId) {
    // Check if portinorderId exists in database
    PortinOrder portinOrder = portinOrderMapper.getPortinOrderById(portinOrderId);
    if (Objects.isNull(portinOrder)) {
      throw new ValidationException("Portin Order Id not found.");
    }
    // Check if portinRequestId exists in database
    PortinRequest portinRequest = portinRequestMapper.getPortinRequestById(portinRequestId);
    if (Objects.isNull(portinRequest)) {
      throw new ValidationException("Portin Request Id not found.");
    }
    PortinFileRespose portinFileRespose =
        portinFileSystemMapper.getPortinRequestFile(portinRequestFileId);
    return getStreamingFile(portinFileRespose);
  }

  public PortinFileRespose getPortinRequestFileId(Long portinRequestFileId) {
    PortinFileRespose portinFileRespose =
        portinFileSystemMapper.getPortinRequestFileId(portinRequestFileId);
    return portinFileRespose;
  }

  private StreamingInputFile getStreamingFile(PortinFileRespose portinFileRespose) {

    InputStream inputStream = s3Service.getFileAsByteArray(portinFileRespose.getFileUri());
    return new StreamingInputFile(inputStream, portinFileRespose.getFileName());
  }

  /**
   * Uploads the files related to a portin-order
   *
   * @param portinOrder
   * @return
   */
  public boolean uploadFilesToBandwidth(PortinOrder portinOrder) {
    boolean isUploadSuccess = true;
    long portinRequestId = portinOrder.getPortinRequestId();
    long portinOrderId = portinOrder.getPortinOrderId();
    List<PortinFileRespose> portinFileResposes =
        portinFileSystemMapper.getFileDetails(portinRequestId, portinOrderId);

    for (PortinFileRespose portinFileRespose : portinFileResposes) {
      try {

        StreamingInputFile streamingInputFile = getStreamingFile(portinFileRespose);
        InputStream fileInputStream = streamingInputFile.getStreamingInput();
        byte[] fileContents = IOUtils.toByteArray(fileInputStream);

        // upload file to BW order
        FileUploadResponse fileUploadResponse =
            bandwidthClientService.uploadFilesToPortinOrder(
                portinOrder.getPortinExternalSystemOrderId(),
                portinFileRespose.getFileName(),
                fileContents,
                PortinFileType.getPortinFileTypeFromId(portinFileRespose.getPortinFileType())
                    .getFileTypeName());

        if (Objects.nonNull(fileUploadResponse)) {
          String externalSystemFileName = fileUploadResponse.getFilename();
          if (StringUtils.isNotEmpty(externalSystemFileName)) {
            portinFileRespose.setExternalApiFileName(externalSystemFileName);
            portinFileSystemMapper.updatePortinRequestFileById(portinFileRespose);
          } else {
            isUploadSuccess = false;
            break;
          }
        }
      } catch (Exception e) {
        logger.error("Exception in PortinFileSystemService.uploadFilesToBandwidth",e);
        isUploadSuccess = false;
      }
    }

    return isUploadSuccess;
  }
}
