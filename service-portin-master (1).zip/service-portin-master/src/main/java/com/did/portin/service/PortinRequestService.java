package com.did.portin.service;

import com.did.portin.model.bandwidth.BulkPortinResponse;
import com.did.portin.model.db.PortinOrder;
import com.did.portin.model.db.PortinRequest;
import com.did.portin.model.enums.PortinRequestStatus;
import com.did.portin.model.pagination.PagedResult;
import com.did.portin.model.pagination.PaginatedRequest;
import com.did.portin.model.rest.PortinRequestCreationResponse;
import com.did.portin.model.rest.PortinRequestDeletionResponse;
import com.did.portin.model.rest.PortinRequestFilter;
import com.did.portin.model.rest.errors.Error;
import com.did.portin.model.sort.PortinRequestSortAttribute;
import com.did.portin.model.sort.SortDirection;
import com.did.portin.model.sort.Sorting;
import com.did.portin.mybatis.PortinOrderMapper;
import com.did.portin.mybatis.PortinRequestMapper;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import javax.validation.ValidationException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
public class PortinRequestService {

  public static final String PORTIN_REQUEST_URI = "/portin-request/";
  private static final Logger logger = LoggerFactory.getLogger(PortinRequestService.class);

  @Autowired PortinRequestMapper portinRequestMapper;
  @Autowired PortinOrderMapper portinOrderMapper;

  @Inject private BandwidthClientService bandwidthClientService;

  @Transactional
  public PortinRequestCreationResponse insertPortinRequest() {

    PortinRequest createPortinRequest = new PortinRequest();
    // TODO: Clean up this hard coded user info with user authentication based info
    createPortinRequest.setRequestedUserId(123456789L);
    createPortinRequest.setRequestedUserCode("virtusauser01");
    createPortinRequest.setRequestedUserEmail("virtusauser01@virtusa.com");
    createPortinRequest.setRequestedUserFullName("Virtusa User");
    createPortinRequest.setRequestStatus(0L);

    portinRequestMapper.insertPortinRequest(createPortinRequest);

    PortinRequestCreationResponse portinRequestCreationResponse =
        new PortinRequestCreationResponse();

    portinRequestCreationResponse.setPortinRequestId(createPortinRequest.getPortinRequestId());
    portinRequestCreationResponse.setPortinExternalRequestId(
        createPortinRequest.getPortinExternalRequestId());
    portinRequestCreationResponse.setPortinRequestURI(
        PORTIN_REQUEST_URI + createPortinRequest.getPortinRequestId());

    return portinRequestCreationResponse;
  }

  @Transactional
  public PagedResult<PortinRequest> searchPortinRequests(
      PaginatedRequest<PortinRequestFilter, PortinRequestSortAttribute> paginatedSearchRequest) {
    PortinRequestFilter filter = paginatedSearchRequest.getFilter();

    String qText = filter.getQ();
    if (!StringUtils.isEmpty(qText)) {
      String wildCardSearchText = "%" + qText + "%";
      filter.setQ(wildCardSearchText);
    }
    Sorting<PortinRequestSortAttribute> sorting = paginatedSearchRequest.getSorting();
    boolean sortOrder = (sorting.getDirection() == SortDirection.asc);

    int total = portinRequestMapper.count(filter);

    List<PortinRequest> results;
    if (total > 0) {
      results =
          portinRequestMapper.searchPortinRequests(
              filter,
              sorting.getAttribute().getColumnName(),
              sortOrder,
              paginatedSearchRequest.getPagination().getLimit(),
              paginatedSearchRequest.getPagination().getOffset());
    } else {
      results = new ArrayList<>(0);
    }

    return new PagedResult<PortinRequest>().withEntities(results).withRowCount(total);
  }

  @Transactional
  public PortinRequestDeletionResponse deletePortinRequest(Long portinRequestId) {

    if (Optional.ofNullable(portinRequestId).orElse(0L) <= 0) {
      throw new ValidationException("Portin request id can not be zero or less than zero.");
    }

    PortinRequest portinRequestDetails =
        portinRequestMapper.getPortinRequestDetail(portinRequestId);
    if (Objects.isNull(portinRequestDetails)) {
      throw new ValidationException("Portin request id not found.");
    }
    // Validate the delete portin request
    PortinRequestDeletionResponse portinRequestDeletionResponse =
        validatePortinRequestStatus(portinRequestDetails);
    if (CollectionUtils.isEmpty(portinRequestDeletionResponse.getValidationErrors())) {
      BulkPortinResponse bulkPortinResponse = null;
      try {
        bulkPortinResponse =
            bandwidthClientService.deleteBulkPortinOrder(
                portinRequestDetails.getBulkPortOrderNumber());
      } catch (Exception e) {
        logger.error("Exception in PortinRequestService.deletePortinRequest",e);
      }
      if (bulkPortinResponse.getBulkPortin().getStatus().getCode() == 200) {
        portinOrderMapper.deleteDraftPortinOrdersByReqId(
            portinRequestId, portinRequestDetails.getRequestStatus());
        portinRequestMapper.deletePortinRequest(portinRequestId);
        portinRequestDeletionResponse.setRequestDeletedFromDatabase(Boolean.TRUE.booleanValue());
      }
    }

    return portinRequestDeletionResponse;
  }

  public PortinRequestDeletionResponse validatePortinRequestStatus(PortinRequest portinRequest) {

    PortinRequestDeletionResponse portinRequestDeletionResponse =
        new PortinRequestDeletionResponse();
    List<Error> validationErrors = new ArrayList<>();
    long requestStatus = portinRequest.getRequestStatus();

    if (PortinRequestStatus.DRAFT.getStatusId() != requestStatus) {
      Error error =
          Error.generateErrorMessage(
              "error",
              "portin-request.delete.portinRequestId.status.notADarft",
              "Portin request status must be in DRAFT status to delete.");
      validationErrors.add(error);
    }
    List<PortinOrder> portinOrderList =
        portinOrderMapper.getNonDraftPortinOrders(portinRequest.getPortinRequestId());
    if (CollectionUtils.isNotEmpty(portinOrderList)) {
      Error error =
          Error.generateErrorMessage(
              "error",
              "portin-request.delete.portinRequestId.status.notADarft",
              "This Portin Request Id has one or more Portin Orders in non-draft status. Hence we suggest to delete the individual portin orders.");
      validationErrors.add(error);
    }
    portinRequestDeletionResponse.setValidationErrors(validationErrors);
    return portinRequestDeletionResponse;
  }
}
