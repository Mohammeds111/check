package com.did.portin.model.pagination;

import com.did.portin.model.rest.BaseFilter;
import com.did.portin.model.sort.SortAttribute;
import com.did.portin.model.sort.Sorting;

public class PaginatedRequest<F extends BaseFilter, A extends SortAttribute> {
    private Pagination pagination;
    private F filter;
    private Sorting<A> sorting;

    public PaginatedRequest() {
    }

    public static <F extends BaseFilter, A extends SortAttribute> PaginatedRequest<F, A> empty() {
        return new PaginatedRequest();
    }

    public static <F extends BaseFilter, A extends SortAttribute> PaginatedRequest<F, A> paginated(Integer offset, Integer limit) {
        return (new PaginatedRequest()).withPagination((new Pagination()).withOffset(offset).withLimit(limit));
    }

    public F getFilter() {
        return this.filter;
    }

    public void setFilter(F filter) {
        this.filter = filter;
    }

    public Pagination getPagination() {
        return this.pagination;
    }

    public void setPagination(Pagination pagination) {
        this.pagination = pagination;
    }

    public Sorting<A> getSorting() {
        return this.sorting;
    }

    public void setSorting(Sorting<A> sorting) {
        this.sorting = sorting;
    }

    public PaginatedRequest<F, A> withFilter(F filter) {
        this.filter = filter;
        return this;
    }

    public PaginatedRequest<F, A> withPagination(Pagination pagination) {
        this.pagination = pagination;
        return this;
    }

    public PaginatedRequest<F, A> withSorting(Sorting<A> sorting) {
        this.sorting = sorting;
        return this;
    }
}
