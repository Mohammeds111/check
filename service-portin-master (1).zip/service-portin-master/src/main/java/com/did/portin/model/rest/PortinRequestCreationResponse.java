package com.did.portin.model.rest;

public class PortinRequestCreationResponse {

  Long portinRequestId;
  String portinExternalRequestId;
  String portinRequestURI;

  public Long getPortinRequestId() {
    return portinRequestId;
  }

  public void setPortinRequestId(Long portinRequestId) {
    this.portinRequestId = portinRequestId;
  }

  public String getPortinExternalRequestId() {
    return portinExternalRequestId;
  }

  public void setPortinExternalRequestId(String portinExternalRequestId) {
    this.portinExternalRequestId = portinExternalRequestId;
  }

  public String getPortinRequestURI() {
    return portinRequestURI;
  }

  public void setPortinRequestURI(String portinRequestURI) {
    this.portinRequestURI = portinRequestURI;
  }
}
