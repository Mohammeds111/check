package com.did.portin.jaxrs;

import com.did.portin.model.rest.PortinResponse;
import com.did.portin.service.GoogleCalendarService;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.inject.Inject;
import javax.ws.rs.Produces;

@RequestMapping("/calendar")
@RestController
public class GoogleCalendarEndpoint {
  @Inject private GoogleCalendarService googleCalendarService;

  @GetMapping("/blackout-dates")
  @Produces(MediaType.APPLICATION_JSON_VALUE)
  public PortinResponse getBlackoutDates() throws Exception {
    return PortinResponse.generateResponse("Ok", 0, googleCalendarService.getBlackoutDates());
  }
}
