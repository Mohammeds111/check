package com.did.portin.model.pagination;

public class Pagination {
    private Integer offset;
    private Integer total;
    private Integer limit;

    public Pagination() {
        this.offset = 0;
        this.total = 0;
        this.limit = 25;
    }

    public Pagination(Integer offset, Integer limit) {
        this.setOffset(offset);
        this.setLimit(limit);
    }

    public Integer getOffset() {
        return this.offset;
    }

    public void setOffset(Integer offset) {
        if (offset != null && offset >= 0) {
            this.offset = offset;
        }

    }

    public Integer getTotal() {
        return this.total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }

    public Integer getLimit() {
        return this.limit;
    }

    public void setLimit(Integer limit) {
        if (limit != null && limit > 1000) {
            this.limit = 1000;
        } else if (limit != null && limit > 0) {
            this.limit = limit;
        }

    }

    public Pagination withOffset(Integer offset) {
        this.setOffset(offset);
        return this;
    }

    public Pagination withTotal(Integer total) {
        this.total = total;
        return this;
    }

    public Pagination withLimit(Integer limit) {
        this.setLimit(limit);
        return this;
    }
}
