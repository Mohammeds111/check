package com.did.portin.model.bandwidth;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.simpleframework.xml.Root;

@Root(name = "LnpOrderSupp", strict = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LnpOrderSupp extends LnpOrderSuppAttributes {}
