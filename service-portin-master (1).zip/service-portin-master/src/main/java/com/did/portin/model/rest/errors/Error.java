package com.did.portin.model.rest.errors;

public class Error {

  public static final String TYPE_ERROR = "error";
  public static final String TYPE_WARN = "warning";

  private String errorType;
  private String errorKey;
  private String errorMessage;

  public String getErrorType() {
    return errorType;
  }

  public void setErrorType(String errorType) {
    this.errorType = errorType;
  }

  public String getErrorKey() {
    return errorKey;
  }

  public void setErrorKey(String errorKey) {
    this.errorKey = errorKey;
  }

  public String getErrorMessage() {
    return errorMessage;
  }

  public void setErrorMessage(String errorMessage) {
    this.errorMessage = errorMessage;
  }

  public static Error generateErrorMessage(String errorType,
                                           String errorKey,
                                           String errorMessage) {
    Error error = new Error();
    error.setErrorType(errorType);
    error.setErrorKey(errorKey);
    error.setErrorMessage(errorMessage);
    return error;
  }

  public static Error generateErrorMessage(String errorKey,
                                           String errorMessage) {
    return generateErrorMessage(TYPE_ERROR,
            errorKey,
            errorMessage);
  }
}
