package com.did.portin.model.bandwidth;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

@Root(name = "WirelessInfo", strict = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class WirelessInfo {

  @Element(name = "AccountNumber", required = false)
  private String accountNumber;

  @Element(name = "PinNumber", required = false)
  private int pinNumber;

  public String getAccountNumber() {
    return accountNumber;
  }

  public void setAccountNumber(String accountNumber) {
    this.accountNumber = accountNumber;
  }

  public int getPinNumber() {
    return pinNumber;
  }

  public void setPinNumber(int pinNumber) {
    this.pinNumber = pinNumber;
  }
}
