package com.did.portin.model.sort;

public interface SortAttribute {
    String getColumnName();
}
