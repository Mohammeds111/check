package com.did.portin.model.db;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Questionnaire {

  int questionId;
  String questionName;
  String questionType;
  String question;
  String defaultSelection;
  String questionDescYes;
  String questionDescNo;
  int yesWeightage;
  int noWeightage;

  public int getQuestionId() {
    return questionId;
  }

  public void setQuestionId(int questionId) {
    this.questionId = questionId;
  }

  public String getQuestionName() {
    return questionName;
  }

  public void setQuestionName(String questionName) {
    this.questionName = questionName;
  }

  public String getQuestionType() {
    return questionType;
  }

  public void setQuestionType(String questionType) {
    this.questionType = questionType;
  }

  public String getQuestion() {
    return question;
  }

  public void setQuestion(String question) {
    this.question = question;
  }

  public String getDefaultSelection() {
    return defaultSelection;
  }

  public void setDefaultSelection(String defaultSelection) {
    this.defaultSelection = defaultSelection;
  }

  public String getQuestionDescYes() {
    return questionDescYes;
  }

  public void setQuestionDescYes(String questionDescYes) {
    this.questionDescYes = questionDescYes;
  }

  public String getQuestionDescNo() {
    return questionDescNo;
  }

  public void setQuestionDescNo(String questionDescNo) {
    this.questionDescNo = questionDescNo;
  }

  public int getYesWeightage() {
    return yesWeightage;
  }

  public void setYesWeightage(int yesWeightage) {
    this.yesWeightage = yesWeightage;
  }

  public int getNoWeightage() {
    return noWeightage;
  }

  public void setNoWeightage(int noWeightage) {
    this.noWeightage = noWeightage;
  }
}
