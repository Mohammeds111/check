package com.did.portin.model.bandwidth;

import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

@Root(name = "ResponseStatus", strict = false)
public class ResponseStatus {

  @Element(name = "ErrorCode", required = false)
  private int errorCode;

  @Element(name = "Description", required = false)
  private String description;

  public int getErrorCode() {
    return errorCode;
  }

  public void setErrorCode(int errorCode) {
    this.errorCode = errorCode;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }
}
