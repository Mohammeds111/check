package com.did.portin.model.sort;

public class Sorting<A extends SortAttribute> {
    private SortDirection direction;
    private A attribute;

    public Sorting() {
    }

    public SortDirection getDirection() {
        return this.direction;
    }

    public void setDirection(SortDirection direction) {
        this.direction = direction;
    }

    public A getAttribute() {
        return this.attribute;
    }

    public void setAttribute(A attribute) {
        this.attribute = attribute;
    }

    public Sorting<A> withDirection(SortDirection direction) {
        this.direction = direction;
        return this;
    }

    public Sorting<A> withAttribute(A attribute) {
        this.attribute = attribute;
        return this;
    }
}
