package com.did.portin.model.bandwidth;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

@Root(name = "ServiceAddress", strict = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ServiceAddress {

  @Element(name = "HouseNumber", required = false)
  private String houseNumber;

  @Element(name = "HousePrefix", required = false)
  private String housePrefix;

  @Element(name = "HouseSuffix", required = false)
  private String houseSuffix;

  @Element(name = "PreDirectional", required = false)
  private String preDirectional;

  @Element(name = "StreetName", required = false)
  private String streetName;

  @Element(name = "StreetSuffix", required = false)
  private String streetSuffix;

  @Element(name = "PostDirectional", required = false)
  private String postDirectional;

  @Element(name = "AddressLine2", required = false)
  private String addressLine2;

  @Element(name = "City", required = false)
  private String city;

  @Element(name = "StateCode", required = false)
  private String stateCode;

  @Element(name = "Zip", required = false)
  private String zip;

  @Element(name = "Country", required = false)
  private String country;

  @Element(name = "AddressType", required = false)
  private String addressType;

  public String getHouseNumber() {
    return houseNumber;
  }

  public void setHouseNumber(String houseNumber) {
    this.houseNumber = houseNumber;
  }

  public String getHousePrefix() {
    return housePrefix;
  }

  public void setHousePrefix(String housePrefix) {
    this.housePrefix = housePrefix;
  }

  public String getHouseSuffix() {
    return houseSuffix;
  }

  public void setHouseSuffix(String houseSuffix) {
    this.houseSuffix = houseSuffix;
  }

  public String getPreDirectional() {
    return preDirectional;
  }

  public void setPreDirectional(String preDirectional) {
    this.preDirectional = preDirectional;
  }

  public String getStreetName() {
    return streetName;
  }

  public void setStreetName(String streetName) {
    this.streetName = streetName;
  }

  public String getStreetSuffix() {
    return streetSuffix;
  }

  public void setStreetSuffix(String streetSuffix) {
    this.streetSuffix = streetSuffix;
  }

  public String getPostDirectional() {
    return postDirectional;
  }

  public void setPostDirectional(String postDirectional) {
    this.postDirectional = postDirectional;
  }

  public String getAddressLine2() {
    return addressLine2;
  }

  public void setAddressLine2(String addressLine2) {
    this.addressLine2 = addressLine2;
  }

  public String getCity() {
    return city;
  }

  public void setCity(String city) {
    this.city = city;
  }

  public String getStateCode() {
    return stateCode;
  }

  public void setStateCode(String stateCode) {
    this.stateCode = stateCode;
  }

  public String getZip() {
    return zip;
  }

  public void setZip(String zip) {
    this.zip = zip;
  }

  public String getCountry() {
    return country;
  }

  public void setCountry(String country) {
    this.country = country;
  }

  public String getAddressType() {
    return addressType;
  }

  public void setAddressType(String addressType) {
    this.addressType = addressType;
  }
}
