package com.did.portin.discovery;

public class DiscoveryConstants {
  public static final String PRODUCT = "portin";
  public static final String COMPONENT = "portin";
}
