package com.did.portin.model.bandwidth;

import org.simpleframework.xml.Root;

@Root(name = "ValidTnList", strict = false)
public class ValidTnList extends TNs {}
