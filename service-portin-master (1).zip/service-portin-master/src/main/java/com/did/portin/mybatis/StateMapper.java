package com.did.portin.mybatis;

import com.did.portin.model.db.State;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface StateMapper {
    @Select(
            "SELECT "
            + "state_id,"
            + "state,"
            + "state_abbreviation "
            + "FROM "
            + "portin.state ")
    @Results({
            @Result(property = "stateId",column = "state_id"),
            @Result(property = "state",column = "state"),
            @Result(property = "stateAbbreviation",column = "state_abbreviation")
    })
    public List<State> getListStates();

    @Select(
            "SELECT "
                    + "state_id,"
                    + "state,"
                    + "state_abbreviation "
                    + "FROM "
                    + "portin.state "
                    + "WHERE "
                    + "state_abbreviation = #{stateAbbreviation} ")
    @Results({
            @Result(property = "stateId",column = "state_id"),
            @Result(property = "state",column = "state"),
            @Result(property = "stateAbbreviation", column = "state_abbreviation")})
    public State getAddressState(@Param("stateAbbreviation") String getStateAbbreviation);
}
