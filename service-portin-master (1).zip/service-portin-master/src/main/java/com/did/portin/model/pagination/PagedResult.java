package com.did.portin.model.pagination;

import java.util.ArrayList;
import java.util.List;

public class PagedResult<T> {
    private List<T> entities = new ArrayList();
    private int rowCount = 0;

    public PagedResult() {
    }

    public List<T> getEntities() {
        return this.entities;
    }

    public void setEntities(List<T> entities) {
        this.entities = entities;
    }

    public int getRowCount() {
        return this.rowCount;
    }

    public void setRowCount(int rowCount) {
        this.rowCount = rowCount;
    }

    public PagedResult<T> withEntities(List<T> entities) {
        this.entities = entities;
        return this;
    }

    public PagedResult<T> withRowCount(int rowCount) {
        this.rowCount = rowCount;
        return this;
    }
}
