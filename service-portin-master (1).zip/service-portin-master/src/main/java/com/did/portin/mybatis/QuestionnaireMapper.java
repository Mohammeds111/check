package com.did.portin.mybatis;

import com.did.portin.model.db.Questionnaire;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface QuestionnaireMapper {
  @Select(
      "SELECT "
          + "qid, "
          + "qname, "
          + "qtype, "
          + "question, "
          + "default_selection, "
          + "q_desc_yes, "
          + "q_desc_no, "
          + "yes_weightage, "
          + "no_weightage "
          + "FROM "
          + "portin.portin_questionnaire ")
  @Results({
    @Result(property = "questionId", column = "qid"),
    @Result(property = "questionName", column = "qname"),
    @Result(property = "questionType", column = "qtype"),
    @Result(property = "question", column = "question"),
    @Result(property = "defaultSelection", column = "default_selection"),
    @Result(property = "questionDescYes", column = "q_desc_yes"),
    @Result(property = "questionDescNo", column = "q_desc_no"),
    @Result(property = "yesWeightage", column = "yes_weightage"),
    @Result(property = "noWeightage", column = "no_weightage")
  })
  public List<Questionnaire> getPrecheckQuestionnaire();
}
