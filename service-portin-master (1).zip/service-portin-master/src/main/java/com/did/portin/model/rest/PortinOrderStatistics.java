package com.did.portin.model.rest;

public class PortinOrderStatistics {
    private int total;
    private int carriers;
    private int rateCenter;
    private int wireless;
    private int wired;
    private int tollfree;

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public int getCarriers() {
        return carriers;
    }

    public void setCarriers(int carriers) {
        this.carriers = carriers;
    }

    public int getRateCenter() {
        return rateCenter;
    }

    public void setRateCenter(int rateCenter) {
        this.rateCenter = rateCenter;
    }

    public int getWireless() {
        return wireless;
    }

    public void setWireless(int wireless) {
        this.wireless = wireless;
    }

    public int getWired() {
        return wired;
    }

    public void setWired(int wired) {
        this.wired = wired;
    }

    public int getTollfree() {
        return tollfree;
    }

    public void setTollfree(int tollfree) {
        this.tollfree = tollfree;
    }
}
