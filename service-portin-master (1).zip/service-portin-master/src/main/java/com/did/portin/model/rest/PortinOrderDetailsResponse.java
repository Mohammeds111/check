package com.did.portin.model.rest;

import java.util.List;

public class PortinOrderDetailsResponse {
    private List<PortinOrderResponse> supportedOrders;
    private PortinOrderStatistics stats;

    public List<PortinOrderResponse> getSupportedOrders() {
        return supportedOrders;
    }

    public void setSupportedOrders(List<PortinOrderResponse> supportedOrders) {
        this.supportedOrders = supportedOrders;
    }

    public PortinOrderStatistics getStats() {
        return stats;
    }

    public void setStats(PortinOrderStatistics stats) {
        this.stats = stats;
    }
}
