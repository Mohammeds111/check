package com.did.portin.model.enums;

public enum PortinOrderStatus {

    // Portin order status candidates
    DRAFT(0, "DRAFT"),
    PENDING_DOCUMENTS(1, "PENDING_DOCUMENTS"),
    SUBMITTED(2, "SUBMITTED"),
    EXCEPTION(3, "EXCEPTION"),
    REQUESTED_CANCEL(4, "REQUESTED_CANCEL"),
    REQUESTED_SUPP(5, "REQUESTED_SUPP"),
    FOC(6, "FOC"),
    CANCELLED(7, "CANCELLED"),
    COMPLETE(8, "COMPLETE");

    private long statusId;
    private String statusName;

    PortinOrderStatus(int statusId, String statusName) {
        this.statusId = statusId;
        this.statusName = statusName;
    }

    public long getStatusId() {
        return this.statusId;
    }

    public String getStatusName() {
        return this.statusName;
    }

    public static PortinOrderStatus getStatusTypeFromId(long statusId) {
        for (PortinOrderStatus portinOrderStatus : PortinOrderStatus.values()) {
            if (portinOrderStatus.getStatusId() == statusId) {
                return portinOrderStatus;
            }
        }

        return null;
    }

    public static PortinOrderStatus getStatusTypeFromName(String statusName) {
        for (PortinOrderStatus portinOrderStatus : PortinOrderStatus.values()) {
            if (portinOrderStatus.getStatusName().equalsIgnoreCase(statusName)) {
                return portinOrderStatus;
            }
        }

        return null;
    }
}