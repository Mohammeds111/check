package com.did.portin.model.bandwidth;

import org.simpleframework.xml.ElementList;

import java.util.List;

public class TNs {
  @ElementList(entry = "TN", inline = true, required = false)
  private List<String> tns;

  public List<String> getTns() {
    return tns;
  }

  public void setTns(List<String> tns) {
    this.tns = tns;
  }
}
