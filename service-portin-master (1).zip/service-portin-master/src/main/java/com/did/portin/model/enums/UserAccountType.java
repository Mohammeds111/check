package com.did.portin.model.enums;

public enum UserAccountType {

    // User account type candidates
    BUSINESS,
    RESIDENTIAL;

    public static UserAccountType getUserAccountTypeFromName(String name) {
        for (UserAccountType userAccountType : UserAccountType.values()) {
            if (userAccountType.name().equalsIgnoreCase(name)) {
                return userAccountType;
            }
        }

        return null;
    }
}