package com.did.portin.model.rest;

public abstract class BaseFilter {
    public BaseFilter() {
    }
}
