package com.did.portin.client;

import okhttp3.OkHttpClient;
import org.simpleframework.xml.convert.AnnotationStrategy;
import org.simpleframework.xml.core.Persister;
import retrofit2.Retrofit;
import retrofit2.converter.simplexml.SimpleXmlConverterFactory;

import java.util.Base64;
import java.util.concurrent.TimeUnit;

public class BandwidthClientFactory {
  private static final String BASIC = "Basic ";

  private Retrofit retrofit;

  private BandwidthClient bandwidthClient;

  private String basicAuthToken;

  public BandwidthClientFactory() {

    basicAuthToken =
        Base64.getEncoder()
            .encodeToString(String.format("%s:%s", "stalluri", "Virtusa123!").getBytes());

    // TODO read from properties
    String bandwidthBaseUrl = "https://test.dashboard.bandwidth.com/api/accounts/5000908/";

    OkHttpClient.Builder httpClient =
        new OkHttpClient.Builder()
            .connectTimeout(180, TimeUnit.SECONDS)
            .readTimeout(180, TimeUnit.SECONDS)
            .writeTimeout(180, TimeUnit.SECONDS);

    // Create Foundry Clients

    Retrofit.Builder bandwidthBuilder =
        new Retrofit.Builder()
            .baseUrl(bandwidthBaseUrl)
            .addConverterFactory(SimpleXmlConverterFactory.create(new Persister(new AnnotationStrategy())));

    retrofit = bandwidthBuilder.client(httpClient.build()).build();

    this.setBandwidthClient(retrofit.create(BandwidthClient.class));
  }

  public String generateBWToken() {
    return BASIC + basicAuthToken;
  }

  public BandwidthClient getBandwidthClient() {
    return bandwidthClient;
  }

  public void setBandwidthClient(BandwidthClient bandwidthClient) {
    this.bandwidthClient = bandwidthClient;
  }

  public Retrofit getRetrofit() {
    return retrofit;
  }

}
