package com.did.portin.model.bandwidth;

import org.simpleframework.xml.Element;

public class LnpOrderSuppAttributes {

  @Element(name = "CustomerOrderId", required = false)
  private String customerOrderId;

  @Element(name = "RequestedFocDate", required = false)
  private String requestedFocDate;

  @Element(name = "BillingTelephoneNumber", required = false)
  private String billingTelephoneNumber;

  @Element(name = "NewBillingTelephoneNumber", required = false)
  private String newBillingTelephoneNumber;

  @Element(name = "Subscriber", required = false)
  private Subscriber subscriber;

  @Element(name = "SiteId", required = false)
  private String siteId;

  @Element(name = "PeerId", required = false)
  private String peerId;

  @Element(name = "PartialPort", required = false)
  private String partialPort;

  @Element(name = "LoaAuthorizingPerson", required = false)
  private String loaAuthorizingPerson;

  @Element(name = "WirelessInfo", required = false)
  private WirelessInfo wirelessInfo;

  @Element(name = "ListOfPhoneNumbers", required = false)
  private ListOfPhoneNumbers listOfPhoneNumbers;

  @Element(name = "Triggered", required = false)
  private String triggered;

  @Element(name = "Immediately", required = false)
  private String immediately;

  @Element(name = "ProcessingStatus", required = false)
  private String processingStatus;

  public String getCustomerOrderId() {
    return customerOrderId;
  }

  public void setCustomerOrderId(String customerOrderId) {
    this.customerOrderId = customerOrderId;
  }

  public String getRequestedFocDate() {
    return requestedFocDate;
  }

  public void setRequestedFocDate(String requestedFocDate) {
    this.requestedFocDate = requestedFocDate;
  }

  public String getBillingTelephoneNumber() {
    return billingTelephoneNumber;
  }

  public void setBillingTelephoneNumber(String billingTelephoneNumber) {
    this.billingTelephoneNumber = billingTelephoneNumber;
  }

  public String getNewBillingTelephoneNumber() {
    return newBillingTelephoneNumber;
  }

  public void setNewBillingTelephoneNumber(String newBillingTelephoneNumber) {
    this.newBillingTelephoneNumber = newBillingTelephoneNumber;
  }

  public Subscriber getSubscriber() {
    return subscriber;
  }

  public void setSubscriber(Subscriber subscriber) {
    this.subscriber = subscriber;
  }

  public String getSiteId() {
    return siteId;
  }

  public void setSiteId(String siteId) {
    this.siteId = siteId;
  }

  public String getPeerId() {
    return peerId;
  }

  public void setPeerId(String peerId) {
    this.peerId = peerId;
  }

  public String getPartialPort() {
    return partialPort;
  }

  public void setPartialPort(String partialPort) {
    this.partialPort = partialPort;
  }

  public String getLoaAuthorizingPerson() {
    return loaAuthorizingPerson;
  }

  public void setLoaAuthorizingPerson(String loaAuthorizingPerson) {
    this.loaAuthorizingPerson = loaAuthorizingPerson;
  }

  public ListOfPhoneNumbers getListOfPhoneNumbers() {
    return listOfPhoneNumbers;
  }

  public void setListOfPhoneNumbers(ListOfPhoneNumbers listOfPhoneNumbers) {
    this.listOfPhoneNumbers = listOfPhoneNumbers;
  }

  public String getTriggered() {
    return triggered;
  }

  public void setTriggered(String triggered) {
    this.triggered = triggered;
  }

  public String getImmediately() {
    return immediately;
  }

  public void setImmediately(String immediately) {
    this.immediately = immediately;
  }

  public String getProcessingStatus() {
    return processingStatus;
  }

  public void setProcessingStatus(String processingStatus) {
    this.processingStatus = processingStatus;
  }

  public WirelessInfo getWirelessInfo() {
    return wirelessInfo;
  }

  public void setWirelessInfo(WirelessInfo wirelessInfo) {
    this.wirelessInfo = wirelessInfo;
  }
}
