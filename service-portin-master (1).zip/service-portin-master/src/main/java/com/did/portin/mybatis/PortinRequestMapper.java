package com.did.portin.mybatis;

import com.did.portin.model.db.PortinRequest;
import com.did.portin.model.rest.PortinRequestFilter;
import java.util.List;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

@Mapper
public interface PortinRequestMapper {

  public static String PORTINREQUEST_SEARCH_WHERE_FILTER =
      "  request_status IN (<foreach collection='criteria.statuses' item='status' separator=','>#{status}</foreach>) "
          + "<if test='criteria.q != null'>"
          + "  AND "
          + "  (portin_external_request_id ILIKE #{criteria.q} "
          + "  OR "
          + "  requested_user_fullname ILIKE #{criteria.q} "
          + "  OR "
          + "  to_char(requested_quantity, '9999999999') ILIKE #{criteria.q} "
          + "  OR "
          + "  to_char(request_status, '9999999999') ILIKE #{criteria.q} "
          + "  OR "
          + "  to_char(requested_date, 'YYYY-MON-DD HH24:MI:SS.MS-TZ') ILIKE #{criteria.q} "
          + "  ) "
          + "</if>"
          + "<if test='criteria.organization != null'>"
          + "   AND "
          + "   (organization_code ILIKE #{criteria.organization} "
          + "   OR organization_name ILIKE #{criteria.organization}) "
          + "</if>";

  public static final String PORTIN_EXTERNAL_REQUEST_ID =
      " CONCAT( "
          + "'PREQ',"
          + "TO_CHAR(current_timestamp, 'YYYYMMDD'), "
          + "'-', "
          + "LPAD( currval(pg_get_serial_sequence('portin.portin_request', 'portin_request_id'))::text, 10, '0') "
          + "), ";

  @Insert({
    "INSERT INTO portin.portin_request("
        + "portin_external_request_id, "
        + "request_status, "
        + "requested_date, "
        + "requested_user_id, "
        + "requested_user_email, "
        + "requested_user_fullname, "
        + "requested_user_code "
        + ")"
        + "VALUES"
        + "("
        + PORTIN_EXTERNAL_REQUEST_ID
        + "#{createPortinRequest.requestStatus},"
        + "current_timestamp,"
        + "#{createPortinRequest.requestedUserId},"
        + "#{createPortinRequest.requestedUserEmail},"
        + "#{createPortinRequest.requestedUserFullName},"
        + "#{createPortinRequest.requestedUserCode} "
        + ") RETURNING portin_request_id, portin_external_request_id"
  })
  @Options(
      useGeneratedKeys = true,
      keyProperty =
          "createPortinRequest.portinRequestId,createPortinRequest.portinExternalRequestId",
      keyColumn = "portin_request_id,portin_external_request_id")
  public Long insertPortinRequest(@Param("createPortinRequest") PortinRequest createPortinRequest);

  @Select(
      "SELECT "
          + "portin_request_id "
          + "FROM "
          + "portin.portin_request "
          + "WHERE "
          + "portin_request_id = #{portinRequestId} ")
  @Results({@Result(property = "portinRequestId", column = "portin_request_id")})
  public PortinRequest getPortinRequestById(@Param("portinRequestId") Long portinRequestId);

  @Select(
      "<script> "
          + "SELECT count(*) "
          + "FROM portin.portin_request pr "
          + "<where> "
          + PORTINREQUEST_SEARCH_WHERE_FILTER
          + " </where>"
          + "</script>")
  public int count(@Param("criteria") PortinRequestFilter criteria);

  @Select(
      "<script> "
          + "SELECT "
          + "portin_request_id, "
          + "portin_external_request_id, "
          + "customer_account_id, "
          + "phone_numbers, "
          + "non_portable_numbers, "
          + "requested_activation_date, "
          + "requested_quantity, "
          + "request_status, "
          + "bulk_port_order_number, "
          + "organization_code, "
          + "organization_name, "
          + "requested_date, "
          + "requested_user_id, "
          + "requested_user_email, "
          + "requested_user_fullname, "
          + "requested_user_code, "
          + "modified_date, "
          + "modified_user_id, "
          + "modified_user_email, "
          + "modified_user_fullname, "
          + "modified_user_code, "
          + "completed_date, "
          + "completed_user_id, "
          + "completed_user_email, "
          + "completed_user_fullname, "
          + "completed_user_code, "
          + "notes, "
          + "( "
          + " false ) as overdue "
          + "FROM "
          + "portin.portin_request "
          + "<where> "
          + PORTINREQUEST_SEARCH_WHERE_FILTER
          + " </where>"
          + " ORDER BY "
          + "<choose>"
          + "<when test=\"sortField == 'portin_request_id'\"> request_id </when>"
          + "<when test=\"sortField == 'portin_external_request_id'\"> portin_external_request_id </when>"
          + "<when test=\"sortField == 'requested_date'\"> requested_date </when>"
          + "<when test=\"sortField == 'organization'\"> organization </when>"
          + "<when test=\"sortField == 'organization_name'\"> organization_name </when>"
          + "<otherwise> requested_date </otherwise>"
          + "</choose>"
          + "<choose>"
          + "<when test=\"sortOrder\"> ASC </when>"
          + "<otherwise> DESC </otherwise>"
          + "</choose>"
          + " LIMIT #{limit} OFFSET #{offset} "
          + "</script>")
  @Results({
    @Result(property = "portinRequestId", column = "portin_request_id"),
    @Result(property = "portinExternalRequestId", column = "portin_external_request_id"),
    @Result(property = "customerAccountId", column = "customer_account_id"),
    @Result(property = "phoneNumbers", column = "phone_numbers"),
    @Result(property = "nonPortableNumbers", column = "non_portable_numbers"),
    @Result(property = "requestedActivationDate", column = "requested_activation_date"),
    @Result(property = "requestedQuantity", column = "requested_quantity"),
    @Result(property = "requestStatus", column = "request_status"),
    @Result(property = "bulkPortOrderNumber", column = "bulk_port_order_number"),
    @Result(property = "organizationCode", column = "organization_code"),
    @Result(property = "organizationName", column = "organization_name"),
    @Result(property = "requestedDate", column = "requested_date"),
    @Result(property = "requestedUserId", column = "requested_user_id"),
    @Result(property = "requestedUserEmail", column = "requested_user_email"),
    @Result(property = "requestedUserFullName", column = "requested_user_fullname"),
    @Result(property = "requestedUserCode", column = "requested_user_code"),
    @Result(property = "modifiedDate", column = "modified_date"),
    @Result(property = "modifiedUserId", column = "modified_user_id"),
    @Result(property = "modifiedUserEmail", column = "modified_user_email"),
    @Result(property = "modifiedUserFullName", column = "modified_user_fullname"),
    @Result(property = "modifiedUserCode", column = "modified_user_code"),
    @Result(property = "completedDate", column = "completed_date"),
    @Result(property = "completedUserId", column = "completed_user_id"),
    @Result(property = "completedUserEmail", column = "completed_user_email"),
    @Result(property = "completedUserFullName", column = "completed_user_fullname"),
    @Result(property = "completedUserCode", column = "completed_user_code"),
    @Result(property = "notes", column = "notes"),
    @Result(property = "overdue", column = "overdue")
  })
  public List<PortinRequest> searchPortinRequests(
      @Param("criteria") PortinRequestFilter criteria,
      @Param("sortField") String sortField,
      @Param("sortOrder") boolean sortOrder,
      @Param("limit") int limit,
      @Param("offset") int offset);

  @Select(
      "SELECT "
          + "portin_request_id, "
          + "portin_external_request_id, "
          + "customer_account_id, "
          + "phone_numbers, "
          + "non_portable_numbers, "
          + "requested_activation_date, "
          + "requested_quantity, "
          + "request_status, "
          + "bulk_port_order_number, "
          + "organization_code, "
          + "organization_name, "
          + "requested_date, "
          + "requested_user_id, "
          + "requested_user_email, "
          + "requested_user_fullname, "
          + "requested_user_code, "
          + "modified_date, "
          + "modified_user_id, "
          + "modified_user_email, "
          + "modified_user_fullname, "
          + "modified_user_code, "
          + "completed_date, "
          + "completed_user_id, "
          + "completed_user_email, "
          + "completed_user_fullname, "
          + "completed_user_code, "
          + "notes, "
          + "( "
          + " false ) as overdue "
          + "FROM "
          + "portin.portin_request "
          + "WHERE "
          + "portin_request_id = #{portinRequestId} ")
  @Results({
    @Result(property = "portinRequestId", column = "portin_request_id"),
    @Result(property = "portinExternalRequestId", column = "portin_external_request_id"),
    @Result(property = "customerAccountId", column = "customer_account_id"),
    @Result(property = "phoneNumbers", column = "phone_numbers"),
    @Result(property = "nonPortableNumbers", column = "non_portable_numbers"),
    @Result(property = "requestedActivationDate", column = "requested_activation_date"),
    @Result(property = "requestedQuantity", column = "requested_quantity"),
    @Result(property = "requestStatus", column = "request_status"),
    @Result(property = "bulkPortOrderNumber", column = "bulk_port_order_number"),
    @Result(property = "organizationCode", column = "organization_code"),
    @Result(property = "organizationName", column = "organization_name"),
    @Result(property = "requestedDate", column = "requested_date"),
    @Result(property = "requestedUserId", column = "requested_user_id"),
    @Result(property = "requestedUserEmail", column = "requested_user_email"),
    @Result(property = "requestedUserFullName", column = "requested_user_fullname"),
    @Result(property = "requestedUserCode", column = "requested_user_code"),
    @Result(property = "modifiedDate", column = "modified_date"),
    @Result(property = "modifiedUserId", column = "modified_user_id"),
    @Result(property = "modifiedUserEmail", column = "modified_user_email"),
    @Result(property = "modifiedUserFullName", column = "modified_user_fullname"),
    @Result(property = "modifiedUserCode", column = "modified_user_code"),
    @Result(property = "completedDate", column = "completed_date"),
    @Result(property = "completedUserId", column = "completed_user_id"),
    @Result(property = "completedUserEmail", column = "completed_user_email"),
    @Result(property = "completedUserFullName", column = "completed_user_fullname"),
    @Result(property = "completedUserCode", column = "completed_user_code"),
    @Result(property = "notes", column = "notes"),
    @Result(property = "overdue", column = "overdue")
  })
  public PortinRequest getPortinRequestDetail(@Param("portinRequestId") Long portinRequestId);

  @Update(
      "<script>"
          + "Update portin.portin_request "
          + "<set>"
          + "modified_date = current_timestamp, "
          + "<if test='portinRequest.customerAccountId != null'>customer_account_id = #{portinRequest.customerAccountId}, </if>"
          + "<if test='portinRequest.phoneNumbers != null'>phone_numbers = #{portinRequest.phoneNumbers}, </if>"
          + "<if test='portinRequest.nonPortableNumbers != null'>non_portable_numbers = #{portinRequest.nonPortableNumbers}, </if>"
          + "<if test='portinRequest.requestedActivationDate != null'>requested_activation_date = #{portinRequest.requestedActivationDate}, </if>"
          + "<if test='portinRequest.requestedQuantity != null'>requested_quantity = #{portinRequest.requestedQuantity}, </if>"
          + "<if test='portinRequest.requestStatus != null'>request_status = #{portinRequest.requestStatus}, </if>"
          + "<if test='portinRequest.bulkPortOrderNumber != null'>bulk_port_order_number = #{portinRequest.bulkPortOrderNumber}, </if>"
          + "<if test='portinRequest.organizationCode != null'>organization_code = #{portinRequest.organizationCode}, </if>"
          + "<if test='portinRequest.organizationName != null'>organization_name = #{portinRequest.organizationName}, </if>"
          + "<if test='portinRequest.requestedDate != null'>requested_date = #{portinRequest.requestedDate}, </if>"
          + "<if test='portinRequest.requestedUserId != null'>requested_user_id = #{portinRequest.requestedUserId}, </if>"
          + "<if test='portinRequest.requestedUserEmail != null'>requested_user_email = #{portinRequest.requestedUserEmail}, </if>"
          + "<if test='portinRequest.requestedUserFullName != null'>requested_user_fullname = #{portinRequest.requestedUserFullName}, </if>"
          + "<if test='portinRequest.requestedUserCode != null'>requested_user_code = #{portinRequest.requestedUserCode}, </if>"
          + "<if test='portinRequest.modifiedUserId != null'>modified_user_id = #{portinRequest.modifiedUserId}, </if>"
          + "<if test='portinRequest.modifiedUserEmail != null'>modified_user_email = #{portinRequest.modifiedUserEmail}, </if>"
          + "<if test='portinRequest.modifiedUserFullName != null'>modified_user_fullname = #{portinRequest.modifiedUserFullName}, </if>"
          + "<if test='portinRequest.modifiedUserCode != null'>modified_user_code = #{portinRequest.modifiedUserCode}, </if>"
          + "<if test='portinRequest.completedDate != null'>completed_date = #{portinRequest.completedDate}, </if>"
          + "<if test='portinRequest.completedUserId != null'>completed_user_id = #{portinRequest.completedUserId}, </if>"
          + "<if test='portinRequest.completedUserEmail != null'>completed_user_email = #{portinRequest.completedUserEmail}, </if>"
          + "<if test='portinRequest.completedUserFullName != null'>completed_user_fullname = #{portinRequest.completedUserFullName}, </if>"
          + "<if test='portinRequest.completedUserCode != null'>completed_user_code = #{portinRequest.completedUserCode}, </if>"
          + "<if test='portinRequest.notes != null'>notes = #{portinRequest.notes} </if>"
          + "</set>"
          + "WHERE "
          + "portin_request_id = #{portinRequest.portinRequestId}"
          + "</script>")
  public void updatePortinRequest(@Param("portinRequest") PortinRequest portinRequest);

  @Delete("DELETE FROM portin.portin_request WHERE portin_request_id = #{portinRequestId}")
  void deletePortinRequest(@Param("portinRequestId") Long portinRequestId);
}
