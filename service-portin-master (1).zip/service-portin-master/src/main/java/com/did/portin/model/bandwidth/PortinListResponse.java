package com.did.portin.model.bandwidth;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

@Root(name = "PortinListResponse", strict = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PortinListResponse {
    @Element(name = "PortinList", required = false)
    private PortinList portinList;

    @Element(name = "ResponseStatus", required = false)
    private ResponseStatus responseStatus;

    public PortinList getPortinList() {
        return portinList;
    }

    public void setPortinList(PortinList portinList) {
        this.portinList = portinList;
    }

    public ResponseStatus getResponseStatus() {
        return responseStatus;
    }

    public void setResponseStatus(ResponseStatus responseStatus) {
        this.responseStatus = responseStatus;
    }
}
