package com.did.portin.model.sort;

public enum SortDirection {
    asc,
    desc;

    private SortDirection() {
    }
}