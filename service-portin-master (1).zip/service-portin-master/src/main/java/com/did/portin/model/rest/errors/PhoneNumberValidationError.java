package com.did.portin.model.rest.errors;

import java.util.List;

public class PhoneNumberValidationError {
  private List<String> numbers;
  private List<Error> errors;

  public List<String> getNumbers() {
    return numbers;
  }

  public void setNumbers(List<String> numbers) {
    this.numbers = numbers;
  }

  public List<Error> getErrors() {
    return errors;
  }

  public void setErrors(List<Error> errors) {
    this.errors = errors;
  }
}
