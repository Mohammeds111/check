package com.did.portin.model.bandwidth;

import org.simpleframework.xml.Root;

@Root(name = "Status", strict = false)
public class Status extends ErrorCommonAttributes {
}
