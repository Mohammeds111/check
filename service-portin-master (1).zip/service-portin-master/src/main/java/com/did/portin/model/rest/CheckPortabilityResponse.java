package com.did.portin.model.rest;

import com.did.portin.model.db.PortinOrder;
import com.did.portin.model.rest.errors.PhoneNumberValidationError;
import java.util.List;

public class CheckPortabilityResponse {
    private List<PortinOrder> supportedOrders;
    private List<String> unsupportedNumbers;
    private List<PhoneNumberValidationError> invalidNumbers;
    private PortinOrderStatistics stats;

    public List<PortinOrder> getSupportedOrders() {
        return supportedOrders;
    }

    public void setSupportedOrders(List<PortinOrder> supportedOrders) {
        this.supportedOrders = supportedOrders;
    }

    public List<String> getUnsupportedNumbers() {
        return unsupportedNumbers;
    }

    public void setUnsupportedNumbers(List<String> unsupportedNumbers) {
        this.unsupportedNumbers = unsupportedNumbers;
    }

    public List<PhoneNumberValidationError> getInvalidNumbers() {
        return invalidNumbers;
    }

    public void setInvalidNumbers(List<PhoneNumberValidationError> invalidNumbers) {
        this.invalidNumbers = invalidNumbers;
    }

    public PortinOrderStatistics getStats() {
        return stats;
    }

    public void setStats(PortinOrderStatistics stats) {
        this.stats = stats;
    }
}
