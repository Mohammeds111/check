package com.did.portin.jaxrs;

import com.did.portin.model.file.StreamingInputFile;
import com.did.portin.model.rest.PortinFileRespose;
import com.did.portin.model.rest.PortinResponse;
import com.did.portin.service.PortinFileSystemService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.inject.Inject;
import javax.validation.ValidationException;
import javax.ws.rs.QueryParam;
import java.util.Objects;
import java.util.Optional;

@RestController
public class DIDPortinFilesEndPoint {
  private static final Logger logger = LoggerFactory.getLogger(DIDPortinFilesEndPoint.class);
  @Inject PortinFileSystemService portinFileSystemService;

  @PostMapping("/portin-request/{portinRequestId}/portin-order/{portinOrderId}/document")
  public PortinResponse documentFileUpload(
      @PathVariable("portinRequestId") Long portinRequestId,
      @PathVariable("portinOrderId") Long portinOrderId,
      @RequestParam("file") MultipartFile file,
      @RequestParam("filetype") String fileType,
      @QueryParam("signedDate") String signedDate)
      throws Exception {
    if (file == null || file.isEmpty()) {
      throw new ValidationException("No file attachment found in the request.");
    } else if (fileType == null || fileType.isEmpty()) {
      throw new ValidationException("No file type found in the request.");
    }

    String fileName = StringUtils.cleanPath(file.getOriginalFilename());
    return PortinResponse.generateResponse(
        "Ok",
        200,
        portinFileSystemService.saveDocumentToPortinOrder(
            file.getBytes(), fileName, portinRequestId, portinOrderId, fileType, signedDate));
  }

  @DeleteMapping(
      "/portin-request/{portinRequestId}/portin-order/{portinOrderId}/document/{portinRequestFileId}")
  public PortinResponse deleteDocumentForOrder(
      @PathVariable("portinRequestId") Long portinRequestId,
      @PathVariable("portinOrderId") Long portinOrderId,
      @PathVariable("portinRequestFileId") Long portinRequestFileId)
      throws Exception {
    return PortinResponse.generateResponse(
        "Ok",
        0,
        portinFileSystemService.deleteDocumentFromOrder(
            portinRequestId, portinOrderId, portinRequestFileId));
  }

  @GetMapping(
      "/portin-request/{portinReqId}/portin-order/{portinOrderId}/document/{portinRequestFileId}")
  public @ResponseBody ResponseEntity<Resource> downloadFile(
      @PathVariable("portinReqId") Long portinRequestId,
      @PathVariable("portinOrderId") Long portinOrderId,
      @PathVariable("portinRequestFileId") Long portinRequestFileId)
      throws Exception {

    if (Optional.ofNullable(portinRequestId).orElse(0L) <= 0) {
      throw new ValidationException("Did portin request ID can not be zero or less than zero.");
    } else if (Optional.ofNullable(portinOrderId).orElse(0L) <= 0) {
      throw new ValidationException("Did portin order ID can not be zero or less than zero.");
    } else if (Optional.ofNullable(portinRequestFileId).orElse(0L) <= 0) {
      throw new ValidationException("Portin request file ID can not be zero or less than zero.");
    }
    PortinFileRespose portinFileRespose =
        portinFileSystemService.getPortinRequestFileId(portinRequestFileId);
    if (Objects.isNull(portinFileRespose)
        || Objects.isNull(portinFileRespose.getPortinRequestFileId())) {
      throw new ValidationException("Portin request file ID does not exists.");
    }

    StreamingInputFile streamingInputFile =
        portinFileSystemService.getFileToDownload(
            portinRequestId, portinOrderId, portinRequestFileId);
    InputStreamResource resource = new InputStreamResource(streamingInputFile.getStreamingInput());

    return ResponseEntity.ok()
        .header(
            HttpHeaders.CONTENT_DISPOSITION,
            "attachment; filename=\"" + streamingInputFile.getFileName() + "\"")
        .contentType(MediaType.parseMediaType("application/octet-stream"))
        .body(resource);
  }

  @GetMapping("/portin-request/{portinReqId}/portin-order/{portinOrderId}/document")
  public PortinResponse getPortinOrderDetails(
      @PathVariable("portinReqId") Long portinRequestId,
      @PathVariable("portinOrderId") Long portinOrderId)
      throws Exception {
    return PortinResponse.generateResponse(
        "Ok", 0, portinFileSystemService.getFileDetails(portinRequestId, portinOrderId));
  }

  @ExceptionHandler(Exception.class)
  public ResponseEntity<String> handleException(Exception exception) throws JSONException {
    JSONObject response = new JSONObject();
    response.put("Error Message", exception.getMessage());
    logger.debug("Exception in DIDPortinFilesEndPoint:", exception.getMessage());
    return new ResponseEntity<String>(response.toString(), HttpStatus.BAD_REQUEST);
  }
}
