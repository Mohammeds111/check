package com.did.portin.model.enums;

public enum PortinFileExtensionType {

    // Phone number type candidates
    PDF("application/pdf"),
    TXT("text/plain"),
    JPG("image/jpeg"),
    TIFF("image/tiff"),
    CSV("text/csv"),
    XML("application/xml"),
    WAV("audio/x-wav"),
    ZIP("application/zip");

    private String mimeType;

    PortinFileExtensionType(String mimeType) {
        this.mimeType = mimeType;
    }

    public String getMimeType() {
        return this.mimeType;
    }

    public static PortinFileExtensionType getPortinFileExtensionTypeFromName(String fileExtension) {
        for (PortinFileExtensionType portinFileExtensionType : PortinFileExtensionType.values()) {
            if (portinFileExtensionType.name().equalsIgnoreCase(fileExtension)) {
                return portinFileExtensionType;
            }
        }

        return null;
    }
}