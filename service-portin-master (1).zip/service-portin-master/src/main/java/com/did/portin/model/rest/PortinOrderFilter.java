package com.did.portin.model.rest;

import com.did.portin.model.sort.PortinOrderSortAttribute;
import com.did.portin.model.sort.SortDirection;

public class PortinOrderFilter extends BaseFilter {

  private String q;
  private PortinOrderSortAttribute sortBy;
  private SortDirection sortDirection;
  private Integer[] statuses;
  private String organization;
  private Long portinRequestId;
  private boolean overdue;

  public String getQ() {
    return q;
  }

  public void setQ(String q) {
    this.q = q;
  }

  public PortinOrderSortAttribute getSortBy() {
    return sortBy;
  }

  public void setSortBy(PortinOrderSortAttribute sortBy) {
    this.sortBy = sortBy;
  }

  public SortDirection getSortDirection() {
    return sortDirection;
  }

  public void setSortDirection(SortDirection sortDirection) {
    this.sortDirection = sortDirection;
  }

  public Integer[] getStatuses() {
    return statuses;
  }

  public void setStatuses(Integer[] statuses) {
    this.statuses = statuses;
  }

  public String getOrganization() {
    return organization;
  }

  public void setOrganization(String organization) {
    this.organization = organization;
  }

  public boolean isOverdue() {
    return overdue;
  }

  public void setOverdue(boolean overdue) {
    this.overdue = overdue;
  }

  public PortinOrderFilter withQ(String q) {
    this.q = q;
    return this;
  }

  public PortinOrderFilter withStatuses(Integer[] statuses) {
    this.statuses = statuses;
    return this;
  }

  public PortinOrderFilter withOrganization(String organization) {
    this.organization = organization;
    return this;
  }

  public PortinOrderFilter withOverdue(boolean overdue) {
    this.overdue = overdue;
    return this;
  }

  public Long getPortinRequestId() {
    return portinRequestId;
  }

  public void setPortinRequestId(Long portinRequestId) {
    this.portinRequestId = portinRequestId;
  }

  public PortinOrderFilter withPortinRequestId(Long portinRequestId) {
    this.portinRequestId = portinRequestId;
    return this;
  }
}

