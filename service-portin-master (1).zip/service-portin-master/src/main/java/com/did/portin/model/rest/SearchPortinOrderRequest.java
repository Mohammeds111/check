package com.did.portin.model.rest;

import com.did.portin.model.pagination.Pagination;

public class SearchPortinOrderRequest {

    private PortinOrderFilter filter;
    private Pagination pagination;

    public PortinOrderFilter getFilter() {
        return filter;
    }

    public void setFilter(PortinOrderFilter filter) {
        this.filter = filter;
    }

    public Pagination getPagination() {
        return pagination;
    }

    public void setPagination(Pagination pagination) {
        this.pagination = pagination;
    }
}
