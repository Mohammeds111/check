package com.did.portin.model.bandwidth;

import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

@Root(name = "fileData  ", strict = false)
public class FileData {
  @Element(name = "FileName", required = false)
  private String fileName;

  @Element(name = "FileMetaData", required = false)
  private FileMetaData fileMetaData;

  public String getFileName() {
    return fileName;
  }

  public void setFileName(String fileName) {
    this.fileName = fileName;
  }

  public FileMetaData getFileMetaData() {
    return fileMetaData;
  }

  public void setFileMetaData(FileMetaData fileMetaData) {
    this.fileMetaData = fileMetaData;
  }
}
