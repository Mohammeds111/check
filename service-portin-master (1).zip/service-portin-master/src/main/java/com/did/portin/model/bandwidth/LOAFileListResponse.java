package com.did.portin.model.bandwidth;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Root;

import java.util.List;

@Root(strict = false)
@Element(name = "fileListResponse")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LOAFileListResponse {

  @Element(name = "fileCount", required = false)
  String fileCount;

  @Element(name = "resultCode", required = false)
  String resultCode;

  @Element(name = "resultMessage", required = false)
  String resultMessage;

  @ElementList(entry = "fileNames", inline = true, required = false)
  private List<String> fileNames;

  @ElementList(entry = "fileData", inline = true, required = false)
  private List<FileData> fileData;

  @Element(name = "ErrorResponse", required = false)
  private ErrorResponse errorResponse;

  public ErrorResponse getErrorResponse() {
    return errorResponse;
  }

  public void setErrorResponse(ErrorResponse errorResponse) {
    this.errorResponse = errorResponse;
  }

  public List<FileData> getFileData() {
    return fileData;
  }

  public void setFileData(List<FileData> fileData) {
    this.fileData = fileData;
  }

  public String getFileCount() {
    return fileCount;
  }

  public void setFileCount(String fileCount) {
    this.fileCount = fileCount;
  }

  public String getResultCode() {
    return resultCode;
  }

  public void setResultCode(String resultCode) {
    this.resultCode = resultCode;
  }

  public String getResultMessage() {
    return resultMessage;
  }

  public void setResultMessage(String resultMessage) {
    this.resultMessage = resultMessage;
  }

  public List<String> getFileNames() {
    return fileNames;
  }

  public void setFileNames(List<String> fileNames) {
    this.fileNames = fileNames;
  }
}
