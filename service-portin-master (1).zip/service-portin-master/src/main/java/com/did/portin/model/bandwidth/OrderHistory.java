package com.did.portin.model.bandwidth;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

@Root(name = "OrderHistory", strict = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OrderHistory {
  @Element(name = "OrderDate", required = false)
  private String orderDate;

  @Element(name = "Note", required = false)
  private String note;

  @Element(name = "Author", required = false)
  private String author;

  @Element(name = "Status", required = false)
  private String status;

  @Element(name = "Difference", required = false)
  private String difference;

  public String getOrderDate() {
    return orderDate;
  }

  public void setOrderDate(String orderDate) {
    this.orderDate = orderDate;
  }

  public String getNote() {
    return note;
  }

  public void setNote(String note) {
    this.note = note;
  }

  public String getAuthor() {
    return author;
  }

  public void setAuthor(String author) {
    this.author = author;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public String getDifference() {
    return difference;
  }

  public void setDifference(String difference) {
    this.difference = difference;
  }
}
