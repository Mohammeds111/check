package com.did.portin.jaxrs;

import com.did.portin.model.rest.PortinResponse;
import com.did.portin.service.QuestionnaireService;
import javax.inject.Inject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DIDPortinQuestionsEndpoint {

  @Inject
  private QuestionnaireService questionnaireService;

  @RequestMapping("/portin-questions")
  public PortinResponse getQuestions() {
    return
        PortinResponse.generateResponse("Ok", 0, questionnaireService.getQuestions());
  }
}
