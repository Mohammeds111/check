package com.did.portin.model.db;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.sql.Timestamp;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class PortinOrder {
    private Long portinOrderId;
    private Long portinRequestId;
    private String portinCustomerOrderId;
    private String portinExternalSystemOrderId;
    private String alternateSpid;
    private String billingTelephoneNumber;
    private String replacementBillingTelephoneNumber;
    private String userAccountType;
    private String userCompanyname;
    private String authorizedUsername;
    private String userFirstname;
    private String userMiddleinitial;
    private String userLastname;
    private String addressStreetnumber;
    private String addressStreetname;
    private String addressHousenumber;
    private String addressAddressline2;
    private String addressCity;
    private String addressState;
    private String addressZip;
    private String addressZip4;
    private String partialPortin;
    private String addressCountry;
    private String loaAuthorizingPerson;
    private String lcAccountnumber;
    private String lcPinnumber;
    private String phoneNumbers;
    private Long portinType;
    private String loaUploaded;
    private String csrUploaded;
    private String loaRequired;
    private Timestamp suggestedActivationDate;
    private Timestamp requestedActivationDate;
    private Integer requestedQuantity;
    private Long orderStatus;
    private String externalApiUpdateStatusCode;
    private String externalApiUpdateStatusDescription;
    private String triggered;
    private Timestamp orderDate;
    private String vendorName;
    private String rateCenter;
    private String locCarrierSpid;
    private String locCarrierName;
    private String locCarrierIswireless;
    private String locCarrierAccountnumberrequired;
    private Long locCarrierMinimumportinginterval;
    private String organizationCode;
    private String organizationName;
    private Long requestedUserId;
    private String requestedUserEmail;
    private String requestedUserFullName;
    private String requestedUserCode;
    private Timestamp modifiedDate;
    private Long modifiedUserId;
    private String modifiedUserEmail;
    private String modifiedUserFullName;
    private String modifiedUserCode;
    private Timestamp completedDate;
    private Long completedUserId;
    private String completedUserEmail;
    private String completedUserFullName;
    private String completedUserCode;
    private String notes;
    private String phoneNumberType;

    public Long getPortinOrderId() {
        return portinOrderId;
    }

    public void setPortinOrderId(Long portinOrderId) {
        this.portinOrderId = portinOrderId;
    }

    public Long getPortinRequestId() {
        return portinRequestId;
    }

    public void setPortinRequestId(Long portinRequestId) {
        this.portinRequestId = portinRequestId;
    }

    public String getPortinCustomerOrderId() {
        return portinCustomerOrderId;
    }

    public void setPortinCustomerOrderId(String portinCustomerOrderId) {
        this.portinCustomerOrderId = portinCustomerOrderId;
    }

    public String getPortinExternalSystemOrderId() {
        return portinExternalSystemOrderId;
    }

    public void setPortinExternalSystemOrderId(String portinExternalSystemOrderId) {
        this.portinExternalSystemOrderId = portinExternalSystemOrderId;
    }

    public String getAlternateSpid() {
        return alternateSpid;
    }

    public void setAlternateSpid(String alternateSpid) {
        this.alternateSpid = alternateSpid;
    }

    public String getBillingTelephoneNumber() {
        return billingTelephoneNumber;
    }

    public void setBillingTelephoneNumber(String billingTelephoneNumber) {
        this.billingTelephoneNumber = billingTelephoneNumber;
    }

    public String getReplacementBillingTelephoneNumber() {
        return replacementBillingTelephoneNumber;
    }

    public void setReplacementBillingTelephoneNumber(String replacementBillingTelephoneNumber) {
        this.replacementBillingTelephoneNumber = replacementBillingTelephoneNumber;
    }

    public String getUserAccountType() {
        return userAccountType;
    }

    public void setUserAccountType(String userAccountType) {
        this.userAccountType = userAccountType;
    }

    public String getUserCompanyname() {
        return userCompanyname;
    }

    public void setUserCompanyname(String userCompanyname) {
        this.userCompanyname = userCompanyname;
    }

    public String getAuthorizedUsername() {
        return authorizedUsername;
    }

    public void setAuthorizedUsername(String authorizedUsername) {
        this.authorizedUsername = authorizedUsername;
    }

    public String getUserFirstname() {
        return userFirstname;
    }

    public void setUserFirstname(String userFirstname) {
        this.userFirstname = userFirstname;
    }

    public String getUserMiddleinitial() {
        return userMiddleinitial;
    }

    public void setUserMiddleinitial(String userMiddleinitial) {
        this.userMiddleinitial = userMiddleinitial;
    }

    public String getUserLastname() {
        return userLastname;
    }

    public void setUserLastname(String userLastname) {
        this.userLastname = userLastname;
    }

    public String getAddressStreetnumber() {
        return addressStreetnumber;
    }

    public void setAddressStreetnumber(String addressStreetnumber) {
        this.addressStreetnumber = addressStreetnumber;
    }

    public String getAddressStreetname() {
        return addressStreetname;
    }

    public void setAddressStreetname(String addressStreetname) {
        this.addressStreetname = addressStreetname;
    }

    public String getAddressHousenumber() {
        return addressHousenumber;
    }

    public void setAddressHousenumber(String addressHousenumber) {
        this.addressHousenumber = addressHousenumber;
    }

    public String getAddressAddressline2() {
        return addressAddressline2;
    }

    public void setAddressAddressline2(String addressAddressline2) {
        this.addressAddressline2 = addressAddressline2;
    }

    public String getAddressCity() {
        return addressCity;
    }

    public void setAddressCity(String addressCity) {
        this.addressCity = addressCity;
    }

    public String getAddressState() {
        return addressState;
    }

    public void setAddressState(String addressState) {
        this.addressState = addressState;
    }

    public String getAddressZip() {
        return addressZip;
    }

    public void setAddressZip(String addressZip) {
        this.addressZip = addressZip;
    }

    public String getAddressZip4() {
        return addressZip4;
    }

    public void setAddressZip4(String addressZip4) {
        this.addressZip4 = addressZip4;
    }

    public String getPartialPortin() {
        return partialPortin;
    }

    public void setPartialPortin(String partialPortin) {
        this.partialPortin = partialPortin;
    }

    public String getAddressCountry() {
        return addressCountry;
    }

    public void setAddressCountry(String addressCountry) {
        this.addressCountry = addressCountry;
    }

    public String getLoaAuthorizingPerson() {
        return loaAuthorizingPerson;
    }

    public void setLoaAuthorizingPerson(String loaAuthorizingPerson) {
        this.loaAuthorizingPerson = loaAuthorizingPerson;
    }

    public String getLcAccountnumber() {
        return lcAccountnumber;
    }

    public void setLcAccountnumber(String lcAccountnumber) {
        this.lcAccountnumber = lcAccountnumber;
    }

    public String getLcPinnumber() {
        return lcPinnumber;
    }

    public void setLcPinnumber(String lcPinnumber) {
        this.lcPinnumber = lcPinnumber;
    }

    public String getPhoneNumbers() {
        return phoneNumbers;
    }

    public void setPhoneNumbers(String phoneNumbers) {
        this.phoneNumbers = phoneNumbers;
    }

    public Long getPortinType() {
        return portinType;
    }

    public void setPortinType(Long portinType) {
        this.portinType = portinType;
    }

    public String getLoaUploaded() {
        return loaUploaded;
    }

    public void setLoaUploaded(String loaUploaded) {
        this.loaUploaded = loaUploaded;
    }

    public String getCsrUploaded() {
        return csrUploaded;
    }

    public void setCsrUploaded(String csrUploaded) {
        this.csrUploaded = csrUploaded;
    }

    public String getLoaRequired() {
        return loaRequired;
    }

    public void setLoaRequired(String loaRequired) {
        this.loaRequired = loaRequired;
    }

    public Timestamp getSuggestedActivationDate() {
        return suggestedActivationDate;
    }

    public void setSuggestedActivationDate(Timestamp suggestedActivationDate) {
        this.suggestedActivationDate = suggestedActivationDate;
    }

    public Timestamp getRequestedActivationDate() {
        return requestedActivationDate;
    }

    public void setRequestedActivationDate(Timestamp requestedActivationDate) {
        this.requestedActivationDate = requestedActivationDate;
    }

    public Integer getRequestedQuantity() {
        return requestedQuantity;
    }

    public void setRequestedQuantity(Integer requestedQuantity) {
        this.requestedQuantity = requestedQuantity;
    }

    public Long getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(Long orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getExternalApiUpdateStatusCode() {
        return externalApiUpdateStatusCode;
    }

    public void setExternalApiUpdateStatusCode(String externalApiUpdateStatusCode) {
        this.externalApiUpdateStatusCode = externalApiUpdateStatusCode;
    }

    public String getExternalApiUpdateStatusDescription() {
        return externalApiUpdateStatusDescription;
    }

    public void setExternalApiUpdateStatusDescription(String externalApiUpdateStatusDescription) {
        this.externalApiUpdateStatusDescription = externalApiUpdateStatusDescription;
    }

    public String getTriggered() {
        return triggered;
    }

    public void setTriggered(String triggered) {
        this.triggered = triggered;
    }

    public Timestamp getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(Timestamp orderDate) {
        this.orderDate = orderDate;
    }

    public String getVendorName() {
        return vendorName;
    }

    public void setVendorName(String vendorName) {
        this.vendorName = vendorName;
    }

    public String getRateCenter() {
        return rateCenter;
    }

    public void setRateCenter(String rateCenter) {
        this.rateCenter = rateCenter;
    }

    public String getLocCarrierSpid() {
        return locCarrierSpid;
    }

    public void setLocCarrierSpid(String locCarrierSpid) {
        this.locCarrierSpid = locCarrierSpid;
    }

    public String getLocCarrierName() {
        return locCarrierName;
    }

    public void setLocCarrierName(String locCarrierName) {
        this.locCarrierName = locCarrierName;
    }

    public String getLocCarrierIswireless() {
        return locCarrierIswireless;
    }

    public void setLocCarrierIswireless(String locCarrierIswireless) {
        this.locCarrierIswireless = locCarrierIswireless;
    }

    public String getLocCarrierAccountnumberrequired() {
        return locCarrierAccountnumberrequired;
    }

    public void setLocCarrierAccountnumberrequired(String locCarrierAccountnumberrequired) {
        this.locCarrierAccountnumberrequired = locCarrierAccountnumberrequired;
    }

    public Long getLocCarrierMinimumportinginterval() {
        return locCarrierMinimumportinginterval;
    }

    public void setLocCarrierMinimumportinginterval(Long locCarrierMinimumportinginterval) {
        this.locCarrierMinimumportinginterval = locCarrierMinimumportinginterval;
    }

    public String getOrganizationCode() {
        return organizationCode;
    }

    public void setOrganizationCode(String organizationCode) {
        this.organizationCode = organizationCode;
    }

    public String getOrganizationName() {
        return organizationName;
    }

    public void setOrganizationName(String organizationName) {
        this.organizationName = organizationName;
    }

    public Long getRequestedUserId() {
        return requestedUserId;
    }

    public void setRequestedUserId(Long requestedUserId) {
        this.requestedUserId = requestedUserId;
    }

    public String getRequestedUserEmail() {
        return requestedUserEmail;
    }

    public void setRequestedUserEmail(String requestedUserEmail) {
        this.requestedUserEmail = requestedUserEmail;
    }

    public String getRequestedUserFullName() {
        return requestedUserFullName;
    }

    public void setRequestedUserFullName(String requestedUserFullName) {
        this.requestedUserFullName = requestedUserFullName;
    }

    public String getRequestedUserCode() {
        return requestedUserCode;
    }

    public void setRequestedUserCode(String requestedUserCode) {
        this.requestedUserCode = requestedUserCode;
    }

    public Timestamp getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Timestamp modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public Long getModifiedUserId() {
        return modifiedUserId;
    }

    public void setModifiedUserId(Long modifiedUserId) {
        this.modifiedUserId = modifiedUserId;
    }

    public String getModifiedUserEmail() {
        return modifiedUserEmail;
    }

    public void setModifiedUserEmail(String modifiedUserEmail) {
        this.modifiedUserEmail = modifiedUserEmail;
    }

    public String getModifiedUserFullName() {
        return modifiedUserFullName;
    }

    public void setModifiedUserFullName(String modifiedUserFullName) {
        this.modifiedUserFullName = modifiedUserFullName;
    }

    public String getModifiedUserCode() {
        return modifiedUserCode;
    }

    public void setModifiedUserCode(String modifiedUserCode) {
        this.modifiedUserCode = modifiedUserCode;
    }

    public Timestamp getCompletedDate() {
        return completedDate;
    }

    public void setCompletedDate(Timestamp completedDate) {
        this.completedDate = completedDate;
    }

    public Long getCompletedUserId() {
        return completedUserId;
    }

    public void setCompletedUserId(Long completedUserId) {
        this.completedUserId = completedUserId;
    }

    public String getCompletedUserEmail() {
        return completedUserEmail;
    }

    public void setCompletedUserEmail(String completedUserEmail) {
        this.completedUserEmail = completedUserEmail;
    }

    public String getCompletedUserFullName() {
        return completedUserFullName;
    }

    public void setCompletedUserFullName(String completedUserFullName) {
        this.completedUserFullName = completedUserFullName;
    }

    public String getCompletedUserCode() {
        return completedUserCode;
    }

    public void setCompletedUserCode(String completedUserCode) {
        this.completedUserCode = completedUserCode;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getPhoneNumberType() {
        return phoneNumberType;
    }

    public void setPhoneNumberType(String phoneNumberType) {
        this.phoneNumberType = phoneNumberType;
    }
}
