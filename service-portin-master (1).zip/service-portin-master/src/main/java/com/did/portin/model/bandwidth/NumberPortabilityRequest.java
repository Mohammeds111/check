package com.did.portin.model.bandwidth;

import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

@Root(name = "NumberPortabilityRequest", strict = false)
public class NumberPortabilityRequest {

  @Element(name = "TnList", required = true)
  private TnListAlt tnList;

  public TnListAlt getTnList() {
    return tnList;
  }

  public void setTnList(TnListAlt tnList) {
    this.tnList = tnList;
  }
}
