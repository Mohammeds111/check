package com.did.portin.model.bandwidth;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.simpleframework.xml.Root;

@Root(name = "IrisStatus", strict = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class IrisStatusForOrderHistoryWrapper extends ErrorCommonAttributes {}
