package com.did.portin.model.enums;

public enum PortinType {

    // Portin type candidates
    AUTOMATED(0),
    AUTOMATEDOFFNET(1),
    INTERNAL(2),
    MANUAL_ON_NET(3),
    MANUALOFFNET(4),
    MANUAL_TOLLFREE(5),
    MIXED(6);

    private long statusId;

    PortinType(long statusId) {
        this.statusId = statusId;
    }

    public long getStatusId() {
        return this.statusId;
    }

    public static PortinType getPortinTypeFromId(long statusId) {
        for (PortinType portintype : PortinType.values()) {
            if (portintype.getStatusId() == statusId) {
                return portintype;
            }
        }

        return null;
    }

    public static PortinType getPortinTypeFromName(String statusName) {
        for (PortinType portinType : PortinType.values()) {
            if (portinType.name().equalsIgnoreCase(statusName)) {
                return portinType;
            }
        }

        return null;
    }
}