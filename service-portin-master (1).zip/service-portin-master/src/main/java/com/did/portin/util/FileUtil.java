package com.did.portin.util;

import javax.ws.rs.core.MultivaluedMap;

public class FileUtil {
  private FileUtil() {
    // Do nothing.
  }

  public static String getFileName(MultivaluedMap<String, String> header) {
    String[] contentDisposition = header.getFirst("Content-Disposition").split(";");
    for (String filename : contentDisposition) {
      if ((filename.trim().startsWith("filename"))) {
        String[] name = filename.split("=");
        return name[1].trim().replaceAll("\"", "");
      }
    }
    return "unknown";
  }
}
