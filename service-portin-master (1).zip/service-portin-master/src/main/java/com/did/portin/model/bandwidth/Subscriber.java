package com.did.portin.model.bandwidth;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

@Root(name = "Subscriber", strict = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Subscriber {
  @Element(name = "SubscriberType", required = false)
  private String subscriberType;

  @Element(name = "FirstName", required = false)
  private String firstName;

  @Element(name = "LastName", required = false)
  private String lastName;

  @Element(name = "ServiceAddress", required = false)
  private ServiceAddress serviceAddress;

  public String getSubscriberType() {
    return subscriberType;
  }

  public void setSubscriberType(String subscriberType) {
    this.subscriberType = subscriberType;
  }

  public String getFirstName() {
    return firstName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public String getLastName() {
    return lastName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public ServiceAddress getServiceAddress() {
    return serviceAddress;
  }

  public void setServiceAddress(ServiceAddress serviceAddress) {
    this.serviceAddress = serviceAddress;
  }
}
