package com.did.portin.jaxrs;

import com.did.portin.model.rest.PhoneNumber;
import com.did.portin.model.rest.PortinResponse;
import com.did.portin.service.ValidatePhoneNumberService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.inject.Inject;
import javax.ws.rs.QueryParam;

@RestController
public class PhoneNumberValidationEndpoint {
  private static final Logger logger = LoggerFactory.getLogger(PhoneNumberValidationEndpoint.class);
  @Inject private ValidatePhoneNumberService validatePhoneNumberService;

  @PostMapping(
      path = "/phone-number/validation",
      consumes = "application/json",
      produces = "application/json")
  public PortinResponse validatePhoneNumber(
      @RequestBody PhoneNumber phoneNumber, @QueryParam("portinOrderId") Long portinOrderId)
      throws Exception {
    return PortinResponse.generateResponse(
        "Ok",
        0,
        validatePhoneNumberService.validatePhoneNumbers(
            phoneNumber.getPhoneNumbers(), portinOrderId));
  }

  @ExceptionHandler(Exception.class)
  public ResponseEntity<String> handleException(Exception exception) throws JSONException {
    JSONObject response = new JSONObject();
    response.put("Error Message", exception.getMessage());
    logger.debug("Exception in PhoneNumberValidationEndpoint:", exception.getMessage());
    return new ResponseEntity<String>(response.toString(), HttpStatus.BAD_REQUEST);
  }
}
