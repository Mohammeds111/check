package com.did.portin.model.bandwidth;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Root;

import java.util.List;

@Root(name = "UnsupportedLosingCarriers", strict = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UnsupportedLosingCarriers {

  @ElementList(name = "LosingCarrierTnList", inline = true, required = false)
  private List<LosingCarrierTnList> losingCarrierTnList;

  public List<LosingCarrierTnList> getLosingCarrierTnList() {
    return losingCarrierTnList;
  }

  public void setLosingCarrierTnList(List<LosingCarrierTnList> losingCarrierTnList) {
    this.losingCarrierTnList = losingCarrierTnList;
  }
}
