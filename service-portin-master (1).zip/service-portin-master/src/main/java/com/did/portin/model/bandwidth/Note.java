package com.did.portin.model.bandwidth;

import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

@Root(name = "Note")
public class Note {
  @Element(name = "Id", required = false)
  private int id;

  @Element(name = "UserId", required = false)
  private String userId;

  @Element(name = "Description", required = false)
  private String description;

  @Element(name = "LastDateModifier", required = false)
  private String lastDateModifier;

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getUserId() {
    return userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getLastDateModifier() {
    return lastDateModifier;
  }

  public void setLastDateModifier(String lastDateModifier) {
    this.lastDateModifier = lastDateModifier;
  }
}
