package com.did.portin.model.bandwidth;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Root;

import java.util.List;

@Root(name = "NumberPortabilityResponse", strict = false)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class NumberPortabilityResponse {

  @Element(name = "PortType", required = false)
  private String portType;

  @Element(name = "PortableNumbers", required = false)
  private PortableNumbers portableNumbers;

  @Element(name = "PortabilityErrors", required = false)
  private PortabilityErrors portabilityErrors;

  @ElementList(entry = "SupportedRateCenters", inline = true, required = false)
  private List<SupportedRateCenters> supportedRateCenters;

  @ElementList(entry = "UnsupportedRateCenters", inline = true, required = false)
  private List<UnsupportedRateCenters> unsupportedRateCenters;

  @ElementList(entry = "PartnerSupportedRateCenters", inline = true, required = false)
  private List<PartnerSupportedRateCenters> partnerSupportedRateCenters;

  @ElementList(entry = "SupportedLosingCarriers", inline = true, required = false)
  private List<SupportedLosingCarriers> supportedLosingCarriers;

  @ElementList(entry = "UnsupportedLosingCarriers", inline = true, required = false)
  private List<UnsupportedLosingCarriers> unsupportedLosingCarriers;

  @ElementList(entry = "Errors", inline = true, required = false)
  private List<Errors> errors;

  public String getPortType() {
    return portType;
  }

  public void setPortType(String portType) {
    this.portType = portType;
  }

  public List<SupportedRateCenters> getSupportedRateCenters() {
    return supportedRateCenters;
  }

  public void setSupportedRateCenters(List<SupportedRateCenters> supportedRateCenters) {
    this.supportedRateCenters = supportedRateCenters;
  }

  public List<UnsupportedRateCenters> getUnsupportedRateCenters() {
    return unsupportedRateCenters;
  }

  public void setUnsupportedRateCenters(List<UnsupportedRateCenters> unsupportedRateCenters) {
    this.unsupportedRateCenters = unsupportedRateCenters;
  }

  public List<PartnerSupportedRateCenters> getPartnerSupportedRateCenters() {
    return partnerSupportedRateCenters;
  }

  public void setPartnerSupportedRateCenters(
      List<PartnerSupportedRateCenters> partnerSupportedRateCenters) {
    this.partnerSupportedRateCenters = partnerSupportedRateCenters;
  }

  public List<SupportedLosingCarriers> getSupportedLosingCarriers() {
    return supportedLosingCarriers;
  }

  public void setSupportedLosingCarriers(List<SupportedLosingCarriers> supportedLosingCarriers) {
    this.supportedLosingCarriers = supportedLosingCarriers;
  }

  public List<UnsupportedLosingCarriers> getUnsupportedLosingCarriers() {
    return unsupportedLosingCarriers;
  }

  public void setUnsupportedLosingCarriers(
      List<UnsupportedLosingCarriers> unsupportedLosingCarriers) {
    this.unsupportedLosingCarriers = unsupportedLosingCarriers;
  }

  public List<Errors> getErrors() {
    return errors;
  }

  public void setErrors(List<Errors> errors) {
    this.errors = errors;
  }

  public PortableNumbers getPortableNumbers() {
    return portableNumbers;
  }

  public void setPortableNumbers(PortableNumbers portableNumbers) {
    this.portableNumbers = portableNumbers;
  }

  public PortabilityErrors getPortabilityErrors() {
    return portabilityErrors;
  }

  public void setPortabilityErrors(PortabilityErrors portabilityErrors) {
    this.portabilityErrors = portabilityErrors;
  }
}
