package com.did.portin.model.rest;

import com.did.portin.model.rest.errors.Error;

import java.util.List;

public class PortinOrderDeleteResponse {
  private boolean orderDeletedFromDatabase;
  private List<Error> validationErrors;

  public boolean isOrderDeletedFromDatabase() {
    return orderDeletedFromDatabase;
  }

  public void setOrderDeletedFromDatabase(boolean orderDeletedFromDatabase) {
    this.orderDeletedFromDatabase = orderDeletedFromDatabase;
  }

  public List<Error> getValidationErrors() {
    return validationErrors;
  }

  public void setValidationErrors(List<Error> validationErrors) {
    this.validationErrors = validationErrors;
  }
}
